# FULL104 PR #146 standalone derived-metadata evidence bundle

Contains the ten ORIGINAL `diagnostic_parameters_v1` package files byte-for-byte, plus the original PR #146 navigation index, START_HERE.md, exact CI workflow, and two bundle-specific explanatory files. Each original file was checked against its exact immutable PR-head Git blob SHA-1, including the three CSVs' CRLF bytes.

Source repository: https://github.com/dushyant-mishra/sea-ad-jepa-agent/pull/146
Original immutable head: 8369efe5839f9aca5912cc8280a05330b2b104a3

This is complete for *published derived metadata and verification*, but does NOT include the separately owned 410 MB original calibration ZIP or expanded 2.7 GB original SQLite. Their authenticated source identities, also in the physical receipt, are:
- FOUNDATION_CALIBRATION_BUNDLE_20260824.zip: 410278055 bytes, SHA-256 07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444
- metadata/foundation_metadata_rows.sqlite: 2709786624 expanded bytes, SHA-256 a771f08be31a840b5472448c438a153fbca7de93ba2ed31fe692eaeda02e6913

The independently published verifier can run on the included exported outputs without those source files. Re-executing the original producer from its raw inputs REQUIRES those separately authenticated heavy files. No training or protected outcomes were used, and no current V5 execution authority is granted.

From the archive root:
```bash
python analysis/v5_full104_dataset_etl_20260921/diagnostic_parameters_v1/verify_full104_metadata_receipt_v1.py analysis/v5_full104_dataset_etl_20260921/diagnostic_parameters_v1
python -m pytest -q analysis/v5_full104_dataset_etl_20260921/diagnostic_parameters_v1/test_full104_diagnostic_metadata_v1.py
```
