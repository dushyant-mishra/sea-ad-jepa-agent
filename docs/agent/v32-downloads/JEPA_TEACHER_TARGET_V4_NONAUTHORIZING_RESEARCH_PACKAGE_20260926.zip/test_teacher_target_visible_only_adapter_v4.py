#!/usr/bin/env python3
"""Independent V4 view-boundary tests, including planted V3 aggregate leakage."""
import unittest
import numpy as np
from scipy.sparse import csr_matrix
from teacher_target_raw_adapter_v3 import strict_raw_views,frozen_query_partition
from teacher_target_visible_only_adapter_v4 import visible_only_views

class VisibleOnlyTests(unittest.TestCase):
 def setUp(self):
  self.raw=np.array([[7,13,8,4,3,9],[1,2,6,3,1,12],[0,5,5,1,2,7]],dtype=np.int64)
  self.extra=np.array([103,23,50],dtype=np.int64)
  self.support=np.ones(6,dtype=bool);self.C=np.array([1,3,5]);self.T=np.array([2,4])
 def route(self,m,cls=visible_only_views):
  return cls(csr_matrix(m),m.sum(1)+self.extra,self.support,0,self.C,self.T)
 def test_both_views_match_direct_visible_only_raw_oracle(self):
  v=self.route(self.raw)
  for x,cols in [(v.context_values.toarray(),self.C),(v.teacher_values.toarray(),self.T)]:
   raw=self.raw[:,cols].astype(float)
   np.testing.assert_allclose(x,np.log1p(10000*raw/raw.sum(1)[:,None]),atol=1e-13)
 def test_exact_q_and_opposite_view_counterfactual_invariance(self):
  orig=self.route(self.raw)
  for index in [0,2,4]: # q or teacher-only indices
   for mult in [0,2,10000]:
    x=self.raw.copy();x[:,index]*=mult
    if index in self.T and np.any(x[:,self.T].sum(1)==0):continue
    now=self.route(x)
    np.testing.assert_array_equal(now.context_values.toarray(),orig.context_values.toarray())
    if index==0:np.testing.assert_array_equal(now.teacher_values.toarray(),orig.teacher_values.toarray())
  for index in self.C: # student-only indices must not move teacher representation
   x=self.raw.copy();x[:,index]*=100
   np.testing.assert_array_equal(self.route(x).teacher_values.toarray(),orig.teacher_values.toarray())
 def test_v3_aggregate_teacher_leak_is_caught(self):
  old=self.route(self.raw,strict_raw_views)
  x=self.raw.copy();x[:,self.T[0]]+=100
  old2=self.route(x,strict_raw_views)
  self.assertGreater(float(np.max(np.abs(old2.context_values.toarray()-old.context_values.toarray()))),0.1)
  new=self.route(self.raw)
  new2=self.route(x)
  np.testing.assert_array_equal(new2.context_values.toarray(),new.context_values.toarray())
 def test_visible_only_normalized_archive_formula(self):
  # Old z contains q and T in full L. Per-view expm1 ratios cancel L.
  original=np.log1p(10000*self.raw/self.raw.sum(1)[:,None])
  zview=original[:,self.C]
  ratio=np.expm1(zview)
  corrected=np.log1p(10000*ratio/ratio.sum(1)[:,None])
  np.testing.assert_allclose(corrected,self.route(self.raw).context_values.toarray(),atol=2e-12)
  mutated=self.raw.copy();mutated[:,self.T]+=77;mutated[:,0]+=125
  old=np.log1p(10000*mutated/mutated.sum(1)[:,None]);r=np.expm1(old[:,self.C]);cf=np.log1p(10000*r/r.sum(1)[:,None])
  np.testing.assert_allclose(cf,corrected,atol=2e-12)
 def test_zero_depth_and_source_library_invalid_fail(self):
  raw=self.raw.copy();raw[0,self.T]=0
  with self.assertRaisesRegex(ValueError,'insufficient visible'):self.route(raw)
  with self.assertRaises(ValueError):visible_only_views(csr_matrix(self.raw),np.zeros(3,dtype=int),self.support,0,self.C,self.T)
 def test_reject_malformed_support_and_query_or_overlap(self):
  sup=self.support.copy();sup[0]=False
  with self.assertRaisesRegex(ValueError,'structural measurement'):
   visible_only_views(csr_matrix(self.raw),self.raw.sum(1)+self.extra,sup,0,self.C,self.T)
  with self.assertRaises(ValueError):
   visible_only_views(csr_matrix(self.raw),self.raw.sum(1)+self.extra,self.support,0,[0,1],self.T)
  with self.assertRaises(ValueError):
   visible_only_views(csr_matrix(self.raw),self.raw.sum(1)+self.extra,self.support,0,[1,2],self.T)
 def test_randomized_adversarial_vectors(self):
  rng=np.random.default_rng(260926)
  for rep in range(512):
   raw=rng.integers(1,1000,size=(3,6),dtype=np.int64)
   extra=rng.integers(1,1000,size=3,dtype=np.int64)
   base=visible_only_views(csr_matrix(raw),raw.sum(1)+extra,self.support,0,self.C,self.T)
   changed=raw.copy();changed[:,[0,2,4]]=rng.integers(0,100000,size=(3,3))
   new=visible_only_views(csr_matrix(changed),changed.sum(1)+extra,self.support,0,self.C,self.T)
   np.testing.assert_array_equal(new.context_values.toarray(),base.context_values.toarray())
   changed2=raw.copy();changed2[:,[0,1,3,5]]=rng.integers(0,100000,size=(3,4))
   newer=visible_only_views(csr_matrix(changed2),changed2.sum(1)+extra,self.support,0,self.C,self.T)
   np.testing.assert_array_equal(newer.teacher_values.toarray(),base.teacher_values.toarray())

if __name__=='__main__':unittest.main(verbosity=2)
