#!/usr/bin/env python3
"""Independent 300-row historical old-log1p archival q/T counterfactual redteam.

Mathematical counterfactuals on original normalized expression, not actual alternate
raw-cell measurements. Scope strictly historical, no FULL104 V5 production claims.
"""
import json,hashlib
import numpy as np
from scipy import sparse
from pathlib import Path
from teacher_target_historical_crossview_v3 import load,read_historical_common_support

n=300
X,m=load(n,Path('/tmp/foundation_discovery_50k.npz'),Path('/mnt/data/expression.zip'))
common=read_historical_common_support(m,Path('/mnt/data/FOUNDATION_CALIBRATION_BUNDLE_20260824.zip'))
q=6186
assert common[q]
cols=np.flatnonzero(common);cols=cols[cols!=q]
# Partition independent of observed q value and observed expression.
order=sorted(cols,key=lambda col:hashlib.sha256(f'V4_INDEPENDENT_PANEL|{int(col)}'.encode()).digest())
cols=np.array(order[:2048]);C,T=cols[:1024],cols[1024:]
Zc=X[:,C].toarray();Zt=X[:,T].toarray();zq=X[:,q].toarray().ravel()
uc=np.expm1(Zc);ut=np.expm1(Zt);uq=np.expm1(zq)
vc=uc.sum(axis=1)
active=(vc>1e-10)
assert active.sum()>250

def visible(Cvals):
 mass=np.expm1(Cvals)
 denom=mass.sum(axis=1)
 out=np.zeros_like(mass)
 good=denom>1e-10
 out[good]=np.log1p(10000*mass[good]/denom[good,None])
 return out

base=visible(Zc)
errors=[];leaks=[];errs_f32=[];errs_d6=[]
qf=uq/10000;tf=ut.sum(axis=1)/10000
for mq,mt in [(0,1),(2,1),(0,0),(2,20),(0,20)]:
 # Perturb ONLY q and teacher-view counts. All C raw counts fixed; all
 # outside-panel raw counts fixed, including source-unmapped features.
 factor=1+(mq-1)*qf+(mt-1)*tf
 assert np.min(factor)>1e-10
 alt_c=np.log1p(uc/factor[:,None])
 corrected=visible(alt_c)
 errors.append(float(np.max(abs(corrected[active]-base[active]))))
 leaks.append(float(np.max(abs(alt_c[active]-Zc[active]))))
 q32=visible(np.asarray(Zc,dtype=np.float32).astype(np.float64))
 alt32=visible(np.asarray(alt_c,dtype=np.float32).astype(np.float64))
 errs_f32.append(float(np.max(abs(q32[active]-alt32[active]))))
 q6=visible(np.round(Zc,6));alt6=visible(np.round(alt_c,6))
 errs_d6.append(float(np.max(abs(q6[active]-alt6[active]))))
assert max(errors)<1e-11
assert max(leaks)>0.1
out={'scope':'AUTHENTICATED_HISTORICAL_300_ROWS__EXPLORATORY_MATHEMATICAL_COUNTERFACTUAL',
    'sample_rows':n,'rows_with_nonzero_visible_panel':int(active.sum()),
    'canonical_q':q,'context_gene_count':len(C),'teacher_gene_count':len(T),
    'q_and_teacher_counterfactual_regimes':5,
    'original_full_library_nonquery_change_max':float(max(leaks)),
    'visible_only_counterfactual_max_float64':float(max(errors)),
    'visible_only_counterfactual_max_independent_float32_reencoding':float(max(errs_f32)),
    'visible_only_counterfactual_max_independent_6decimal_reencoding':float(max(errs_d6)),
    'queries_selected_from_structural_support_not_q_expression':True,
    'does_not_prove_current_FULL104_storage_or_actual_V5_consumer':True,
    'training_authorized':False}
p=Path('/mnt/data/teacher_target_view_leak_redteam_v4_results.json')
p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
