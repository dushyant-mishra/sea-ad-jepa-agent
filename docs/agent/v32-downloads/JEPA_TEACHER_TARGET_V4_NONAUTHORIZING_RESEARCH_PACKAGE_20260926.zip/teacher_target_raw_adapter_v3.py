#!/usr/bin/env python3
"""NON-AUTHORIZING RESEARCH ADAPTER: strict query-excluded raw FULL104-like CSR.

Not a production-source patch, representation authority, masking qualification or
trainer. All metadata/source digests must be authenticated by the caller.
"""
from dataclasses import dataclass
from hashlib import sha256
from typing import Sequence
import numpy as np
import scipy.sparse as sp


@dataclass(frozen=True)
class QueryBlindViews:
    """ONLY values and structurally supported indices allowed downstream."""
    canonical_query_address: int
    context_columns: tuple[int, ...]
    teacher_columns: tuple[int, ...]
    context_values: sp.csr_matrix
    teacher_values: sp.csr_matrix
    context_measured: np.ndarray
    teacher_measured: np.ndarray


def frozen_query_partition(n_addresses: int, query_address: int, measured: np.ndarray,
                           salt: str) -> tuple[np.ndarray, np.ndarray]:
    """Partition measured non-query columns without reading any RNA count.
    Demonstration only: a real policy must freeze salt/partition/coverage first.
    """
    if not isinstance(salt, str) or not salt or not (0 <= query_address < n_addresses):
        raise ValueError('bad partition inputs')
    sup = np.asarray(measured)
    if sup.shape != (n_addresses,) or sup.dtype != np.bool_ or not sup[query_address]:
        raise ValueError('query must have authenticated structural measurement')
    cols = np.flatnonzero(sup)
    cols = cols[cols != query_address]
    selected = [[], []]
    for col in cols:
        bit = sha256(f'{salt}|query={query_address}|address={int(col)}'.encode('ascii')).digest()[0] & 1
        selected[bit].append(int(col))
    if not selected[0] or not selected[1]:
        raise ValueError('insufficient support for complementary views')
    return np.asarray(selected[0], np.int64), np.asarray(selected[1], np.int64)


def strict_raw_views(raw_counts: sp.csr_matrix, source_library: Sequence[int],
                     structural_support: np.ndarray, query_address: int,
                     context_columns: Sequence[int], teacher_columns: Sequence[int],
                     *, max_query_fraction: float = 1 - 1e-8) -> QueryBlindViews:
    """Exclude q at RAW normalization boundary; emit no q count or original L.

    Note: the caller's original raw CSR is not mutated, and must be kept out
    of teacher/student object reachability after calling this trusted adapter.
    """
    if not sp.isspmatrix_csr(raw_counts):
        raise ValueError('authenticated raw Level4 block must be CSR')
    n, width = raw_counts.shape
    if n == 0 or width < 3 or not 0 <= query_address < width:
        raise ValueError('bad block/query shape')
    if raw_counts.data.size and (np.any(raw_counts.data < 0) or not np.all(np.isfinite(raw_counts.data))
                                 or not np.all(raw_counts.data == np.rint(raw_counts.data))):
        raise ValueError('raw matrix must be finite nonnegative integer counts')
    if not np.issubdtype(raw_counts.dtype, np.integer):
        raise ValueError('raw Level4 dtype must be integer')
    if not raw_counts.has_canonical_format:
        raise ValueError('CSR must be canonical (no unsorted or duplicate source entries)')
    libraries = np.asarray(source_library)
    if libraries.shape != (n,) or not np.issubdtype(libraries.dtype, np.integer) or np.any(libraries <= 0):
        raise ValueError('full source library must be exact positive integers per row')
    sup = np.asarray(structural_support)
    if sup.shape != (width,) or sup.dtype != np.bool_ or not sup[query_address]:
        raise ValueError('operator must structurally measure query')
    if raw_counts.indices.size and not np.all(sup[raw_counts.indices]):
        raise ValueError('nonzero count in structurally unmeasured address')
    def validate_cols(label: str, val: Sequence[int]) -> np.ndarray:
        seq = np.asarray(val)
        if seq.ndim != 1 or seq.dtype.kind not in 'iu' or seq.size == 0:
            raise ValueError(f'{label} must be nonempty integer indices')
        if np.any(seq < 0) or np.any(seq >= width) or len(np.unique(seq)) != len(seq):
            raise ValueError(f'{label} contains invalid or duplicate addresses')
        if query_address in seq or not np.all(sup[seq]):
            raise ValueError(f'{label} contains query or unmeasured address')
        return seq.astype(np.int64)
    C = validate_cols('context', context_columns)
    T = validate_cols('teacher', teacher_columns)
    if np.intersect1d(C, T).size:
        raise ValueError('context and teacher views must be disjoint')
    mapped_sums = np.asarray(raw_counts.sum(axis=1), dtype=np.int64).reshape(-1)
    if np.any(mapped_sums > libraries):
        raise ValueError('mapped counts exceed full source library')
    q_counts = np.asarray(raw_counts[:, query_address].toarray(), dtype=np.int64).reshape(-1)
    if np.any(q_counts > libraries):
        raise ValueError('query exceeds full source library')
    denominator = libraries - q_counts
    fractions = q_counts.astype(np.float64) / libraries.astype(np.float64)
    if np.any(denominator <= 0) or np.any(fractions > max_query_fraction):
        raise ValueError('query-excluded denominator is invalid or insufficiently stable')
    def normalize_selected(cols: np.ndarray) -> sp.csr_matrix:
        out = raw_counts[:, cols].astype(np.float64).tocsr()
        if out.nnz:
            row_ix = np.repeat(np.arange(n), np.diff(out.indptr))
            out.data = np.log1p(out.data * (10000.0 / denominator[row_ix]))
        return out
    # Only sanctioned non-query views and structural masks escape.
    return QueryBlindViews(int(query_address), tuple(map(int, C)), tuple(map(int,T)),
                           normalize_selected(C), normalize_selected(T),
                           np.ones(C.size,dtype=np.bool_),np.ones(T.size,dtype=np.bool_))
