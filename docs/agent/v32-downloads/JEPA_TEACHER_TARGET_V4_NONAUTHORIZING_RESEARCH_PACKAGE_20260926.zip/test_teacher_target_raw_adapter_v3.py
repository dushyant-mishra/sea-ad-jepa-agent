#!/usr/bin/env python3
"""Independent fixtures + adversarial raw adapter integration tests. NON-AUTHORIZING."""
import unittest
import numpy as np
from scipy.sparse import csr_matrix
from dataclasses import fields
from teacher_target_raw_adapter_v3 import strict_raw_views, frozen_query_partition

class StrictRawAdapterTests(unittest.TestCase):
    def setUp(self):
        # Sixth column stands for a measured non-panel address, remainder includes
        # additional source features not included in Level4 canonical matrix.
        self.raw=np.array([[7,13,0,4,3,9],[1,0,6,3,0,12],[0,0,5,1,0,0]],dtype=np.int64)
        self.extra=np.array([103,23,50],dtype=np.int64)
        self.L=self.raw.sum(axis=1)+self.extra
        self.sup=np.array([True,True,True,True,True,True])
        self.C=np.array([1,3,5],dtype=np.int64)
        self.T=np.array([2,4],dtype=np.int64)
    def route(self, raw=None,L=None,sup=None,C=None,T=None,q=0):
        x=self.raw if raw is None else raw
        return strict_raw_views(csr_matrix(x), self.L if L is None else L,
                 self.sup if sup is None else sup,q,self.C if C is None else C,
                 self.T if T is None else T)
    def test_direct_raw_oracle_and_outside_panel_mass(self):
        v=self.route();d=self.L-self.raw[:,0]
        np.testing.assert_allclose(v.context_values.toarray(),np.log1p(10000*self.raw[:,self.C]/d[:,None]),atol=1e-14)
        np.testing.assert_allclose(v.teacher_values.toarray(),np.log1p(10000*self.raw[:,self.T]/d[:,None]),atol=1e-14)
        self.assertTrue(np.all(self.extra>0))
    def test_query_counterfactual_per_cell_and_views(self):
        baseline=self.route()
        for shift in [-7,-1,1,111,100000]:
            m=self.raw.copy();m[:,0]=np.maximum(0,m[:,0]+shift)
            L=m.sum(axis=1)+self.extra
            if np.any(m[:,0]/L > 1-1e-8):continue
            test=self.route(m,L)
            np.testing.assert_array_equal(test.context_values.toarray(),baseline.context_values.toarray())
            np.testing.assert_array_equal(test.teacher_values.toarray(),baseline.teacher_values.toarray())
            self.assertEqual(test.context_columns,baseline.context_columns)
            self.assertEqual(test.teacher_columns,baseline.teacher_columns)
        # Both values and membership invariant, not just a near-zero gradient.
    def test_deterministic_partition_cannot_see_q_count(self):
        x,y=frozen_query_partition(6,0,self.sup,'PREDECLARED_SYNTH_FIXTURE')
        for _ in range(4):
            xx,yy=frozen_query_partition(6,0,self.sup,'PREDECLARED_SYNTH_FIXTURE')
            np.testing.assert_array_equal(x,xx);np.testing.assert_array_equal(y,yy)
        self.assertFalse(set(x)&set(y));self.assertNotIn(0,x);self.assertNotIn(0,y)
    def test_measured_zero_is_distinct_from_unmeasured(self):
        v=self.route();self.assertTrue(v.context_measured[0]);self.assertEqual(self.raw[1,1],0)
        sup=self.sup.copy();sup[0]=False
        with self.assertRaisesRegex(ValueError,'measure query'):self.route(sup=sup)
        sup=self.sup.copy();sup[2]=False
        # Structural support cannot silently contradict observed count.
        with self.assertRaisesRegex(ValueError,'structurally unmeasured'):self.route(sup=sup)
        with self.assertRaisesRegex(ValueError,'unmeasured address'):self.route(sup=sup,T=np.array([2,4]))
    def test_no_forbidden_payload_escapes(self):
        v=self.route()
        keys=set(x.name for x in fields(v))
        self.assertFalse(keys & {'q_count','source_library','query_fraction','denominator','raw_counts','donor_id','full_normalized','qc'})
        self.assertEqual(set(v.context_columns)&set(v.teacher_columns),set())
    def test_invalid_libraries_and_corrupted_blocks_fail(self):
        for L in [np.array([1,1,1]),np.array([0,1,1]),np.array([1.0,2,3]),np.array([1,2])]:
            with self.assertRaises(ValueError):self.route(L=L)
        for bad in ['duplicate','nonint','negative','unsorted']:
            x=csr_matrix(self.raw)
            if bad=='duplicate':
                x=csr_matrix((np.array([7,3,10]),np.array([0,0,1]),np.array([0,2,3,3])),shape=(3,6))
            elif bad=='nonint':x=x.astype(float)
            elif bad=='negative':x.data[0]=-1
            else:
                a=x.indptr[0];b=x.indptr[1]
                x.indices[a:b]=x.indices[a:b][::-1];x.data[a:b]=x.data[a:b][::-1]
            with self.assertRaises(ValueError):
                strict_raw_views(x,self.L,self.sup,0,self.C,self.T)
    def test_views_query_inclusion_collision_or_invalid_missingness_fail(self):
        for C,T in [([0,1],[2,4]),([1,3],[3,4]),([1,1],[2,4]),([1],[100])]:
            with self.assertRaises(ValueError):self.route(C=np.array(C),T=np.array(T))
        with self.assertRaises(ValueError):self.route(q=6)
    def test_legacy_route_must_be_detected_as_leaky(self):
        old=np.log1p(self.raw[:,self.C]*10000/self.L[:,None]);m=self.raw.copy();m[:,0]+=100
        newL=m.sum(axis=1)+self.extra
        new=np.log1p(m[:,self.C]*10000/newL[:,None]);self.assertGreater(np.max(abs(old-new)),0.1)

if __name__=='__main__':unittest.main(verbosity=2)
