#!/usr/bin/env python3
"""Non-authorizing strict raw sparse visible-only normalization candidate.

For each complementary view, the normalized values are a function ONLY of that
view's raw measured counts. The audited original source library is validated for
integrity, but never serves as a model normalization denominator. This removes
both q-scalar and opposite-view total-count compositional shortcuts.

This pure helper has NOT been wired into/qualified against the live V5 consumer.
"""
from typing import Sequence
import numpy as np
import scipy.sparse as sp
from teacher_target_raw_adapter_v3 import QueryBlindViews


def visible_only_views(raw_counts: sp.csr_matrix, source_library: Sequence[int],
                       structural_support: np.ndarray, query_address: int,
                       context_columns: Sequence[int], teacher_columns: Sequence[int],
                       *, min_visible_counts: int = 1) -> QueryBlindViews:
    if not sp.isspmatrix_csr(raw_counts):
        raise ValueError('authenticated raw Level4 block must be CSR')
    n, width = raw_counts.shape
    if n == 0 or width < 3 or not isinstance(query_address, (int, np.integer)) or not (0 <= query_address < width):
        raise ValueError('invalid block or canonical query address')
    if not np.issubdtype(raw_counts.dtype, np.integer) or not raw_counts.has_canonical_format:
        raise ValueError('original matrix must have integer counts and canonical CSR format')
    if raw_counts.nnz and np.any(raw_counts.data < 0):
        raise ValueError('negative raw counts')
    libraries = np.asarray(source_library)
    if (libraries.shape != (n,) or not np.issubdtype(libraries.dtype, np.signedinteger)
            or np.any(libraries <= 0)):
        raise ValueError('source library must be exact signed positive integer counts per row')
    mapped_sums = np.asarray(raw_counts.sum(axis=1),dtype=np.int64).ravel()
    if np.any(mapped_sums > libraries):
        raise ValueError('mapped counts exceed original full source-library counts')
    if isinstance(min_visible_counts, bool) or not isinstance(min_visible_counts,int) or min_visible_counts < 1:
        raise ValueError('minimum view-depth threshold must be positive integer')
    sup=np.asarray(structural_support)
    if sup.shape != (width,) or sup.dtype != np.bool_ or not sup[int(query_address)]:
        raise ValueError('query must have authenticated structural measurement')
    if raw_counts.nnz and not np.all(sup[raw_counts.indices]):
        raise ValueError('nonzero count in structurally unmeasured address')
    def cols(label: str, inp: Sequence[int]) -> np.ndarray:
        x=np.asarray(inp)
        if x.ndim != 1 or x.size == 0 or x.dtype.kind not in 'iu':
            raise ValueError(f'{label}: nonempty integer address array required')
        if x.min() < 0 or x.max() >= width or len(np.unique(x))!=len(x):
            raise ValueError(f'{label}: invalid or duplicate addresses')
        if query_address in x or not np.all(sup[x]):
            raise ValueError(f'{label}: query or unmeasured address included')
        return x.astype(np.int64)
    C=cols('student context',context_columns)
    T=cols('teacher',teacher_columns)
    if np.intersect1d(C,T).size:
        raise ValueError('complementary views overlap')
    def normalize_only_visible(c: np.ndarray) -> sp.csr_matrix:
        view=raw_counts[:,c].astype(np.float64).tocsr()
        depth=np.asarray(view.sum(axis=1),dtype=np.float64).ravel()
        if np.any(depth<min_visible_counts):
            raise ValueError('insufficient visible counts for a complementary view')
        if view.nnz:
            rows=np.repeat(np.arange(n,dtype=np.int64),np.diff(view.indptr))
            view.data=np.log1p(10000.0*view.data/depth[rows])
        return view
    # Source-library and q counts are NEVER forwarded, normalized, or copied into
    # a model-visible output. We do not compute the value of q at all.
    return QueryBlindViews(int(query_address),tuple(map(int,C)),tuple(map(int,T)),
            normalize_only_visible(C),normalize_only_visible(T),
            np.ones(C.size,dtype=np.bool_),np.ones(T.size,dtype=np.bool_))
