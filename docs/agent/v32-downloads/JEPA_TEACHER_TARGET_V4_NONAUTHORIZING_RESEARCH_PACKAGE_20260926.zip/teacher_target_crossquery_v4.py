#!/usr/bin/env python3
"""Non-authorizing cross-query generic-state diagnostic, historical SVD only."""
import argparse,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score

p=argparse.ArgumentParser()
p.add_argument('--apoe',type=Path,default=Path('/tmp/crossview_visible_teacher_q6186.npz'))
p.add_argument('--p2ry12',type=Path,default=Path('/tmp/crossview_visible_teacher_q12469.npz'))
p.add_argument('--out',type=Path,default=Path('/mnt/data/teacher_target_crossquery_v4_results.json'))
a=p.parse_args()
A=np.load(a.apoe);B=np.load(a.p2ry12)
assert int(A['query'][0])==6186 and int(B['query'][0])==12469
assert np.array_equal(A['train'],B['train']) and np.array_equal(A['test'],B['test'])
tr=A['train'];te=A['test']
results={}
for tag,x,y in [('APOE_to_P2RY12',A['teacher'],B['teacher']),('P2RY12_to_APOE',B['teacher'],A['teacher'])]:
    fit=Ridge(alpha=100.0).fit(x[tr],y[tr]);pred=fit.predict(x[te]);
    results[tag]={'heldout_pooled_r2':float(r2_score(y[te],pred,multioutput='variance_weighted')),
                  'train_cells':int(tr.sum()),'heldout_cells':int(te.sum())}
out={'scope':'HISTORICAL_SVD_CROSSQUERY_COMPARABILITY_NOT_BIOLOGICAL_SPECIFICITY',
     'queries':{'APOE':6186,'P2RY12':12469},'results':results,
     'caveats':['Linear cross-query predictability indicates overlapping state information, not its complete identity.',
                'Neither teacher is an EMA or actual query-conditioned JEPA representation.',
                'SVDs are derived from the same source RNA cells; external chromatin/perturbation validation remains absent.'],
     'training_authorized':False}
a.out.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
