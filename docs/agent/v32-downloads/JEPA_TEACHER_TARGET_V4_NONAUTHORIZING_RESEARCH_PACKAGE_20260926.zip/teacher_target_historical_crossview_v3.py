#!/usr/bin/env python3
"""Exploratory NON-AUTHORIZING historical RNA cross-view feasibility only.

No current FULL104 target authority, masking qualification, JEPA training,
protected outcomes, or independent biological validation. Teacher = PCA/SVD of
predeclared second gene view, NOT a trained/EMA query-local teacher.
"""
from __future__ import annotations
import argparse, csv, gzip, hashlib, io, json, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder

NPZ_SHA='4c50f1de2446b07bbf3199bba80ebc89749c8104cb7668664ed705dbfc579d92'
MANIFEST_SHA='79eb005c719788119d9c3021e211148d34198301a59393707c9a2dc88dcef9a6'

def sha256(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for chunk in iter(lambda:f.read(8<<20),b''):h.update(chunk)
 return h.hexdigest()

def prefix_npy(z,name,count):
 with z.open(name) as f:
  ver=np.lib.format.read_magic(f)
  shape,order,dtype=(np.lib.format.read_array_header_1_0(f) if ver==(1,0) else np.lib.format.read_array_header_2_0(f))
  if len(shape)!=1 or order or count>shape[0]:raise ValueError('bad sparse npy header')
  b=f.read(count*dtype.itemsize)
  if len(b)!=count*dtype.itemsize:raise ValueError('truncated archive')
  return np.frombuffer(b,dtype=dtype).copy()

def load(n,archive,metadata):
 if sha256(archive)!=NPZ_SHA:raise ValueError('NPZ hash mismatch')
 with zipfile.ZipFile(archive) as z:
  with z.open('shape.npy') as f:shape=np.load(f,allow_pickle=False)
  if tuple(shape)!=(50000,41238):raise ValueError('historical shape mismatch')
  ptr=prefix_npy(z,'indptr.npy',n+1)
  idx=prefix_npy(z,'indices.npy',int(ptr[-1]))
  data=prefix_npy(z,'data.npy',int(ptr[-1]))
  X=sparse.csr_matrix((data,idx,ptr),shape=(n,41238))
 with zipfile.ZipFile(metadata) as z:
  path=next(p for p in z.namelist() if p.endswith('/FOUNDATION_DISCOVERY_SAMPLE_FREEZE.csv'))
  full=z.read(path)
  if hashlib.sha256(full).hexdigest()!=MANIFEST_SHA:raise ValueError('historical manifest hash mismatch')
  m=pd.read_csv(io.BytesIO(full),nrows=n,dtype={'donor_id':str})
 if len(m)!=n or not np.array_equal(m.sample_row.to_numpy(),np.arange(n)) or not (m['sample']=='A_NATURAL_MIXTURE').all():
  raise ValueError('metadata/expression alignment mismatch')
 if m['in_original_t1'].astype(str).str.lower().isin(['true','1']).any():raise ValueError('original T1 contamination')
 return X,m

def read_historical_common_support(m, bundle: Path) -> np.ndarray:
    """Use the actual August 42-operator support ledger, not nonzero detection."""
    needed=set(m.matrix_id.unique())
    support={k:np.zeros(41238,dtype=np.bool_) for k in needed}
    compressed_expected='ee5d12c144536efdacb983f6b9aa2acb46d47d395b2aa9c556ad10b191f3cdaa'
    with zipfile.ZipFile(bundle) as z:
        name=next(p for p in z.namelist() if p.endswith('/address_measurement_support.csv.gz'))
        packed=z.read(name)
    if hashlib.sha256(packed).hexdigest()!=compressed_expected:raise ValueError('historical support digest mismatch')
    with gzip.GzipFile(fileobj=io.BytesIO(packed)) as g:
        rows=csv.DictReader(io.TextIOWrapper(g,encoding='utf-8',newline=''))
        for row in rows:
            label=row['matrix_id']
            if label not in needed:continue
            col=int(row['molecular_address_index'])
            if row['measured_address'].lower()=='true':support[label][col]=True
    if not all(x.any() for x in support.values()):raise ValueError('historical matrix support missing')
    shared=np.logical_and.reduce(list(support.values()))
    return shared

def by_donor_rmse(y,p,d):
 v=[]
 for donor in np.unique(d):
  mask=d==donor
  if mask.sum()<3:continue
  v.append(float(np.sqrt(np.mean((y[mask]-p[mask])**2))))
 return np.asarray(v)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--npz',type=Path,default=Path('/tmp/foundation_discovery_50k.npz'))
 ap.add_argument('--metadata',type=Path,default=Path('/mnt/data/expression.zip'))
 ap.add_argument('--normalization',choices=['query-excluded','visible-only'],default='query-excluded');ap.add_argument('--teacher-output',type=Path,default=None);ap.add_argument('--query',type=int,choices=[0,6186,12469],default=6186);ap.add_argument('--bundle',type=Path,default=Path('/mnt/data/FOUNDATION_CALIBRATION_BUNDLE_20260824.zip'));ap.add_argument('--rows',type=int,default=4000);ap.add_argument('--out',type=Path,default=Path('/mnt/data/teacher_target_historical_crossview_v3_results.json'))
 a=ap.parse_args()
 if not 1000<=a.rows<=5000:raise ValueError('bounded historical only')
 X,m=load(a.rows,a.npz,a.metadata)
 common=read_historical_common_support(m,a.bundle)
 donors=m.donor_id.to_numpy(dtype=str); unique=np.unique(donors)
 test_d=set(sorted(unique,key=lambda d:hashlib.sha256(('V3_TEST|'+d).encode()).hexdigest())[:max(1,len(unique)//5)])
 test=np.array([d in test_d for d in donors]); train=~test
 if train.sum()<1000 or test.sum()<150:raise ValueError('insufficient donor separation')
 # Query address is selected in the command BEFORE reading expression.
 # 6186 = APOE, 12469 = P2RY12, 0 = TSPAN6 under historical registry.
 q=a.query
 if not common[q]:raise ValueError('requested q is not structurally supported in all sampled matrices')
 zq=X[:,q].toarray().ravel();frac=np.expm1(zq)/10000
 if np.any(frac<0) or np.any(frac>=1-1e-8):raise ValueError('invalid query fractions')
 # Train-only gene panel choice is exploratory, not an approved target panel.
 counts=X[train].getnnz(axis=0);counts[~common]=-1;counts[q]=-1
 panel=np.argsort(-counts,kind='stable')[:1200]
 C=np.array([j for j in panel if hashlib.sha256(f'V3_VIEW|q={q}|{j}'.encode()).digest()[0]&1==0])
 T=np.array([j for j in panel if hashlib.sha256(f'V3_VIEW|q={q}|{j}'.encode()).digest()[0]&1==1])
 if len(C)<400 or len(T)<400:raise AssertionError('bad view partition')
 def strict_panel(cols):
  arr=X[:,cols].astype('float64').tocsr(copy=True)
  if a.normalization=='visible-only':
   if arr.nnz:
    arr.data=np.expm1(arr.data)
    denom=np.asarray(arr.sum(axis=1)).ravel()
    if np.any(denom<=0):raise ValueError('nonestimable empty visible-only view')
    rows=np.repeat(np.arange(arr.shape[0]),np.diff(arr.indptr))
    arr.data=np.log1p(10000*arr.data/denom[rows])
  elif arr.nnz:
   rows=np.repeat(np.arange(arr.shape[0]),np.diff(arr.indptr))
   arr.data=np.log1p(np.expm1(arr.data)/(1-frac[rows]))
  return arr
 ctx=strict_panel(C);tgt=strict_panel(T)
 # SVD is fitted ONLY on train donors; not the same as an actual EMA teacher.
 Tsvd=TruncatedSVD(n_components=12,n_iter=5,random_state=102)
 yy=Tsvd.fit_transform(tgt[train]);Y=Tsvd.transform(tgt)
 # For all methods, normalize teacher components using train donors only.
 mu=Y[train].mean(0);sd=Y[train].std(0);sd=np.where(sd>1e-8,sd,1)
 Y=(Y-mu)/sd
 Csvd=TruncatedSVD(n_components=48,n_iter=4,random_state=103)
 XX=Csvd.fit_transform(ctx[train]);Cemb=Csvd.transform(ctx)
 c_mu=Cemb[train].mean(0);c_sd=Cemb[train].std(0);Cemb=(Cemb-c_mu)/np.where(c_sd>1e-8,c_sd,1)
 op=m.operator_index.astype(str).to_numpy();celltype=m.broad_class.fillna('UNKNOWN').astype(str).to_numpy()
 enc=OneHotEncoder(handle_unknown='ignore',sparse_output=False)
 nuisance=enc.fit_transform(np.column_stack([op[train],celltype[train]]))
 nuisance_all=enc.transform(np.column_stack([op,celltype]))
 ridge=lambda x,y:Ridge(alpha=100.0,fit_intercept=True).fit(x[train],y[train])
 pred_full=ridge(Cemb,Y).predict(Cemb[test]);pred_meta=ridge(nuisance_all,Y).predict(nuisance_all[test]);
 pred_combined=ridge(np.hstack([Cemb,nuisance_all]),Y).predict(np.hstack([Cemb[test],nuisance_all[test]]))
 pred_constant=np.tile(Y[train].mean(0),(test.sum(),1))
 # Within donor + broad class, shuffle training teacher vectors: retains class and
 # donor composition but destroys cell-specific paired target. Do not shuffle TEST.
 rng=np.random.default_rng(24118);ys=Y.copy()
 for _,rows in m[train].groupby(['donor_id','broad_class'],dropna=False).indices.items():
  # pandas group indices relative to filtered frame; map back to absolute rows.
  ix=np.flatnonzero(train)[np.asarray(rows,dtype=int)]
  ys[ix]=Y[rng.permutation(ix)]
 pred_shuf=ridge(Cemb,ys).predict(Cemb[test])
 # Strictly observable/technical-only controls, plus fine-grained old cell labels.
 # These are exploratory historical annotation controls, never JEPA model inputs.
 visible_depth=np.asarray(ctx.getnnz(axis=1),dtype=float).reshape(-1)
 visible_total=np.asarray(ctx.sum(axis=1),dtype=float).reshape(-1)
 visible_square=np.asarray(ctx.power(2).sum(axis=1),dtype=float).reshape(-1)
 Tech=np.stack([np.log1p(visible_depth),np.log1p(visible_total),np.log1p(visible_square)],axis=1)
 tech_mu=Tech[train].mean(axis=0);tech_sd=Tech[train].std(axis=0)
 Tech=(Tech-tech_mu)/np.where(tech_sd>1e-8,tech_sd,1)
 pred_tech=ridge(Tech,Y).predict(Tech[test])
 native_class=m.native_class.fillna('UNKNOWN').astype(str).to_numpy()
 fine_enc=OneHotEncoder(handle_unknown='ignore',sparse_output=False)
 fine_enc.fit(np.column_stack([op[train],native_class[train]]))
 fine_all=fine_enc.transform(np.column_stack([op,native_class]))
 pred_fine=ridge(fine_all,Y).predict(fine_all[test])
 pred_fine_plus=ridge(np.hstack([Cemb,fine_all]),Y).predict(np.hstack([Cemb[test],fine_all[test]]))
 observed=Y[test];d_test=donors[test]
 def metrics(p):
  mse=np.mean((observed-p)**2);base=np.mean((observed-pred_constant)**2)
  d_rmse=by_donor_rmse(observed,p,d_test)
  return {'r2_pooled':float(1-mse/np.mean((observed-observed.mean(0))**2)),
          'mse':float(mse),'relative_gain_vs_train_mean':float(1-mse/base),
          'mean_donor_rmse_min3cells':float(d_rmse.mean()) if len(d_rmse) else None,
          'donors_with_3plus_cells':int(len(d_rmse))}
 scores={'context_to_teacher':metrics(pred_full),'class_operator_only':metrics(pred_meta),
         'context_plus_class_operator':metrics(pred_combined),'donor_class_paired_shuffle_train':metrics(pred_shuf),
         'teacher_train_mean':metrics(pred_constant),'visible_view_technical_summary_only':metrics(pred_tech),
         'native_class_operator_only':metrics(pred_fine),
         'context_plus_native_class_operator':metrics(pred_fine_plus)}
 # Compare donor-level paired RMSE, not pseudo-independent cell-level significance.
 a1=by_donor_rmse(observed,pred_full,d_test);a2=by_donor_rmse(observed,pred_meta,d_test)
 delta=a2-a1
 # Bootstrap donors only, exploratory interval; no threshold retrofitted.
 boot=[]
 if len(delta)>2:
  for _ in range(1000):boot.append(float(np.mean(rng.choice(delta,len(delta),replace=True))))
 out={'scope':'HISTORICAL_DISCOVERY_SAMPLE_A__EXPLORATORY_CROSSVIEW_SVD_NOT_JEPA_TRAINING',
      'source_npz_sha256':NPZ_SHA,'sample_freeze_manifest_sha256':MANIFEST_SHA,
      'rows':a.rows,'train_cells':int(train.sum()),'heldout_cells':int(test.sum()),
      'train_donors':int(len(unique)-len(test_d)),'test_donors':int(len(test_d)),
      'normalization':a.normalization,'target_q_address':int(q),'q_is_excluded_from_both_views':True,
      'query_count_positive_fraction':float((zq>0).mean()),'panel_gene_count':int(len(panel)),'n_common_measured_addresses_in_sampled_matrices':int(common.sum()),
      'context_gene_count':len(C),'teacher_gene_count':len(T),'teacher_svd_dim':12,
      'student_svd_dim':48,'historical_sample_prefix_composition':m.source.value_counts().to_dict(),
      'scores':scores,'native_class_count_in_sample':int(len(np.unique(native_class))),
      'native_class_operator_minus_full_donor_rmse_mean':float(np.mean(by_donor_rmse(observed,pred_fine,d_test)-a1)),
      'class_operator_minus_full_donor_rmse_mean':float(np.mean(delta)),
      'class_operator_minus_full_donor_rmse_bootstrap_ci95':list(map(float,np.percentile(boot,[2.5,97.5]))) if boot else None,
      'actual_ema_or_query_conditioning_tested':False,'biological_prediction_qualified':False,
      'notes':['Targets derive from the same archived transcriptome and are not independent ground truth',
               'Class/operating annotations are historical, not future production-authorized covariates',
               'Panel chosen using training donors only but is not a prospective scientific gene-panel freeze',
               'One fixed query per execution; varying q alone does not demonstrate true q-specific latent interaction',
               'Historical normalized-only recovery has finite precision; production preference remains direct raw view-specific normalization',
               'One historical sample-prefix donor split; not FULL104, not heldout pathology']}
 if a.teacher_output is not None:
  np.savez_compressed(a.teacher_output,teacher=Y.astype(np.float32),train=train,test=test,query=np.array([q],dtype=np.int64))
 a.out.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
