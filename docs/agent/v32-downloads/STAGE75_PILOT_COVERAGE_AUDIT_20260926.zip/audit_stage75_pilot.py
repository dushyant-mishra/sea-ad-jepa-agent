#!/usr/bin/env python3
"""Stage75 compact pilot coverage against archived August24 address namespace.
This is NOT full Morabito RNA/ATAC overlap or current V5 authority closure.
"""
import csv, io, json, hashlib, zipfile
from collections import Counter
from pathlib import Path
ROOT=Path('/mnt/data')
ZIP=ROOT/'FOUNDATION_CALIBRATION_BUNDLE_20260824.zip'
TARGETS='AIF1 AP1G1 APOC1 APOE B2M BSG C1QB C1QC CD74 CTSB FCER1G GPX4 HLA-DPA1 HLA-DPB1 HLA-DRA HLA-DRB1 HMOX1 IRF8 LAMP2 LAPTM5 NFKBIA NPC2 PRDX1 PSAP TREM2 TXNIP TYROBP'.split()
REGULATORS='BACH1 CEBPA ELF1 IRF8 RELA SPI1 STAT1'.split()
manifest='results/tables/stage75_integrated_tf_target_summary_v1.csv'
with zipfile.ZipFile(ZIP) as z:
 member=next(n for n in z.namelist() if n.endswith('/contracts/address_namespace.csv'))
 raw=z.read(member)
 rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8'))))
assert len(rows)==41238, len(rows)
symbols={}
for r in rows:
 if r['symbol']:symbols.setdefault(r['symbol'],[]).append(r)
needed=sorted(set(TARGETS+REGULATORS))
records=[]
for symbol in needed:
 options=symbols.get(symbol,[])
 records.append({'symbol':symbol,'stage75_target':symbol in TARGETS,'stage75_supported_regulator':symbol in REGULATORS,
                 'historical_registry_matches':len(options),'historical_address_indices':';'.join(o['molecular_address_index'] for o in options),
                 'historical_address_ids':';'.join(o['molecular_address_id'] for o in options),
                 'historical_identity_classes':';'.join(o['identity_class'] for o in options),
                 'note':'HISTORICAL AUG24 IDENTITY ONLY; current V5 authority and GSE174367 mapping unverified'})
with (ROOT/'stage75_coverage_audit/stage75_pilot_historical_registry_crosswalk.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=records[0].keys());w.writeheader();w.writerows(records)
summary={'scope':'HISTORICAL_STAGE75_PILOT_CROSSWALK_ONLY__NOT_ATAC_GENE_COVERAGE',
         'repo_commit':'c49b13bd75c2d23716c777336db8fbfc78c09cd0',
         'stage75_tf_target_table_git_blob_sha':'fd0f8e12c1161629f53f568f30cbc0bf8e3ff1a1',
         'source_in_git':manifest,'historical_namespace_zip_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),
         'historical_namespace_member':member,'historical_namespace_member_sha256':hashlib.sha256(raw).hexdigest(),
         'historical_namespace_rows':len(rows),'stage75_target_rows':96,'stage75_unique_targets':len(TARGETS),
         'stage75_supported_regulators':len(REGULATORS),'union_symbols':len(needed),
         'mapped_targets_unique':[r['symbol'] for r in records if r['stage75_target'] and r['historical_registry_matches']==1],
         'unmapped_targets':[r['symbol'] for r in records if r['stage75_target'] and r['historical_registry_matches']==0],
         'ambiguous_targets':[r['symbol'] for r in records if r['stage75_target'] and r['historical_registry_matches']>1],
         'mapped_regulators_unique':[r['symbol'] for r in records if r['stage75_supported_regulator'] and r['historical_registry_matches']==1],
         'unmapped_regulators':[r['symbol'] for r in records if r['stage75_supported_regulator'] and r['historical_registry_matches']==0],
         'ambiguous_regulators':[r['symbol'] for r in records if r['stage75_supported_regulator'] and r['historical_registry_matches']>1],
         'full_morabito_feature_overlap':'NOT_MEASURED','atac_mapped_gene_coverage':'NOT_MEASURED',
         'current_full104_registry_binding':'NOT_VERIFIED',
         'notes':'Counts derived from audited Stage75F table and archived historical namespace. No Morabito RNA/ATAC data are present in this container.'}
out=ROOT/'stage75_coverage_audit/stage75_pilot_coverage_summary.json'
out.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k in ['historical_namespace_rows','stage75_target_rows','stage75_unique_targets','stage75_supported_regulators','union_symbols','unmapped_targets','ambiguous_targets','unmapped_regulators','ambiguous_regulators']},indent=2))
