"""Non-authorizing September 26 JEPA local integrity/identity audit.

Reads the historical calibration ZIP and split archive *without extracting*; never
imports legacy NPZ or checkpoint/pickle content. Requires exact authority digests.
GitHub Stage75 27-symbol snapshot is pinned to blob fd0f8e12c1161629f53f568f30cbc0bf8e3ff1a1;
this script crosswalks that inspected snapshot against the historical registry,
NOT the current V5 registry, the original Stage75 code or Morabito raw H5 files.
"""
from __future__ import annotations
import csv
import hashlib
import io
import json
from pathlib import Path
import unittest
import zipfile
from collections import defaultdict

ROOT=Path('/mnt/data')
CAL='FOUNDATION_CALIBRATION_BUNDLE_20260824.zip'
PARTS=('FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part001','FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part002')
CAL_SHA='07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444'
PART_SHA=('b8163f53a27f7cb1b526f8311d1b46b599502596c5d0be74fa588747a4e72b2e','5bc2ec30fb374b15f1c5a4764e1856b0664c13513462ef2f7e224c4b6f856875')
COMBINED_SHA='63239898b9c93f29c20b62b84dc9b94c2c87e3e3f2b7958b7435847e3b9541f7'
QUARANTINED_NPZ='66e64913-959f-4a7c-bbfe-6ff906fb281d.npz'
QUARANTINED_OBSERVED_SHA='001375ec77c5b606ad0972073c1daa6ad14b0e517f05ea23c6c9b3110203ff70'
STAGE75_BLOB='fd0f8e12c1161629f53f568f30cbc0bf8e3ff1a1'
# From the GitHub-fetched, immutable 96-row Stage75F table at STAGE75_BLOB.
TARGETS=tuple('AIF1 AP1G1 APOC1 APOE B2M BSG C1QB C1QC CD74 CTSB FCER1G GPX4 HLA-DPA1 HLA-DPB1 HLA-DRA HLA-DRB1 HMOX1 IRF8 LAMP2 LAPTM5 NFKBIA NPC2 PRDX1 PSAP TREM2 TXNIP TYROBP'.split())
REGULATORS=tuple('BACH1 CEBPA ELF1 IRF8 RELA SPI1 STAT1'.split())
EXPECTED_AMBIGUOUS={'HLA-DPA1','HLA-DPB1'}


def hash_files(paths):
    h=hashlib.sha256()
    for path in paths:
        with Path(path).open('rb') as f:
            for chunk in iter(lambda: f.read(4*1024*1024),b''):
                h.update(chunk)
    return h.hexdigest()


def require_digest(paths, expected):
    observed=hash_files(paths)
    if observed!=expected:
        raise ValueError(f'FAIL_SHA256 expected={expected} observed={observed}')
    return observed


def classify(symbols, rows):
    by_symbol=defaultdict(list)
    for r in rows:
        if r['symbol']:
            by_symbol[r['symbol']].append(r)
    unique={}; ambiguous={}; missing=[]
    for s in symbols:
        matches=by_symbol.get(s,[])
        if not matches:missing.append(s)
        elif len(matches)==1: unique[s]=matches[0]
        else: ambiguous[s]=matches
    return unique,ambiguous,missing


def run_audit(root=ROOT):
    p=root/CAL
    require_digest([p],CAL_SHA)
    for part,sha in zip(PARTS,PART_SHA):require_digest([root/part],sha)
    require_digest([root/p for p in PARTS],COMBINED_SHA)
    with zipfile.ZipFile(p) as z:
        member=next((n for n in z.namelist() if n.endswith('/contracts/address_namespace.csv')),None)
        if member is None:raise ValueError('MISSING_REGISTRY_MEMBER')
        with z.open(member) as f:
            rows=list(csv.DictReader(io.TextIOWrapper(f,encoding='utf-8',newline='')))
    if len(rows)!=41238:raise ValueError(f'WRONG_REGISTRY_ROWS {len(rows)}')
    unique,ambiguous,missing=classify(TARGETS,rows)
    r_unique,r_ambiguous,r_missing=classify(REGULATORS,rows)
    if missing or r_missing or set(ambiguous)!=EXPECTED_AMBIGUOUS or r_ambiguous:
        raise ValueError(f'IDENTITY_CENSUS_FAIL missing={missing} reg_missing={r_missing} ambiguous={list(ambiguous)} reg_ambiguous={list(r_ambiguous)}')
    if len(unique)!=25 or len(r_unique)!=7:
        raise ValueError('IDENTITY_COUNT_FAIL')
    q=root/QUARANTINED_NPZ
    q_sha=hash_files([q]) if q.exists() else None
    if q_sha is not None and q_sha != QUARANTINED_OBSERVED_SHA:raise ValueError('QUARANTINED_NPZ_DRIFT')
    result={
        'audit':'JEPA_SEP26_LOCAL_HISTORICAL_ASSET_AND_STAGE75_NAMESPACE_V1',
        'training_authorized':False,'current_v5_integration':'NOT_TESTED',
        'stage75_github_blob_reference':STAGE75_BLOB,'stage75_blob_bytes_present_locally':False,
        'calibration_sha256_verified':True,'split_part_sha256_verified':True,'combined_sha256_verified':True,
        'historical_registry_rows':len(rows),'stage75_target_count_reference':len(TARGETS),
        'unique_historical_target_mappings':len(unique),'ambiguous_target_symbols':{},
        'missing_historical_target_symbols':missing,
        'unique_historical_regulator_mappings':len(r_unique),
        'quarantined_npz_sha256':q_sha,'quarantined_npz_usable':False,
        'not_executed':['V4 15-test package absent','Original Stage75 scripts absent','Current-V5 registry matching','Morabito raw RNA/ATAC coverage','FULL104 expression or protected outcomes']
    }
    for symbol,matches in sorted(ambiguous.items()):
        result['ambiguous_target_symbols'][symbol]=[
            {'id':r['molecular_address_id'],'identity_class':r['identity_class'],
             'source_families':r['contributing_source_families']} for r in matches
        ]
    return result


class SyntheticRedTeam(unittest.TestCase):
    def test_digest_accepts_exact_bytes(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a';p.write_bytes(b'authority');self.assertEqual(require_digest([p],hashlib.sha256(b'authority').hexdigest()),hashlib.sha256(b'authority').hexdigest())
    def test_digest_rejects_changed_bytes(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a';p.write_bytes(b'authority');correct=hash_files([p]);p.write_bytes(b'authority!')
            with self.assertRaisesRegex(ValueError,'FAIL_SHA256'):require_digest([p],correct)
    def test_split_part_reordering_detected(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            a=Path(td)/'a';b=Path(td)/'b';a.write_bytes(b'part1');b.write_bytes(b'part2')
            with self.assertRaisesRegex(ValueError,'FAIL_SHA256'):require_digest([b,a],hash_files([a,b]))
    def test_symbol_collision_is_never_autoresolved(self):
        rows=[{'symbol':'HLA-DPA1','molecular_address_id':'current'},{'symbol':'HLA-DPA1','molecular_address_id':'legacy'}]
        u,a,m=classify(['HLA-DPA1'],rows)
        self.assertEqual(u,{});self.assertEqual(len(a['HLA-DPA1']),2);self.assertEqual(m,[])
    def test_missing_symbol_is_not_assumed_zero(self):
        u,a,m=classify(['unobserved'],[])
        self.assertEqual(m,['unobserved']);self.assertEqual(u,{});self.assertEqual(a,{})
    def test_unique_does_not_promote_legacy_collision(self):
        rows=[{'symbol':'A','molecular_address_id':'one'},{'symbol':'A','molecular_address_id':'two'},{'symbol':'B','molecular_address_id':'unique'}]
        u,a,_=classify(['A','B'],rows)
        self.assertEqual(set(u),{'B'});self.assertEqual(set(a),{'A'})


def run_selftests():
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(SyntheticRedTeam)
    return unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful()


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--audit',action='store_true');parser.add_argument('--test',action='store_true');args=parser.parse_args()
    if args.test and not run_selftests():
        raise SystemExit('LOCAL_SELFTEST_FAILED')
    if args.audit or not args.test:
        print(json.dumps(run_audit(),indent=2,sort_keys=True))
