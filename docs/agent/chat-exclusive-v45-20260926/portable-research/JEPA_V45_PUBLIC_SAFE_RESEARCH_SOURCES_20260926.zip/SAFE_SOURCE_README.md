# V45 public-safe archival research source subset

This ZIP is **not** an exact replacement for any original research package. It contains only the historical .py source, narrative .md reports, explicitly named contract/schema/manifest JSON, and four standalone ETL/R17 scripts. Original row-level and per-donor research **results and execution logs are deliberately excluded**, and must be recovered from the separately supplied local-only original portable ZIP if authorized. No human expression matrices or checkpoint data are included.

Source code and fixtures are research-only and sometimes contain superseded options and expected-failure tests. Never execute as authorized production V5 or infer real biological validation from a passing unit test. Original 17 source ZIP byte sizes and full SHA256 are in the accompanying custody manifest, not in this archive's interpreted results.
