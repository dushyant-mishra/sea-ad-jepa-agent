#!/usr/bin/env python3
"""Non-authorizing adversarial audit of the R5 research target/results."""
import hashlib,json,collections,re
from pathlib import Path
import numpy as np
R=Path('/mnt/data');j=json.loads((R/'JEPA_TOURNAMENT_R5_EXPLICIT_TARGET_RESULTS_20260926.json').read_text());t=json.loads((R/'JEPA_TOURNAMENT_R5_TEACHER_FIDELITY_RESULTS_20260926.json').read_text())
checks=[]
def check(name,yes):
    assert bool(yes),name
    checks.append(name)
check('R5_NO_TRAINING_OR_PROTECTED',not j['training_authorized'] and not j['protected_opened'])
check('R5_HISTORICAL_NOT_FULL104',j['biological_target_scientifically_qualified'] is False and j['scope'].startswith('NONAUTHORIZING_HISTORICAL'))
check('TEACHER_DID_NOT_PRETEND_NEURAL',j['neural_teacher_trained'] is False)
check('FIVE_DONOR_FOLDS',j['folds']==5 and len(j['sources'])==5)
check('FORTY_Q_FOLDS',j['n_query_fold']==40)
check('TARGET_MEASURED_NONQ_8_PROGRAM',j['target_definition']['teacher_observation'].startswith('same original cell, 8 q-correlated other genes'))
check('ALL_Q_COUNTERFACTUALS',j['integrity']['query_counterfactual_checks']==40)
check('ALL_Q_EXCLUSIONS',j['integrity']['q_exclusion_checks']==40)
check('ZERO_CONTEXT_ABSTAINS',j['integrity']['zero_teacher_panel_abstains'])
check('THREE_MASK_LABELS_MATCH_MAJOR',j['integrity']['student_train_mask_alignment'].startswith('np.tile'))
source=j['sources'];allq=[(v['fold'],q) for v in source for q in v['queries']];check('EIGHT_DISTINCT_QUERIES_PER_FOLD',len(allq)==40 and all(len(set(v['queries']))==8 for v in source))
check('EACH_Q_PANEL_RECORDED',all(len(v['neighbor_shas'])==8 and all(re.fullmatch('[0-9a-f]{64}',x) for x in v['neighbor_shas']) for v in source))
check('NO_TARGET_SUPPORT_INVENTED',all(min(v['target_support_per_query_test'])>0 for v in source))
check('PER_DONOR_REPORT_FOR_EVERY_Q_ARM',all(z['per_donor_r2'] and z['n_donors']==len(z['per_donor_r2']) for z in j['results']))
check('ALL_50_DONORS_TESTED',len(set(d for z in j['results'] if z['arm']=='Q_SPECIFIC_SHARED32' and z['region']=='ALL' for d in z['per_donor_r2']))==50)
check('EXPLICIT_QUERY_BIASED_CONTROL','SHARED_SLOPE_PLUS_Q_BIAS' in j['summary'])
check('HIGH_CAPACITY_QUERY_BLIND_CONTROL','CAPACITY_MATCHED_Q_BLIND_PCA256' in j['summary'])
check('WRONG_SLOPE_WITH_CORRECT_Q_BIAS', 'WRONG_Q_SLOPE_CORRECT_Q_BIAS' in j['summary'])
check('NO_FALSE_WRONG_QUERY_AUTHORITY','not biological identity proof' in j['redteam_caveat'])
check('SOURCE_PANEL_IDENTITY_AT_EACH_FOLD',all(re.fullmatch('[a-f0-9]{64}',x['eval_sha']) for x in source))
check('MAIN_R5_COUNT',len(j['results'])==5*8*8*2)
check('TEACHER_Q_POLICY_NOT_CONFUSED_WITH_STUDENT',j['target_definition']['student_visibility'].startswith('only independently masked') and 'may separately observe q scalar' in j['target_definition']['teacher_visibility'])
check('TEACHER_FIDELITY_IS_SAME_RNA_NOT_INDEPENDENT',t['scope']=='HISTORICAL_REUSED_RNA_OUTCOME_NOT_INDEPENDENT_BIOLOGY' and t['teacher_policy_selected'] is False)
check('TEACHER_Q_COUNTERFACTUAL_ALL_40',len(t['audit'])==40 and all(x['q_value_invariant'] for x in t['audit']))
check('TEACHER_N_AND_H_DIFFERENT',all(x['n_sha']!=x['h_sha'] for x in t['audit']))
check('TEACHER_MODEL_THREE_COMPARATORS',set(t['summary'])=={'N_CONTEXT_ONLY','N_CONTEXT_PLUS_Q_SCALAR','Q_SCALAR_ONLY'})
# A deliberately invalid normalization demonstrates the exact q leak excluded by R5.
context=np.array([[4.,1.,3.]]);qcount=np.array([[2.]])
def bad(q):return np.log1p(10000*context/(context.sum(axis=1,keepdims=True)+q))
def good():return np.log1p(10000*context/context.sum(axis=1,keepdims=True))
check('PLANTED_FULL_LIBRARY_NORMALIZATION_LEAK_DETECTED',not np.array_equal(bad(qcount),bad(qcount+100)))
check('CORRECT_NONQ_NORMALIZATION_Q_INVARIANT',np.array_equal(good(),good()))
# Distinct exact source bytes and sealed original-asset hashes; no use of ambiguous NPZ.
roots={'FOUNDATION_CALIBRATION_BUNDLE_20260824.zip':'07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444', 'FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part001':'b8163f53a27f7cb1b526f8311d1b46b599502596c5d0be74fa588747a4e72b2e','FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part002':'5bc2ec30fb374b15f1c5a4764e1856b0664c13513462ef2f7e224c4b6f856875'}
for filename,sha in roots.items():
    h=hashlib.sha256();
    with (R/filename).open('rb') as f:
        for c in iter(lambda:f.read(8<<20),b''):h.update(c)
    check('ORIGINAL_SHA_'+filename,h.hexdigest()==sha)
known={'jepa_tour_logexpr.npz':'70a900a800e35027e9c3701178a986758f228d41984dc03d4a4e88c3459ee729','jepa_tour_meta.csv':'95d971a880c7b17f8fa5e00b767459d12846cc362e8f3f26aadc08ed10f297dc'}
for filename,sha in known.items():check('PREPARED_SUBSET_ROOT_'+filename,hashlib.sha256((Path('/tmp')/filename).read_bytes()).hexdigest()==sha)
# Statistical uncertainty across independent donors, not 40 dependent q-fold events.
g=collections.defaultdict(dict)
for z in j['results']:
    if z['region']=='MICRO':continue
    for d,score in z['per_donor_r2'].items():g[d].setdefault(z['arm'],[]).append(score)
D=sorted(g);arms=['Q_SPECIFIC_SHARED32','TECH_PLUS_Q','SHARED_SLOPE_PLUS_Q_BIAS','CAPACITY_MATCHED_Q_BLIND_PCA256','WRONG_Q_SLOPE_CORRECT_Q_BIAS'];A=np.array([[np.mean(g[d][a]) for a in arms] for d in D]);rng=np.random.default_rng(435);bootstrap={}
for i in range(1,len(arms)):
    delta=A[:,0]-A[:,i];bt=np.mean(delta[rng.integers(0,len(D),(10000,len(D)))],axis=1)
    bootstrap[arms[i]]={'mean_donor_macro_r2_difference':float(np.mean(delta)),'naive_cluster_bootstrap_95pct':list(map(float,np.quantile(bt,[.025,.975]))),'positive_of_50_donors':int(np.sum(delta>0))}
check('POSITIVE_Q_INTERACTION_VS_TECH_IN_ALL_FOLDS',all(np.mean([z['r2'] for z in j['results'] if z['arm']=='Q_SPECIFIC_SHARED32' and z['region']=='ALL' and z['fold']==fi]) > np.mean([z['r2'] for z in j['results'] if z['arm']=='TECH_PLUS_Q' and z['region']=='ALL' and z['fold']==fi]) for fi in range(5)))
receipt={'schema':'JEPA_R5_PROSPECTIVE_DEV_TARGET_AUDIT_V1','scope':'REPEATED_HISTORICAL_SAME_STUDY_EXPLORATORY_NO_CLAIM_OF_INDEPENDENT_BIOLOGY','passed':len(checks),'checks':checks,'donors':len(D),'donor_clustered_exploratory_deltas':bootstrap,'known_post_hoc_limit':'Prior R1-R4 use same subset and eval96; bootstrap CIs are descriptive, NOT confirmatory and ignore some dependency from fold-wise fitting','no_production_authority':True}
p=R/'JEPA_TOURNAMENT_R5_REDTEAM_RESULTS_20260926.json';p.write_text(json.dumps(receipt,indent=2));print('R5_CHECKS_PASSED',len(checks),'ALL_ORIGINAL_SHA_MATCH');print('DONOR_MACRO_DELTAS',json.dumps(bootstrap,indent=2))
