#!/usr/bin/env python3
"""Development-only teacher target definition and actual query-conditioned student test.
Historical 1,561-cell R1 subset. No FULL104 authority, protected outcomes or biological fidelity claim.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ[k]='1'
import hashlib,json,importlib.util,time
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder
from sklearn.utils.extmath import randomized_svd
ROOT=Path('/mnt/data'); st=time.time()
spec=importlib.util.spec_from_file_location('prior_frozen',ROOT/'JEPA_TINY_TOURNAMENT_20260926.py'); f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
meta=f.meta; donors=meta.donor_id.to_numpy(); ops=meta.operator_index.to_numpy(); micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy();
donor_ids=np.array(sorted(set(donors[micro])));assert len(donor_ids)==50
perm=np.random.default_rng(20260926).permutation(donor_ids);folds=np.array_split(perm,5)
Q=8; K=8; DELTA=0.0; records=[]; sources=[]; tests=[]

def weighted_r2(y,p,mu,idx=None):
    if idx is not None:y=y[idx];p=p[idx]
    den=np.sum((y-mu)**2);return 1-float(np.sum((y-p)**2))/den if den>0 else None

def prep_pca(x,tr,w,dim=32,seed=10):
    x=np.asarray(x,dtype='float64');wt=w/w.sum();mu=wt@x[tr];sd=np.maximum(np.sqrt(wt@((x[tr]-mu)**2)),.05)
    _,_,vt=randomized_svd((x[tr]-mu)/sd*np.sqrt(wt[:,None]),n_components=dim,n_iter=5,random_state=seed)
    return (x-mu)/sd@vt.T

def fit_predict(xtr,xte,y,w,alpha=20):
    mu=np.average(xtr,axis=0,weights=w);sd=np.maximum(np.sqrt(np.average((xtr-mu)**2,axis=0,weights=w)),.05)
    return Ridge(alpha=alpha).fit((xtr-mu)/sd,y,sample_weight=w/w.mean()).predict((xte-mu)/sd)

for fi,held in enumerate(folds):
    rest=perm[~np.isin(perm,held)];rr=np.random.default_rng(20261010+fi).permutation(rest);train_d=rr[8:];val_d=rr[:8]
    tr=np.flatnonzero(np.isin(donors,train_d));va=np.flatnonzero(np.isin(donors,val_d));te=np.flatnonzero(np.isin(donors,held));tm=np.intersect1d(tr,np.flatnonzero(micro))
    assert not(set(donors[tr])&set(donors[va]) or set(donors[tr])&set(donors[te]) or set(donors[va])&set(donors[te]))
    raw,full,parts,_,source=f.features(tr,va,te)
    # Re-derive exact prior historical evaluation panel: training-microglia only.
    A=f.rawX[tm][:,f.eligible].toarray();preval=(A>0).mean(0);var=np.var(np.log1p(A),axis=0)
    pool=np.flatnonzero((preval>.10)&(preval<.98));pool=pool[np.argsort(-var[pool])][:1600]
    evlocal=np.random.default_rng(43).choice(pool[200:1400],size=96,replace=False);ev=f.eligible[evlocal]
    assert hashlib.sha256(ev.astype('<i4').tobytes()).hexdigest()==source['evaluation_addresses_sha256']
    evraw=f.rawX[:,ev].toarray().astype('float32')
    qids=np.random.default_rng(1009+fi).choice(96,size=Q,replace=False)
    w=1/np.unique(donors[tr],return_inverse=True,return_counts=True)[2][np.unique(donors[tr],return_inverse=True,return_counts=True)[1]];w*=len(tr)/len(np.unique(donors[tr]))
    # Only STUDENT sees these 700 RNA features; none of the entire 96 teacher assay panel.
    # All normalization occurs after discarding the 96 teacher-only features.
    mask=[f.mask_view(raw,810000+fi*3+j)[0] for j in range(3)]
    testmask=f.mask_view(raw,800000+fi)[0]
    xt=np.vstack([m[tr] for m in mask]);xte=testmask[te];ww=np.tile(w/3,3)
    ztr=prep_pca(xt,np.arange(len(xt)),ww,32,seed=4700+fi)
    # PCA train-only for held-out evaluation, using the same learned transform.
    wt=ww/ww.sum();mu=wt@xt;sd=np.maximum(np.sqrt(wt@((xt-mu)**2)),.05)
    _,_,vt=randomized_svd((xt-mu)/sd*np.sqrt(wt[:,None]),n_components=32,n_iter=5,random_state=4700+fi)
    ztr=(xt-mu)/sd@vt.T;zte=(xte-mu)/sd@vt.T
    # Pooled comparator with ~equal readout parameter budget to 8 independent 32D heads:
    # 256D shared slope * 8 output coordinates versus 8 * (32D * 8 output).
    _,_,vt256=randomized_svd((xt-mu)/sd*np.sqrt(wt[:,None]),n_components=256,n_iter=3,random_state=8800+fi)
    ztr256=(xt-mu)/sd@vt256.T;zte256=(xte-mu)/sd@vt256.T
    oh=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(ops[tr,None])
    def tech(x,ix):return np.c_[oh.transform(ops[ix,None]),np.log1p(x[ix].sum(1)),(x[ix]>0).sum(1),x[ix].var(1)]
    ttr=np.vstack([tech(m,tr) for m in mask]);tte=tech(testmask,te)
    targets=[];valid=[];teacher_scalar=[];neighbor_hashes=[]
    for q in qids:
        yy=np.log1p(evraw[tm]);corr=np.corrcoef(yy,rowvar=False)[q].copy();corr[q]=0;corr[~np.isfinite(corr)]=0
        nei=np.argsort(-np.abs(corr),kind='stable')[:K]
        assert len(nei)==K and q not in nei
        neigh=evraw[:,nei].copy();valid_q=neigh.sum(1)>0
        target=f.panel_log(neigh,np.arange(K)) # measured non-query 8-gene program, composition-specific
        assert np.isfinite(target).all()
        # True perturbation of q before normalization must leave target exactly invariant.
        cf=evraw[te].copy(); cf[:,q]+=17
        assert np.array_equal(f.panel_log(cf[:,nei],np.arange(K)),target[te]);tests.append('q_value_invariance')
        assert not np.any(np.isin(nei,[q]));tests.append('q_exclusion')
        targets.append(target);valid.append(valid_q);teacher_scalar.append(np.log1p(evraw[:,q]));neighbor_hashes.append(hashlib.sha256(ev[nei].astype('<i4').tobytes()).hexdigest())
    # Query-specific targets indexed q, with explicit support flags instead of fake-zero training targets.
    y=np.stack(targets,axis=1);ok=np.stack(valid,axis=1);scalar=np.stack(teacher_scalar,axis=1)
    assert y.shape==(len(meta),Q,K) and ok.shape==(len(meta),Q)
    # One shared 32D state with Q-specific readouts; no dimension/count advantage over q-blind baseline.
    # Generic-cell baseline pools true context across q at each cell (train only); full k-dim output.
    yavg=np.sum(y*ok[:,:,None],axis=1)/np.maximum(ok.sum(1)[:,None],1)
    trainok=ok[tr].sum(1)>0
    yavg_train=np.tile(yavg[tr],(3,1));av_pred=fit_predict(ztr[np.tile(trainok,3)],zte,yavg_train[np.tile(trainok,3)],ww[np.tile(trainok,3)])
    # Genuine query-exchangeability control: apply other q-specific readout at same cell to target q.
    qpred=[];qmean=[];techpred=[];countpred=[]
    for qi,q in enumerate(qids):
        eligible=ok[tr,qi];we=np.tile(w[eligible]/3,3)
        stacked_y=np.tile(y[tr[eligible],qi,:],(3,1));row_sel=np.tile(eligible,3)
        # training 3 masks are mask-major; tiled labels are mask-major too.
        qpred.append(fit_predict(ztr[row_sel],zte,stacked_y,we))
        techpred.append(fit_predict(ttr[row_sel],tte,stacked_y,we))
        qs=np.tile(scalar[tr[eligible],qi,None],(3,1));countpred.append(fit_predict(qs,scalar[te,qi,None],stacked_y,we))
        qmean.append(np.average(y[tr[eligible],qi,:],axis=0,weights=w[eligible]))
    pred=np.stack(qpred,axis=1);tpred=np.stack(techpred,axis=1);cpred=np.stack(countpred,axis=1);qmean=np.stack(qmean)
    # Capacity-lower query-biased control: one common slope from all q tasks and Q train-only intercepts.
    # This distinguishes cell x query interaction from replacing a generic state with a q identity code.
    qres=[];qrows=[];qrows256=[];qweights=[]
    for qi in range(Q):
        eligible=ok[tr,qi];sel=np.tile(eligible,3)
        qres.append(np.tile(y[tr[eligible],qi,:]-qmean[qi],(3,1)))
        qrows.append(ztr[sel]);qrows256.append(ztr256[sel]);qweights.append(np.tile(w[eligible]/3,3))
    bz=np.vstack(qrows);by=np.vstack(qres);bw=np.concatenate(qweights)
    shared_resid=fit_predict(bz,zte,by,bw)
    shared_plus_q=shared_resid[:,None,:]+qmean[None,:,:]
    shared_resid256=fit_predict(np.vstack(qrows256),zte256,by,bw)
    shared_plus_q256=shared_resid256[:,None,:]+qmean[None,:,:]
    # Null: deliberately shuffled assignment of the q-specific SLOPES to queries,
    # but RETAIN the correct per-q train mean, so any failure cannot be explained by q-only bias.
    slope_only=pred-qmean[None,:,:]
    wrong_slopes=qmean[None,:,:]+np.roll(slope_only,1,axis=1)
    # Crucial: contexts are q-specific coordinate systems; wrong-query comparison is only a
    # stress control, NOT proof of correct gene identity or validated biological neighborhood.
    for qi,q in enumerate(qids):
        ii=ok[te,qi];micro_idx=ii & micro[te];true=y[te,qi,:];ref=qmean[qi]
        wrong=wrong_slopes[:,qi,:]
        for sub,mask_sub in [('ALL',ii),('MICRO',micro_idx)]:
            if not mask_sub.any():continue
            for name,guess in [('Q_SPECIFIC_SHARED32',pred[:,qi,:]),('Q_AGNOSTIC_STATE',av_pred),('SHARED_SLOPE_PLUS_Q_BIAS',shared_plus_q[:,qi,:]),('CAPACITY_MATCHED_Q_BLIND_PCA256',shared_plus_q256[:,qi,:]),('TECH_PLUS_Q',tpred[:,qi,:]),('Q_ONLY_CONSTANT',np.broadcast_to(ref,guess_shape:=(len(te),K))),('Q_COUNT_TEACHER_ONLY_DIAGNOSTIC',cpred[:,qi,:]),('WRONG_Q_SLOPE_CORRECT_Q_BIAS',wrong)]:
                r2=weighted_r2(true,guess,ref,mask_sub)
                records.append({'fold':fi,'q_id':int(ev[q]),'q_local_idx':int(q),'arm':name,'region':sub,'r2':r2,'n_cells':int(mask_sub.sum()),'n_donors':int(len(set(donors[te][mask_sub]))),'per_donor_r2':{str(d):weighted_r2(true,guess,ref,mask_sub & (donors[te]==d)) for d in set(donors[te][mask_sub])}})
    sources.append({'fold':fi,'eval_sha':source['evaluation_addresses_sha256'],'train_donors':len(train_d),'val_donors':len(val_d),'test_donors':len(held),'queries':list(map(int,ev[qids])),'target_support_per_query_test':list(map(int,ok[te].sum(0))),'neighbor_shas':neighbor_hashes,'train_micro':len(tm),'all_teacher_targets_q_invariant':True,'teacher_and_student_panels_disjoint':True})
    print('FOLD',fi,'test',len(te),'micro',micro[te].sum(),'q target support',ok[te].sum(0).tolist(),flush=True)
summary={}
for a in sorted({r['arm'] for r in records}):
    summary[a]={k:{'mean_query_fold_r2':float(np.mean([r['r2'] for r in records if r['arm']==a and r['region']==k])),'n_query_fold':sum(r['arm']==a and r['region']==k for r in records)} for k in ['ALL','MICRO']}
result={'schema':'JEPA_R5_EXPLICIT_MEASURED_Q_PROGRAM_V1','scope':'NONAUTHORIZING_HISTORICAL_SAME_STUDY_REPEATED_TOURNAMENT_DATA','target_definition':{'teacher_observation':'same original cell, 8 q-correlated other genes, measured raw UMIs','q_selection':'training donors only from prior reused 96-feature exploratory panel','teacher_target':'8-vector log1p(1e4*UMI_of_other_gene/sum_8_gene_UMIs), valid only when sum>0; q scalar not a primary target','teacher_visibility':'teacher sees all 8 actually observed non-q context counts; may separately observe q scalar for an alternative science hypothesis','student_visibility':'only independently masked/normalized 700 genes, disjoint from all 96 teacher-panel genes; q canonical address allowed, q count impossible through this panel','biological_scope':'observational coexpression readout, NOT validated gene program / causal state'},'folds':5,'distinct_test_donors':50,'n_query_fold':40,'results':records,'summary':summary,'sources':sources,'integrity':{'query_counterfactual_checks':tests.count('q_value_invariance'),'q_exclusion_checks':tests.count('q_exclusion'),'student_train_mask_alignment':'np.tile q labels three times to match mask-major concatenation','zero_teacher_panel_abstains':True},'redteam_caveat':'wrong-q slopes are applied with correct q mean to avoid mere q-identification bias; contextual 8D coordinate systems still differ across q, not biological identity proof','biological_target_scientifically_qualified':False,'neural_teacher_trained':False,'training_authorized':False,'protected_opened':False,'elapsed_s':time.time()-st}
p=ROOT/'JEPA_TOURNAMENT_R5_EXPLICIT_TARGET_RESULTS_20260926.json';p.write_text(json.dumps(result,indent=2));print(json.dumps(summary,indent=2));print('SAVED',p,flush=True)
