#!/usr/bin/env python3
"""Historical same-assay teacher-only falsifier: q value vs q-excluded measured context.
Feature split provides independent RNA *features*, not independent biological modality.
No FULL104 current authority. No selection on heldout donors.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import importlib.util,json,hashlib
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge
ROOT=Path('/mnt/data');s=importlib.util.spec_from_file_location('source',ROOT/'JEPA_TINY_TOURNAMENT_20260926.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
meta=f.meta;don=meta.donor_id.to_numpy();micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy();op=meta.operator_index.to_numpy();D=np.array(sorted(set(don[micro])));perm=np.random.default_rng(20260926).permutation(D);folds=np.array_split(perm,5)
recs=[];audit=[]
def fitpred(x,y,tr,te,w):
    mu=np.average(x[tr],axis=0,weights=w);sd=np.maximum(np.sqrt(np.average((x[tr]-mu)**2,axis=0,weights=w)),.05)
    return Ridge(alpha=20).fit((x[tr]-mu)/sd,y[tr],sample_weight=w/w.mean()).predict((x[te]-mu)/sd)
for fi,held in enumerate(folds):
    remain=perm[~np.isin(perm,held)];rr=np.random.default_rng(20261010+fi).permutation(remain);tr=np.flatnonzero(np.isin(don,rr[8:]));te=np.flatnonzero(np.isin(don,held));tm=np.intersect1d(tr,np.flatnonzero(micro))
    _raw,_full,_parts,_y,root=f.features(tr,np.flatnonzero(np.isin(don,rr[:8])),te)
    a=f.rawX[tm][:,f.eligible].toarray();pv=(a>0).mean(0);v=np.var(np.log1p(a),axis=0);pool=np.flatnonzero((pv>.10)&(pv<.98));pool=pool[np.argsort(-v[pool])][:1600]
    ev=f.eligible[np.random.default_rng(43).choice(pool[200:1400],size=96,replace=False)];assert hashlib.sha256(ev.astype('<i4').tobytes()).hexdigest()==root['evaluation_addresses_sha256']; raw=f.rawX[:,ev].toarray().astype('float32')
    # Source-level teacher sees 8 q-associated genes N, optional q count, but never H outcome panel.
    # H validation genes are not used as teacher inputs or chosen by test donors.
    qids=np.random.default_rng(1009+fi).choice(48,size=8,replace=False);yt=np.log1p(raw[tm]);unique,inv,count=np.unique(don[tr],return_inverse=True,return_counts=True);w=(1/count[inv])*(len(tr)/len(unique))
    for q in qids:
        c=np.corrcoef(yt,rowvar=False)[q].copy();c[q]=0;c[~np.isfinite(c)]=0
        n=np.argsort(-np.abs(c[:48]),kind='stable')[:8];h=np.arange(48,96)[np.argsort(-np.abs(c[48:]),kind='stable')[:8]]
        assert q not in n and not set(n)&set(h)
        nr=raw[:,n];hr=raw[:,h];valid=(nr.sum(1)>0)&(hr.sum(1)>0)
        # normalize each biological evidence view independently using non-q eight genes
        ns=f.panel_log(nr,np.arange(8)).astype('float64');hs=f.panel_log(hr,np.arange(8)).astype('float64')
        scalar=np.log1p(raw[:,q,None]).astype('float64')
        models={'N_CONTEXT_ONLY':ns,'N_CONTEXT_PLUS_Q_SCALAR':np.c_[ns,scalar], 'Q_SCALAR_ONLY':scalar}
        for name,x in models.items():
            tt=tr[valid[tr]];ee=te[valid[te]];wt=w[valid[tr]]
            pred=fitpred(x,hs,tt,ee,wt);ref=np.average(hs[tt],axis=0,weights=wt)
            for label,subset in [('ALL',np.arange(len(ee))),('MICRO',np.flatnonzero(micro[ee]))]:
                if not len(subset):continue
                den=np.sum((hs[ee][subset]-ref)**2);r2=1-np.sum((hs[ee][subset]-pred[subset])**2)/den
                recs.append({'fold':fi,'q':int(ev[q]),'model':name,'region':label,'r2':float(r2),'test_n':int(len(subset)),'n_donors':int(len(set(don[ee][subset])))})
        # q-change must NOT modify N/H q-free targets.
        cf=raw[te].copy(); cf[:,q]+=100
        assert np.array_equal(f.panel_log(cf[:,n],np.arange(8)),f.panel_log(raw[te][:,n],np.arange(8)))
        audit.append({'fold':fi,'q_address':int(ev[q]),'n_sha':hashlib.sha256(ev[n].astype('<i4').tobytes()).hexdigest(),'h_sha':hashlib.sha256(ev[h].astype('<i4').tobytes()).hexdigest(),'test_valid':int(valid[te].sum()),'q_value_invariant':True})
    print('FOLD',fi,'done')
summary={}
for m in sorted({r['model'] for r in recs}):summary[m]={reg:float(np.mean([r['r2'] for r in recs if r['model']==m and r['region']==reg])) for reg in ['ALL','MICRO']}
result={'schema':'JEPA_R5_TEACHER_ONLY_SAME_RNA_Q_POLICY_DIAGNOSTIC_V1','scope':'HISTORICAL_REUSED_RNA_OUTCOME_NOT_INDEPENDENT_BIOLOGY','measurement':'predict H8 independently normalized non-query heldout RNA genes from measured N8 contextual teacher program with/without measured q scalar','five_donor_folds':5,'eight_q_per_fold':8,'summary':summary,'records':recs,'audit':audit,'teacher_policy_selected':False,'biological_fidelity_qualified':False,'training_authorized':False};p=ROOT/'JEPA_TOURNAMENT_R5_TEACHER_FIDELITY_RESULTS_20260926.json';p.write_text(json.dumps(result,indent=2));print(json.dumps(summary,indent=2));print('SAVED',p)
