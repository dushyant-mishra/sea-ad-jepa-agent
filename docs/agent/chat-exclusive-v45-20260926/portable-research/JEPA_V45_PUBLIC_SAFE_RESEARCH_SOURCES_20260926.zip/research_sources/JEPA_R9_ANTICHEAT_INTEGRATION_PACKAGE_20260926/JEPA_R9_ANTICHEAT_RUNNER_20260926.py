#!/usr/bin/env python3
"""Run inherited R6/R8 tests and R9 original-data integration; research only."""
import subprocess,os,re,json,hashlib,zipfile,sys
from pathlib import Path
R=Path('/mnt/data')
logs={};runs=[]
def execute(name,script,env=None,expected=None):
    e={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1',**(env or {})}
    proc=subprocess.run([sys.executable,str(R/script)],cwd=R,env=e,capture_output=True,text=True,timeout=120)
    combined=proc.stdout+'\n'+proc.stderr
    if expected=='R6':
        m=re.search(r'Ran (\d+) tests?',combined);n=int(m.group(1)) if m else -1
        ok=(n==25 and proc.returncode==0 and '\nOK' in combined)
    elif expected=='R8':
        data=json.loads(proc.stdout);n=data['passed'];ok=(n==16 and data['failed']==0 and data['training_authorized'] is False and proc.returncode==0)
    else:
        m=re.search(r'Ran (\d+) tests?',combined);n=int(m.group(1)) if m else -1
        marker=[s for s in combined.splitlines() if s.startswith('R9_INTEGRATED_LOCAL_ANTICHEAT_PASS ')]
        ok=n==15 and proc.returncode==0 and '\nOK' in combined and len(marker)==1 and json.loads(marker[0].split(' ',1)[1])['program']==name
    logs[name]=combined
    runs.append(dict(name=name,tests=n,passed=bool(ok),exit_code=proc.returncode,description=expected))
    if not ok:
        print(combined[-3500:]);raise SystemExit(f'FAIL_CLOSED_{name}')
execute('R6_inherited_bridge','JEPA_R6_ARCHITECTURE_BRIDGE_REDTEAM_20260926.py',expected='R6')
execute('R8_inherited_target','JEPA_R8_STRUCTURED_TARGET_REDTEAM_20260926.py',expected='R8')
for name in ('APOE_LIPID','P2RY12_HOMEOSTATIC','HLA_DRA_ANTIGEN'):
    execute(name,'JEPA_R9_ANTICHEAT_R8_BRIDGE_20260926.py',env={'R9_PROGRAM':name},expected='R9')
result={'schema':'JEPA_R9_RESEARCH_ANTICHEAT_DEPLOYMENT_20260926','scope':'R6_R8_INHERITED_PLUS_R9_HISTORICAL_REAL_RNA_RUNTIME_COUNTERFACTUALS',
        'tests_total':sum(x['tests'] for x in runs),'all_passed':all(x['passed'] for x in runs),'runs':runs,
        'original_calibration_sha256':'07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444',
        'source_cache':'historical_discovery_cache_not_independently_original-byte-attested_by_this_runner',
        'prospective_scientific_target_qualified':False,'new_live_git_branch_CI_run':False,
        'current_V5_B2_executed_pass':False,'training_authorized':False,'protected_full104_outcomes_opened':False}
(R/'JEPA_R9_ANTICHEAT_RESULTS_20260926.json').write_text(json.dumps(result,indent=2)+'\n')
(R/'JEPA_R9_ANTICHEAT_TEST_LOG_20260926.txt').write_text('\n'.join('=== '+k+' ===\n'+v for k,v in logs.items()))
print(json.dumps(result,indent=2))
