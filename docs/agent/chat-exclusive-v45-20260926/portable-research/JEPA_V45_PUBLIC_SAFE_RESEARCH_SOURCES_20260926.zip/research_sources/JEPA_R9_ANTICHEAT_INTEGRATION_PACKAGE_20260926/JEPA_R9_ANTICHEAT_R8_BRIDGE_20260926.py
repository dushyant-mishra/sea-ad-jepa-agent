#!/usr/bin/env python3
"""Research-only R8 measured-anchor -> R6 architecture anti-cheat integration.

Demonstrates ACTUAL preprocessing counterfactuals on historical same-cell RNA.
No V5 issuer call, no B2 executed-pass, no biology qualification, no training.
"""
import hashlib, os, sys, json, dataclasses, unittest
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import sparse
sys.path.insert(0, '/mnt/data')
from JEPA_R8_STRUCTURED_TARGET_CONTRACT_20260926 import Evidence,construct_measured_anchor
from JEPA_R6_ARCHITECTURE_BRIDGE_RESEARCH_20260926 import (
    Observation,TeacherHead,StudentView,TeacherTargetPackage,Topology,Module,protected,ContractError)

ROOT='07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444'
BUNDLE=Path('/mnt/data/FOUNDATION_CALIBRATION_BUNDLE_20260824.zip')
CACHE=Path('/tmp/jepa_tour_logexpr.npz')
META=Path('/tmp/jepa_tour_meta.csv')
PROGRAMS={
  'APOE_LIPID':{'q':'APOE','partners':('APOC1','ABCA1','GPNMB','TREM2')},
  'P2RY12_HOMEOSTATIC':{'q':'P2RY12','partners':('TMEM119','CX3CR1','GPR34','C1QA')},
  'HLA_DRA_ANTIGEN':{'q':'HLA-DRA','partners':('CD74','HLA-DPA1','HLA-DMA','IFI30')},
}
PROGRAM=os.environ.get('R9_PROGRAM','APOE_LIPID')
if PROGRAM not in PROGRAMS:raise ValueError('unknown research query program')
NAMES={**PROGRAMS[PROGRAM], 'reference':('RPLP0','EEF1A1','PGK1','HPRT1','PPIA','RPL13A','GUSB','SDHA')}


def load_fixture():
    import zipfile,io
    sha=hashlib.sha256()
    with BUNDLE.open('rb') as f:
        for ch in iter(lambda:f.read(8<<20),b''):sha.update(ch)
    if sha.hexdigest()!=ROOT:raise AssertionError('original historical source SHA mismatch')
    with zipfile.ZipFile(BUNDLE) as z:
        n=next(n for n in z.namelist() if n.endswith('address_namespace.csv'))
        ns=pd.read_csv(z.open(n))
        mapping=ns[ns.identity_class=='current_exact'].set_index('symbol')['molecular_address_index'].to_dict()
        sn=next(n for n in z.namelist() if n.endswith('FOUNDATION_OPERATOR_ADDRESS_OBSERVATION_STATE.npz'))
        with np.load(io.BytesIO(z.read(sn)),allow_pickle=False) as o:support=o['states'].copy()
    meta=pd.read_csv(META); X=sparse.load_npz(CACHE)
    assert X.shape==(len(meta),41238)
    cols={k:tuple(int(mapping[x]) for x in NAMES[k]) if isinstance(NAMES[k],tuple) else int(mapping[NAMES[k]]) for k in NAMES}
    forbid=set(cols['partners']+cols['reference']+(cols['q'],))
    micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy()
    # Eligible same-cell R8 target; reference>0; 16 input genes observed under source operator.
    for i in np.flatnonzero(micro):
        op=int(meta.operator_index.iloc[i]); row=X.getrow(i)
        if row.nnz==0:continue
        scale=np.expm1(row.data.min()); assert scale>0
        def raw(c):
            values=np.asarray(X[i,list(c)].toarray()).ravel(); raw=np.expm1(values)/scale
            assert np.max(abs(raw-np.rint(raw)))<1e-5
            return np.rint(raw).astype(int)
        if not all(support[op,x]==1 for x in forbid):continue
        p=raw(cols['partners']); ref=raw(cols['reference'])
        if not ref.sum() or not p.sum():continue
        # Common visible candidates exclude q, target and normalization reference entirely.
        visible=tuple(int(x) for x in row.indices
                      if support[op,int(x)]==1 and int(x) not in forbid)[:16]
        if len(visible)!=16:continue
        v=raw(visible); assert np.all(v>0); q=int(raw([cols['q']])[0]);
        return dict(meta=meta,X=X,support=support,source_sha=sha.hexdigest(),cell_index=int(i),
                    donor=str(meta.donor_id.iloc[i]),cell_key=f'R9_HISTORICAL_CACHE_ROW_{i}',q=cols['q'],
                    partner_ids=cols['partners'],ref_ids=cols['reference'],student_ids=visible,
                    partner=p,reference=ref,student=v,query_count=q)
    raise AssertionError('no eligible original-cell fixture')

def make_anchor(f,*,q_count=None,partner=None,reference=None):
    e=Evidence(f['cell_key'],f['donor'],f['q'],NAMES['q'],f['partner_ids'],
               tuple(map(int,f['partner'] if partner is None else partner)),f['ref_ids'],
               tuple(map(int,f['reference'] if reference is None else reference)),
               'RNA','SAME_ORIGINAL_CELL',f['source_sha'],
               f['query_count'] if q_count is None else q_count)
    return construct_measured_anchor(e,expected_source_sha256=ROOT)

def student_pipeline(f,*,values=None,denominator_source='VISIBLE_ONLY',hidden_q=None,hidden_partner=None,hidden_reference=None):
    """Actual toy preprocessing; boundary assertions alone cannot establish its lineage."""
    x=np.array(f['student'] if values is None else values,dtype=float)
    if denominator_source=='VISIBLE_ONLY': denom=x.sum()
    elif denominator_source=='FULL_LIBRARY_BAD':
        denom=x.sum()+float(f['query_count'] if hidden_q is None else hidden_q)+sum(f['partner'] if hidden_partner is None else hidden_partner)+sum(f['reference'] if hidden_reference is None else hidden_reference)
    else:raise ValueError('unrecognized preprocessing')
    return np.log1p(np.divide(10000*x,denom,out=np.zeros_like(x),where=denom>0))

def bind_r8_r6(f):
    a=make_anchor(f)
    assert a.status=='MEASURED_NONZERO',a.status
    val=(a.log10k_activity,)+a.clr_composition
    obs=Observation(f['cell_key'],f['q'],tuple(val),True,f['source_sha'])
    t=TeacherHead('CORE',obs,(f['q'],)+f['partner_ids']+f['ref_ids'],f['partner_ids']+f['ref_ids'],True)
    # This bridge deliberately forbids student use of the teacher reference too.
    stu=StudentView(obs,f['student_ids'],f['student_ids'],(),f['partner_ids']+f['ref_ids'])
    target=TeacherTargetPackage((t,),stu,'ALLOW_TEACHER_Q_WITH_SCALAR_DIAGNOSTIC')
    v=target.validate()
    return a,v

class LiveAnticheatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.f=load_fixture()
    def test_01_exact_original_bundle_and_cache_shape(self):
        self.assertEqual(self.f['source_sha'],ROOT)
        self.assertEqual(self.f['X'].shape[1],41238)
    def test_02_real_same_cell_target_bind(self):
        a,v=bind_r8_r6(self.f)
        self.assertFalse(v['training_authorized'])
        self.assertTrue(v['q_visible_to_teacher'])
        self.assertEqual(a.canonical_query,self.f['q'])
    def test_03_query_count_cannot_change_measured_anchor(self):
        a=make_anchor(self.f);b=make_anchor(self.f,q_count=self.f['query_count']+200)
        self.assertEqual((a.log10k_activity,a.clr_composition),(b.log10k_activity,b.clr_composition))
    def test_04_student_runtime_mutation_forbidden_q(self):
        f=self.f
        a=student_pipeline(f); b=student_pipeline(f,hidden_q=f['query_count']+200)
        self.assertTrue(np.array_equal(a,b))
    def test_05_student_runtime_mutation_forbidden_partner_and_reference(self):
        f=self.f;a=student_pipeline(f)
        b=student_pipeline(f,hidden_partner=f['partner']+500,hidden_reference=f['reference']+400)
        self.assertTrue(np.array_equal(a,b))
    def test_06_plant_full_library_query_denominator_must_fail(self):
        f=self.f;a=student_pipeline(f,denominator_source='FULL_LIBRARY_BAD')
        b=student_pipeline(f,denominator_source='FULL_LIBRARY_BAD',hidden_q=f['query_count']+200)
        self.assertGreater(float(abs(a-b).max()),1e-6)
    def test_07_plant_full_library_reference_denominator_must_fail(self):
        f=self.f;a=student_pipeline(f,denominator_source='FULL_LIBRARY_BAD')
        b=student_pipeline(f,denominator_source='FULL_LIBRARY_BAD',hidden_reference=f['reference']+400)
        self.assertGreater(float(abs(a-b).max()),1e-6)
    def test_08_actual_student_inputs_matter(self):
        f=self.f;a=student_pipeline(f);v=f['student'].copy();v[0]+=100
        b=student_pipeline(f,values=v)
        self.assertGreater(float(abs(a-b).max()),1e-6)
    def test_09_teacher_partner_counts_change_measured_anchor(self):
        f=self.f;a=make_anchor(f);p=f['partner'].copy();p[0]+=50
        b=make_anchor(f,partner=p)
        self.assertNotEqual(a.log10k_activity,b.log10k_activity)
    def test_10_bad_declared_student_normalization_ancestor_rejected(self):
        f=self.f;a,v=bind_r8_r6(f)
        obs=Observation(f['cell_key'],f['q'],(1.,),True,f['source_sha'])
        with self.assertRaises(ContractError):StudentView(obs,f['student_ids'],f['student_ids']+(f['q'],),(),f['partner_ids']+f['ref_ids']).verify()
    def test_11_bad_reference_or_partner_as_student_value_rejected(self):
        f=self.f;obs=Observation(f['cell_key'],f['q'],(1.,),True,f['source_sha'])
        for addr in (f['partner_ids'][0],f['ref_ids'][0]):
            with self.subTest(addr=addr),self.assertRaises(ContractError):
                StudentView(obs,f['student_ids']+(addr,),f['student_ids'],(),f['partner_ids']+f['ref_ids']).verify()
    def test_12_wrong_same_cell_identity_rejected(self):
        f=self.f;a,v=bind_r8_r6(f)
        obs=Observation('DIFFERENT_CELL',f['q'],(a.log10k_activity,),True,f['source_sha'])
        other=TeacherHead('CORE',obs,(f['q'],)+f['partner_ids'],f['partner_ids']+f['ref_ids'],True)
        st=StudentView(Observation(f['cell_key'],f['q'],(.1,),True,f['source_sha']),f['student_ids'],f['student_ids'],(),f['partner_ids']+f['ref_ids'])
        with self.assertRaises(ContractError):TeacherTargetPackage((other,),st,'ALLOW_TEACHER_Q_WITH_SCALAR_DIAGNOSTIC').validate()
    def test_13_teacher_q_excluded_policy_must_fail_if_q_visible(self):
        f=self.f;a,v=bind_r8_r6(f);o=Observation(f['cell_key'],f['q'],(a.log10k_activity,),True,f['source_sha'])
        t=TeacherHead('CORE',o,(f['q'],)+f['partner_ids'],f['partner_ids']+f['ref_ids'],True)
        s=StudentView(o,f['student_ids'],f['student_ids'],(),f['partner_ids']+f['ref_ids'])
        with self.assertRaises(ContractError):TeacherTargetPackage((t,),s,'TEACHER_Q_EXCLUDED').validate()
    def test_14_student_forbidden_target_set_cannot_omit_reference(self):
        f=self.f;a,v=bind_r8_r6(f);o=Observation(f['cell_key'],f['q'],(a.log10k_activity,),True,f['source_sha'])
        t=TeacherHead('CORE',o,(f['q'],)+f['partner_ids']+f['ref_ids'],f['partner_ids']+f['ref_ids'],True)
        s=StudentView(o,f['student_ids'],f['student_ids'],(),f['partner_ids'])
        with self.assertRaises(ContractError):TeacherTargetPackage((t,),s,'ALLOW_TEACHER_Q_WITH_SCALAR_DIAGNOSTIC').validate()
    def test_15_existing_topology_guard_checks_all_ema(self):
        x=Topology((Module('student','ONLINE_ENCODER',2,protected(2)),Module('teacher','EMA_TEACHER',2,protected(2)),Module('predictor','ONLINE_PREDICTOR',0,())),('student','predictor'),(('student','teacher'),))
        self.assertFalse(x.validate()['training_authorized'])
        y=dataclasses.replace(x,ema_pairs=())
        with self.assertRaises(ContractError):y.validate()

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(LiveAnticheatTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():sys.exit(1)
    f=LiveAnticheatTests.f
    print('R9_INTEGRATED_LOCAL_ANTICHEAT_PASS',json.dumps({'passed':result.testsRun,'failed':0,'source_root':ROOT,'cell':f['cell_key'],'donor':f['donor'],'query':f['q'],'program':PROGRAM,'training_authorized':False}))
