import unittest
import numpy as np
from jepa_r14_query_firewall import *
D=PreprocessingDeclaration(0,(1,2,3),(4,5),(6,7),True)
X=np.array([50,4,3,7,9,0,4,1,8,2])
class TestQueryFirewall(unittest.TestCase):
 def test_raw_query_mutation_keeps_every_student_feature_exact(self):
  a=assert_counterfactual_isolation(X,D,{0:250});self.assertEqual(a['status'],'COUNTERFACTUAL_UNCHANGED')
 def test_all_teacher_partner_changes_invariant(self):
  assert_counterfactual_isolation(X,D,{4:0,5:100})
 def test_all_teacher_reference_changes_invariant(self):
  assert_counterfactual_isolation(X,D,{6:0,7:250})
 def test_combined_forbidden_mutation_invariant(self):
  assert_counterfactual_isolation(X,D,{0:0,4:0,6:0,7:10000})
 def test_teacher_q_visible_only_when_policy_allows(self):
  self.assertEqual(make_teacher_context(X,D)['query_count'],50)
  blind=PreprocessingDeclaration(0,(1,2,3),(4,5),(6,7),False)
  self.assertIsNone(make_teacher_context(X,blind)['query_count'])
 def test_student_mutation_changes_feature_positive(self):
  y=X.copy();y[1]+=5;a=make_student_view(X,D);b=make_student_view(y,D)
  self.assertFalse(np.array_equal(a['tokens'],b['tokens']))
  self.assertNotEqual(a['view_library_size'],b['view_library_size'])
 def test_full_library_normalization_is_leaky_positive(self):
  self.assertTrue(demonstrate_bad_full_library_leak(X,D,250))
 def test_overlapping_student_query_refused(self):
  self.assertRaises(QueryLeakageError,make_student_view,X,PreprocessingDeclaration(0,(0,2,3),(4,5),(6,7)))
 def test_overlapping_teacher_student_refused(self):
  self.assertRaises(QueryLeakageError,make_student_view,X,PreprocessingDeclaration(0,(1,2,4),(4,5),(6,7)))
 def test_duplicate_within_student_refused(self):
  self.assertRaises(QueryLeakageError,make_student_view,X,PreprocessingDeclaration(0,(1,1,3),(4,5),(6,7)))
 def test_negative_and_fractional_counts_refused(self):
  y=X.astype(float);y[0]=-1;self.assertRaises(QueryLeakageError,make_student_view,y,D)
  y[0]=.5;self.assertRaises(QueryLeakageError,make_student_view,y,D)
 def test_no_student_library_support_refused(self):
  y=X.copy();y[1:4]=0;self.assertRaises(QueryLeakageError,make_student_view,y,D)
 def test_unpermitted_counterfactual_refused(self):
  self.assertRaises(QueryLeakageError,assert_counterfactual_isolation,X,D,{1:50})
 def test_mutation_actual_q_differs_in_teacher_not_student(self):
  y=X.copy();y[0]=100
  self.assertNotEqual(make_teacher_context(X,D)['query_count'],make_teacher_context(y,D)['query_count'])
  self.assertEqual(assert_counterfactual_isolation(X,D,{0:100})['status'],'COUNTERFACTUAL_UNCHANGED')
if __name__=='__main__':unittest.main()
