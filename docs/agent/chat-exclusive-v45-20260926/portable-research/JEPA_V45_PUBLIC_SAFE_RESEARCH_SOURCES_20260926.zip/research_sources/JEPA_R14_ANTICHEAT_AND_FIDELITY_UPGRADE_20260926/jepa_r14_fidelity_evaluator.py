"""R14 RESEARCH-ONLY synthetic-testable cross-modal fidelity evaluator.

Never opens protected real outcomes, authorizes training, authenticates external
provenance, or claims that synthetic checks establish biological validity.
Identical assay-derived RNA (not a deliberately impoverished PC summary) is the
primary linear benchmark. Teacher features are residualized against the full
RNA and technical matrix INSIDE EACH donor-held-out training fold.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import re
from typing import Sequence
import numpy as np
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge

class EvaluationBlocked(ValueError): pass

@dataclass(frozen=True)
class ResearchContract:
    teacher_sha256: str
    rna_panel_sha256: str
    atac_panel_sha256: str
    alpha: float = 10.0
    pca_width: int = 2
    teacher_residual_alpha: float = 1e-6
    teacher_input_assays: tuple[str, ...] = ('RNA',)
    student_training_authorized: bool = False
    endpoint_used_for_selection: bool = False
    real_outcome_opening_authorized: bool = False
    def validate(self):
        for val in (self.teacher_sha256,self.rna_panel_sha256,self.atac_panel_sha256):
            if not isinstance(val,str) or re.fullmatch(r'[0-9a-f]{64}',val) is None:
                raise EvaluationBlocked('exact SHA-256 lineage required')
        if self.teacher_input_assays != ('RNA',) or self.student_training_authorized is not False or self.endpoint_used_for_selection is not False or self.real_outcome_opening_authorized is not False:
            raise EvaluationBlocked('research contract must not authorize or consume real outcome')
        if not np.isfinite(self.alpha) or self.alpha<=0 or not np.isfinite(self.teacher_residual_alpha) or self.teacher_residual_alpha<=0 or type(self.pca_width) is not int or self.pca_width<1:
            raise EvaluationBlocked('invalid frozen numerical protocol')


def run_synthetic_only(*, rna, atac, teacher, nuisance, donors:Sequence[str], rna_ids:Sequence[str], atac_ids:Sequence[str], contract:ResearchContract, synthetic_lineage_token:str):
    """Accept synthetic arrays only; caller's token is a tripwire, NOT attestation.

    Real-data implementation MUST be separate and governed by an independently
    issued provenance/outcome permission—not a `synthetic=False` escape hatch.
    """
    contract.validate()
    if synthetic_lineage_token != 'SYNTHETIC_DELIBERATELY_GENERATED_R14':
        raise EvaluationBlocked('only deliberately generated fixtures are permitted')
    arrays=[np.asarray(a,dtype=np.float64) for a in (rna,atac,teacher,nuisance)]
    if any(a.ndim!=2 or a.shape[1]<1 or not np.isfinite(a).all() for a in arrays):
        raise EvaluationBlocked('nonfinite, empty or malformed matrix')
    x,y,z,t=arrays;n=len(x)
    if n<8 or any(len(a)!=n for a in arrays) or any(len(v)!=n for v in (donors,rna_ids,atac_ids)):
        raise EvaluationBlocked('row count mismatch')
    if len(set(rna_ids))!=n or list(rna_ids)!=list(atac_ids):
        raise EvaluationBlocked('unmatched or duplicate paired nucleus ID')
    if any(not isinstance(d,str) or not d for d in donors):
        raise EvaluationBlocked('missing donor')
    d=np.asarray(donors,dtype=str);ud=np.unique(d)
    if len(ud)<4 or contract.pca_width>min(x.shape[1],min(int(np.sum(d!=k))-1 for k in ud)):
        raise EvaluationBlocked('invalid independent donor count or PCA width')
    if x.shape[1]+t.shape[1]>=min(int(np.sum(d!=k))-1 for k in ud):
        raise EvaluationBlocked('full-RNA readout underdetermined: freeze an RNA feature panel on separate developmental data; do not silently substitute PCA or use an interpolating residualizer')
    arms=('technical','pca_rna','full_rna','teacher_only','teacher_plus_pca','teacher_plus_full_rna_unadjusted','teacher_plus_full_rna_residual')
    out=[]
    for donor in ud:
        tr=d!=donor;te=~tr
        def standardize(a):
            mean=a[tr].mean(axis=0);sd=a[tr].std(axis=0);sd[sd<1e-9]=1
            return (a[tr]-mean)/sd,(a[te]-mean)/sd
        xtr,xte=standardize(x);ttr,tte=standardize(t);ztr,zte=standardize(z)
        pca=PCA(n_components=contract.pca_width,svd_solver='full')
        pxtr=pca.fit_transform(xtr);pxte=pca.transform(xte)
        base_tr=np.c_[ttr,xtr];base_te=np.c_[tte,xte]
        # Residualizer does not look at test donors or ATAC. Tiny ridge stabilizes
        # rank-deficient RNA; residual prediction is applied to test RNA as well.
        res_model=Ridge(alpha=contract.teacher_residual_alpha,fit_intercept=True).fit(base_tr,ztr)
        rztr=ztr-np.asarray(res_model.predict(base_tr)).reshape(ztr.shape)
        rzte=zte-np.asarray(res_model.predict(base_te)).reshape(zte.shape)
        # A duplicate RNA feature has a zero training residual. Refuse a
        # meaningless 'increment' due to numerical noise or ridge penalty drift.
        if np.max(np.abs(rztr))<1e-8:
            rztr=np.zeros_like(rztr);rzte=np.zeros_like(rzte)
        feats={
           'technical':(ttr,tte),
           'pca_rna':(np.c_[ttr,pxtr],np.c_[tte,pxte]),
           'full_rna':(base_tr,base_te),
           'teacher_only':(np.c_[ttr,ztr],np.c_[tte,zte]),
           'teacher_plus_pca':(np.c_[ttr,pxtr,ztr],np.c_[tte,pxte,zte]),
           'teacher_plus_full_rna_unadjusted':(np.c_[base_tr,ztr],np.c_[base_te,zte]),
           'teacher_plus_full_rna_residual':(np.c_[base_tr,rztr],np.c_[base_te,rzte])
        }
        mu=y[tr].mean(axis=0);denom=float(np.square(y[te]-mu).sum())
        if denom<=1e-12:raise EvaluationBlocked('unscorable donor must not silently drop')
        scores={}
        for name,(train,test) in feats.items():
            p=np.asarray(Ridge(alpha=contract.alpha).fit(train,y[tr]).predict(test)).reshape(y[te].shape)
            scores[name]=float(1-np.square(y[te]-p).sum()/denom)
        out.append({'donor':str(donor),'n_nuclei':int(sum(te)),'scores':scores,
                    'increment_unadjusted':scores['teacher_plus_full_rna_unadjusted']-scores['full_rna'],
                    'increment_residualized':scores['teacher_plus_full_rna_residual']-scores['full_rna'],
                    'increment_vs_pca':scores['teacher_plus_pca']-scores['pca_rna']})
    mean=lambda key:float(np.mean([fold[key] for fold in out]))
    return {'scope':'SYNTHETIC_ONLY_NO_REAL_ATAC_PERMISSION','n_donors':len(ud),'n_nuclei':n,'folds':out,
            'donor_equal_score':{a:float(np.mean([o['scores'][a] for o in out])) for a in arms},
            'mean_increment_vs_pca':mean('increment_vs_pca'),
            'mean_increment_unadjusted':mean('increment_unadjusted'),
            'mean_increment_residualized':mean('increment_residualized'),
            'training_authorized':False,'biologically_validated':False}
