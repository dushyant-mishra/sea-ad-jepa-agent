import unittest
import numpy as np
from jepa_r14_fidelity_evaluator import ResearchContract,run_synthetic_only,EvaluationBlocked
C=ResearchContract('a'*64,'b'*64,'c'*64,alpha=10,pca_width=2)

def fixture(kind,seed=7):
    rng=np.random.default_rng(seed);nd=8;k=16;n=nd*k
    donors=[f'D{i}' for i in range(nd) for _ in range(k)]
    ids=[f'{donor}:N{j}' for donor in [f'D{i}' for i in range(nd)] for j in range(k)]
    # Seven visible RNA features. PCA2 discards x[6] on purpose by large variance
    # in the first two coordinates. Full linear regression can still access x[6].
    x=rng.normal(size=(n,7));x[:,:2]*=12
    nuisance=rng.normal(size=(n,1))
    if kind=='nonlinear':
        program=x[:,3]*x[:,4];z=np.c_[program,x[:,3]+x[:,4]];y=program+0.1*rng.normal(size=n)
    elif kind=='linear_sham':
        z=x[:,6:7].copy();y=1.5*x[:,6]+0.12*rng.normal(size=n)
    elif kind=='linear_hidden_by_pca':
        z=x[:,6:7].copy();y=2.0*x[:,6]+0.1*rng.normal(size=n)
    elif kind=='nuisance_sham':
        z=nuisance.copy();y=nuisance[:,0]+0.1*rng.normal(size=n)
    else:raise ValueError(kind)
    return dict(rna=x,atac=y[:,None],teacher=z,nuisance=nuisance,donors=donors,rna_ids=ids,atac_ids=ids,contract=C,synthetic_lineage_token='SYNTHETIC_DELIBERATELY_GENERATED_R14')

class TestR14(unittest.TestCase):
    def test_real_without_synthetic_token_refused(self):
        a=fixture('nonlinear');a['synthetic_lineage_token']='REAL_ATAC';self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_fake_real_permission_refused(self):
        a=fixture('nonlinear');a['contract']=ResearchContract('a'*64,'b'*64,'c'*64,real_outcome_opening_authorized=True)
        self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_planted_nonlinear_representation_survives_full_rna(self):
        z=run_synthetic_only(**fixture('nonlinear'))
        self.assertGreater(z['mean_increment_residualized'],.25)
        self.assertEqual(z['n_donors'],8)
    def test_duplicate_rna_teacher_has_no_residual_signal(self):
        z=run_synthetic_only(**fixture('linear_sham'))
        self.assertLess(abs(z['mean_increment_residualized']),1e-8)
    def test_pca_baseline_can_create_false_teacher_gain(self):
        z=run_synthetic_only(**fixture('linear_hidden_by_pca'))
        self.assertGreater(z['mean_increment_vs_pca'],.2)
        self.assertLess(abs(z['mean_increment_residualized']),1e-8)
    def test_unadjusted_duplicate_regularization_may_shift_score(self):
        z=run_synthetic_only(**fixture('linear_sham'))
        self.assertIsInstance(z['mean_increment_unadjusted'],float)
    def test_qc_copy_not_biology(self):
        z=run_synthetic_only(**fixture('nuisance_sham'))
        self.assertLess(abs(z['mean_increment_residualized']),1e-8)
    def test_wrong_same_donor_barcode_refused(self):
        a=fixture('nonlinear');a['atac_ids']=a['atac_ids'].copy();a['atac_ids'][0],a['atac_ids'][1]=a['atac_ids'][1],a['atac_ids'][0]
        self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_duplicate_id_refused(self):
        a=fixture('nonlinear');a['rna_ids']=a['rna_ids'].copy();a['rna_ids'][1]=a['rna_ids'][0]
        self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_donor_collapse_refused(self):
        a=fixture('nonlinear');a['donors']=['D0']*len(a['donors']);self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_nan_refused(self):
        a=fixture('nonlinear');a['teacher'][0,0]=np.nan;self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_training_authority_refused(self):
        a=fixture('nonlinear');a['contract']=ResearchContract('a'*64,'b'*64,'c'*64,student_training_authorized=True)
        self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_teacher_cannot_use_atac(self):
        a=fixture('nonlinear');a['contract']=ResearchContract('a'*64,'b'*64,'c'*64,teacher_input_assays=('RNA','ATAC'))
        self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_endpoint_posthoc_selection_refused(self):
        a=fixture('nonlinear');a['contract']=ResearchContract('a'*64,'b'*64,'c'*64,endpoint_used_for_selection=True)
        self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_underdetermined_full_rna_is_blocked(self):
        a=fixture('nonlinear');a['rna']=np.tile(a['rna'],(1,18))
        self.assertRaises(EvaluationBlocked,run_synthetic_only,**a)
    def test_two_dimensional_outcome(self):
        a=fixture('nonlinear');a['atac']=np.c_[a['atac'],a['atac']*2];z=run_synthetic_only(**a)
        self.assertGreater(z['mean_increment_residualized'],.25)
if __name__=='__main__':unittest.main()
