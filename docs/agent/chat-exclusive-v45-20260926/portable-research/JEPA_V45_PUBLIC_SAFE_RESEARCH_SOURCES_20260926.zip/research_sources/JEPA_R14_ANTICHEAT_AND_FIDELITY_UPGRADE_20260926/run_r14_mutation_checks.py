"""Executable mutation checks: planted invalid logic MUST fail real tests."""
from pathlib import Path
import subprocess, tempfile, shutil, os
ROOT=Path(__file__).resolve().parent
ENV={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
checks=[
 ('q_leaky_full_library', 'jepa_r14_query_firewall.py',
  's=float(c.sum())','s=float(x.sum())',
  'test_jepa_r14_query_firewall.TestQueryFirewall.test_raw_query_mutation_keeps_every_student_feature_exact'),
 ('q_allow_overlap', 'jepa_r14_query_firewall.py',
  "if other!=k and v&w:raise QueryLeakageError('forbidden overlapping molecular compartments')",
  'if False: raise QueryLeakageError("disabled")',
  'test_jepa_r14_query_firewall.TestQueryFirewall.test_overlapping_student_query_refused'),
 ('residualization_disabled', 'jepa_r14_fidelity_evaluator.py',
  'rztr=ztr-np.asarray(res_model.predict(base_tr)).reshape(ztr.shape)',
  'rztr=ztr.copy()',
  'test_jepa_r14_fidelity_evaluator.TestR14.test_duplicate_rna_teacher_has_no_residual_signal'),
]
for label,name,old,new,test in checks:
 with tempfile.TemporaryDirectory() as d:
  for f in ('jepa_r14_query_firewall.py','jepa_r14_fidelity_evaluator.py','test_jepa_r14_query_firewall.py','test_jepa_r14_fidelity_evaluator.py'):
   shutil.copy2(ROOT/f,Path(d)/f)
  path=Path(d)/name;s=path.read_text();assert s.count(old)==1,label;path.write_text(s.replace(old,new))
  # For a residualization break mutate both train and test to keep shape and meaning aligned.
  if label=='residualization_disabled':
   s=path.read_text();old2='rzte=zte-np.asarray(res_model.predict(base_te)).reshape(zte.shape)';assert s.count(old2)==1
   path.write_text(s.replace(old2,'rzte=zte.copy()'))
  p=subprocess.run(['python','-m','unittest','-q',test],cwd=d,env=ENV,text=True,capture_output=True)
  if p.returncode==0:raise AssertionError('MUTATION ESCAPED: '+label)
  print('MUTATION_CAUGHT',label,'returncode',p.returncode,'failure_signature',next((x for x in p.stderr.splitlines() if 'AssertionError:' in x or 'QueryLeakageError:' in x),'other refusal'))
print('ALL_MUTATION_CONTROLS_FIRED')
