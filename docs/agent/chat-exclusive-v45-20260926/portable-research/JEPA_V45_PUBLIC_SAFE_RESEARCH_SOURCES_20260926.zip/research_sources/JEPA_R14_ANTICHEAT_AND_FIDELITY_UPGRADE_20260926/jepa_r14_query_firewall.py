"""Research-only query-safe raw RNA student preprocessing and executable counterfactual.

Input is ONE ORIGINAL RAW COUNT VECTOR. All derived QC and normalization for
student must be computed solely from declared student indices BEFORE any
per-source full-library normalization. No biological validation or V5 training
permission follows from passing this narrow test.
"""
from dataclasses import dataclass
import hashlib
import json
import numpy as np

class QueryLeakageError(ValueError): pass

@dataclass(frozen=True)
class PreprocessingDeclaration:
    query_index:int
    student_indices:tuple[int,...]
    teacher_partner_indices:tuple[int,...]
    teacher_reference_indices:tuple[int,...]
    allow_teacher_query_value:bool=False

    def validate(self,n_features:int):
        sets={'query':{self.query_index},'student':set(self.student_indices),'partner':set(self.teacher_partner_indices),'reference':set(self.teacher_reference_indices)}
        if any(type(i) is not int or i<0 or i>=n_features for s in (self.student_indices,self.teacher_partner_indices,self.teacher_reference_indices) for i in s) or type(self.query_index) is not int or self.query_index<0 or self.query_index>=n_features:
            raise QueryLeakageError('noncanonical indices')
        if any(not v for v in sets.values()):raise QueryLeakageError('all declared compartments required')
        if any(len(getattr(self,key+'_indices'))!=len(sets[{'student':'student','teacher_partner':'partner','teacher_reference':'reference'}[key]]) for key in ('student','teacher_partner','teacher_reference')):
            raise QueryLeakageError('duplicate index')
        for k,v in sets.items():
            for other,w in sets.items():
                if other!=k and v&w:raise QueryLeakageError('forbidden overlapping molecular compartments')
        if type(self.allow_teacher_query_value) is not bool:raise QueryLeakageError('invalid teacher q policy')


def raw_count_vector(v):
    a=np.asarray(v)
    if a.ndim!=1 or a.size==0 or not np.issubdtype(a.dtype,np.number) or not np.isfinite(a).all() or (a<0).any() or not np.array_equal(a,np.rint(a)):
        raise QueryLeakageError('raw counts must be a finite nonnegative integral vector')
    if np.any(a>np.iinfo(np.int64).max):raise QueryLeakageError('count overflow')
    return a.astype(np.int64)


def make_student_view(raw,declaration:PreprocessingDeclaration):
    x=raw_count_vector(raw);declaration.validate(len(x))
    c=x[list(declaration.student_indices)].astype(float)
    s=float(c.sum())
    if s<=0:raise QueryLeakageError('no student-library support: abstain')
    # Both token representation and QC depend only on the same permitted genes.
    normalized=np.log1p(1e4*c/s)
    out={'tokens':normalized,'view_library_size':s,'view_log_library_size':float(np.log1p(s)),
         'view_detection_fraction':float(np.mean(c>0)),
         'view_mean_raw_count':float(np.mean(c)),
         'view_max_raw_count':float(c.max()),
         'n_visible_genes':int(c.size)}
    if any(not np.isfinite(val).all() for val in out.values()):raise QueryLeakageError('nonfinite student feature')
    return out


def make_teacher_context(raw,declaration:PreprocessingDeclaration):
    x=raw_count_vector(raw);declaration.validate(len(x))
    return {'query_identity':declaration.query_index,
            'query_count':int(x[declaration.query_index]) if declaration.allow_teacher_query_value else None,
            'partner_counts':x[list(declaration.teacher_partner_indices)].copy(),
            'reference_counts':x[list(declaration.teacher_reference_indices)].copy()}


def assert_counterfactual_isolation(raw,declaration:PreprocessingDeclaration,changes:dict[int,int]):
    original=raw_count_vector(raw);declaration.validate(len(original))
    forbidden={declaration.query_index,*declaration.teacher_partner_indices,*declaration.teacher_reference_indices}
    if not changes or any(type(i) is not int or i not in forbidden or type(value) is not int or value<0 for i,value in changes.items()):
        raise QueryLeakageError('counterfactual must only modify forbidden raw counts')
    altered=original.copy()
    for i,value in changes.items():altered[i]=value
    before=make_student_view(original,declaration);after=make_student_view(altered,declaration)
    for key in before:
        a,b=np.asarray(before[key]),np.asarray(after[key])
        if a.shape!=b.shape or not np.array_equal(a,b):
            raise QueryLeakageError('forbidden raw mutation changes student feature: '+key)
    return {'status':'COUNTERFACTUAL_UNCHANGED','changed_forbidden_indices':sorted(changes),
            'teacher_query_count_changed':declaration.query_index in changes,
            'student_view_hash':hashlib.sha256(json.dumps({k:np.asarray(v).tolist() for k,v in before.items()},sort_keys=True).encode()).hexdigest()}


def demonstrate_bad_full_library_leak(raw,declaration,query_new):
    x=raw_count_vector(raw);declaration.validate(len(x))
    y=x.copy();y[declaration.query_index]=query_new
    # This is the KNOWN-UNSAFE comparator, never a candidate preprocess path.
    a=x[list(declaration.student_indices)];b=y[list(declaration.student_indices)]
    u=np.log1p(1e4*a/x.sum());v=np.log1p(1e4*b/y.sum())
    return bool(np.any(u!=v))
