import unittest
import numpy as np
from jepa_r13_paired_multiome_evaluator import FrozenEvaluation,evaluate_paired_nuclei,BiologicalEvaluationError
H='a'*64
C=FrozenEvaluation('SYNTHETIC_GENERATED_ONLY',H,'b'*64,'c'*64,pca_components=2,alpha=10.0)

def fixture(with_nonlinear=True):
    rng=np.random.default_rng(20260926)
    d=15;k=60;n=d*k
    donors=[f'D{i:02}' for i in range(d) for _ in range(k)]
    ids=[f'D{i:02}:N{j:03}' for i in range(d) for j in range(k)]
    # Nonlinear RNA program accessible to a teacher (RNA-only), missed by a linear RNA readout.
    x=rng.normal(size=(n,2))
    donor_shift=np.repeat(rng.normal(size=d),k)
    prog=x[:,0]*x[:,1]
    noise=rng.normal(size=n)
    z=np.c_[prog, x[:,0]+x[:,1]] if with_nonlinear else x.copy()
    y=(prog+0.04*donor_shift+0.10*noise).reshape(-1,1)
    t=donor_shift.reshape(-1,1)
    return dict(rna=x,atac_endpoint=y,teacher_state=z,nuisance=t,donor_keys=donors,rna_cell_ids=ids,atac_cell_ids=ids,contract=C,synthetic_fixture=True)

class PairedBenchmark(unittest.TestCase):
    def test_real_outcome_blocked_by_default(self):
        a=fixture();a['synthetic_fixture']=False
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_synthetic_nonlinear_teacher_adds_information(self):
        z=evaluate_paired_nuclei(**fixture())
        self.assertEqual(z['n_independent_donors'],15)
        self.assertEqual(z['n_nuclei'],900)
        self.assertGreater(z['mean_teacher_increment'],.25)
        self.assertGreater(z['donor_mean_r2']['teacher_state'],z['donor_mean_r2']['same_RNA_linear'])
    def test_linear_teacher_no_large_increment(self):
        z=evaluate_paired_nuclei(**fixture(False))
        self.assertLess(z['mean_teacher_increment'],.10)
    def test_false_same_donor_cross_cell_pair_refused(self):
        a=fixture(); a['atac_cell_ids']=a['atac_cell_ids'].copy()
        a['atac_cell_ids'][0],a['atac_cell_ids'][1]=a['atac_cell_ids'][1],a['atac_cell_ids'][0]
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_duplicate_cell_rejected(self):
        a=fixture(); a['atac_cell_ids']=a['atac_cell_ids'].copy();a['atac_cell_ids'][1]=a['atac_cell_ids'][0]
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_bad_digest_rejected(self):
        a=fixture();a['contract']=FrozenEvaluation('s','not-a-hash',H,H)
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_missing_donor_rejected(self):
        a=fixture();a['donor_keys']=a['donor_keys'][:-1]
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_insufficient_donor_rejected(self):
        a=fixture();a['donor_keys']=['D1']*len(a['donor_keys'])
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_no_atac_teacher_input(self):
        a=fixture();a["contract"]=FrozenEvaluation("SYNTHETIC_GENERATED_ONLY",H,H,H,teacher_input_assays=("RNA","ATAC"))
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_no_posthoc_selection(self):
        a=fixture();a["contract"]=FrozenEvaluation("SYNTHETIC_GENERATED_ONLY",H,H,H,endpoint_used_for_selection=True)
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_no_synthetic_bypass_for_real_tag(self):
        a=fixture();a["contract"]=FrozenEvaluation("real_external_data",H,H,H)
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
    def test_multioutput_shape_no_broadcast(self):
        a=fixture();v=a["atac_endpoint"];a["atac_endpoint"]=np.c_[v,2*v]
        z=evaluate_paired_nuclei(**a)
        self.assertGreater(z["donor_mean_r2"]["teacher_state"],.9)
    def test_no_training_authority(self):
        a=fixture();a['contract']=FrozenEvaluation('s',H,H,H,student_training_authorized=True)
        self.assertRaises(BiologicalEvaluationError,evaluate_paired_nuclei,**a)
if __name__=='__main__':unittest.main()
