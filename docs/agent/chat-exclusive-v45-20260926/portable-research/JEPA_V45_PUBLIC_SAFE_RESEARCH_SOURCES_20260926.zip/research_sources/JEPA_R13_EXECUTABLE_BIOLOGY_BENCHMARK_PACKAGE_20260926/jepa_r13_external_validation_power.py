"""Outcome-blind R13 power sensitivity. NO biological data read, NO authority.

Paired donor-level standardized delta (JEPA minus same-RNA linear baseline).
Analytic noncentral-t power is an optimistic upper bound for complex LODO,
correlated genomic endpoints, subtype rarity or leakage; not design approval.
"""
from __future__ import annotations
import json
import math
from pathlib import Path
from scipy.stats import t as student_t, nct
from scipy.optimize import brentq


def paired_t_power(n_donors: int, standardized_effect: float, alpha: float = 0.05) -> float:
    if type(n_donors) is not int or n_donors < 3:
        raise ValueError('n_donors must be integer >=3')
    if not (0 < alpha < 1) or standardized_effect < 0:
        raise ValueError('invalid alpha or effect')
    df = n_donors - 1
    threshold = student_t.ppf(1-alpha/2, df)
    ncp = standardized_effect * n_donors ** 0.5
    right = float(nct.sf(threshold, df, ncp))
    left = float(nct.cdf(-threshold, df, ncp))
    # SciPy nct may return NaN on the astronomically small opposite tail.
    # For nonnegative large shifts, use the equivalent upper tail at -ncp;
    # if both fail while the positive power already exceeds .5, bound by 0.
    if math.isnan(left):
        left = float(nct.sf(threshold, df, -ncp))
        if math.isnan(left) and right > .5 and ncp > threshold:
            left = 0.0
    if math.isnan(left) or math.isnan(right):
        raise ArithmeticError("noncentral-t distribution evaluation failed")
    return float(min(1.0, right + left))


def effect_for_80pct_power(n_donors: int, alpha: float = .05) -> float:
    return float(brentq(lambda d:paired_t_power(n_donors,d,alpha)-.8,0,5))


def build():
    cohorts=[
        {'cohort':'Morabito GSE174367', 'n_donors':18,'assay':'unpaired RNA/ATAC; donor-level only','role':'SECONDARY_CONTAMINATION_REVIEW_REQUIRED'},
        {'cohort':'Anderson GSE214637/GSE214979', 'n_donors':15,'assay':'reported matched snMultiome; exact accession role verify','role':'CANDIDATE_INDEPENDENT_PAIRED_BIOLOGY'},
        {'cohort':'GSE272082', 'n_donors':9,'assay':'reported paired snMultiome; 3 brain regions','role':'CANDIDATE_REPLICATION_ONLY_SMALL_N'},
    ]
    for c in cohorts:
        n=c['n_donors']
        c['minimal_standardized_effect_80pct_power_optimistic']={
            'single_two_sided_0p05':round(effect_for_80pct_power(n,.05),3),
            'three_primary_contrasts_bonf_0p0167':round(effect_for_80pct_power(n,.05/3),3),
            'six_primary_contrasts_bonf_0p0083':round(effect_for_80pct_power(n,.05/6),3),
        }
        c['power_for_standardized_effect_0p5']={k:round(paired_t_power(n,.5,a),3) for k,a in [('single',.05),('three',.05/3),('six',.05/6)]}
    return {'kind':'R13_PROSPECTIVE_SENSITIVITY_ONLY_NO_ATAC_VALUES',
            'analysis':'idealized paired-donor t-test of one predeclared delta; assumes iid Gaussian donor contrasts, no nested model selection, no multi-gene dependence',
            'source':'public cohort publications/GEO; cohort eligibility, available cell counts per donor and historical reuse NOT independently qualified',
            'cohorts':cohorts,'extended_donor_sensitivity':[{'n_donors':n,'single_alpha_0p05_d80':round(effect_for_80pct_power(n,.05),3),'six_contrasts_d80':round(effect_for_80pct_power(n,.05/6),3)} for n in (9,15,18,30,50,80)],
            'not_authorized':{'architecture_selection':True,'atac_outcome_inspection':True,'production_training':True}}

if __name__=='__main__':
    p=Path(__file__).with_name('JEPA_R13_OUTCOME_BLIND_POWER_SENSITIVITY_20260926.json')
    p.write_text(json.dumps(build(),indent=2)+'\n')
    print(json.dumps(build()['cohorts'],indent=2))
