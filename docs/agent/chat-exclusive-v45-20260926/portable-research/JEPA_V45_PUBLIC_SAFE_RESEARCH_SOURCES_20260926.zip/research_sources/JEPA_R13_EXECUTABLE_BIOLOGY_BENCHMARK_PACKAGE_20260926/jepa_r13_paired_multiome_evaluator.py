"""R13 read-only paired-multiome teacher fidelity evaluator.

ONLY accepts true per-nucleus paired RNA, ATAC, and a FROZEN precomputed
RNA-only teacher state; donor disjoint leave-one-donor-out. Outcomes may be
passed only after independent preregistration and data-provenance approval.
This module is presently tested with SYNTHETIC generated data only.
It never fits a teacher, selects a gene/peak panel or authorizes execution.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.decomposition import PCA

class BiologicalEvaluationError(ValueError): pass

@dataclass(frozen=True)
class FrozenEvaluation:
    source_tag: str
    frozen_teacher_digest: str
    endpoint_gene_panel_digest: str
    endpoint_peak_panel_digest: str
    independent_provenance_approved: bool = False
    outcome_opening_approved: bool = False
    student_training_authorized: bool = False
    alpha: float = 10.0
    pca_components: int = 2
    teacher_input_assays: tuple[str, ...] = ("RNA",)
    teacher_state_frozen: bool = True
    endpoint_used_for_selection: bool = False
    def validate(self):
        import re
        if any(not re.fullmatch('[0-9a-f]{64}',s) for s in (self.frozen_teacher_digest,self.endpoint_gene_panel_digest,self.endpoint_peak_panel_digest)):
            raise BiologicalEvaluationError('sources/target/readout digests must be exact SHA-256')
        if self.student_training_authorized is not False:
            raise BiologicalEvaluationError('evaluation cannot authorize training')
        if self.teacher_input_assays != ('RNA',) or self.teacher_state_frozen is not True or self.endpoint_used_for_selection is not False:
            raise BiologicalEvaluationError('teacher may not access ATAC or use heldout endpoint for selection')
        if self.pca_components < 1 or self.alpha <= 0:
            raise BiologicalEvaluationError('predeclared alpha and PCA dimensions required')
        if not self.source_tag.strip():
            raise BiologicalEvaluationError('source required')
        return True


def evaluate_paired_nuclei(*,rna, atac_endpoint, teacher_state, nuisance, donor_keys: Sequence[str],
                          rna_cell_ids: Sequence[str], atac_cell_ids: Sequence[str],
                          contract: FrozenEvaluation, synthetic_fixture: bool=False):
    contract.validate()
    if synthetic_fixture and (contract.source_tag != 'SYNTHETIC_GENERATED_ONLY' or contract.independent_provenance_approved or contract.outcome_opening_approved):
        raise BiologicalEvaluationError('synthetic fixture cannot impersonate a real evaluation')
    if not synthetic_fixture and not (contract.independent_provenance_approved and contract.outcome_opening_approved):
        raise BiologicalEvaluationError('reserved actual endpoint cannot be opened under research preflight')
    x,y,z,t=(np.asarray(a,dtype=np.float64) for a in (rna,atac_endpoint,teacher_state,nuisance))
    if any(a.ndim!=2 or not np.all(np.isfinite(a)) for a in (x,y,z,t)):
        raise BiologicalEvaluationError('all matrices must be finite two-dimensional')
    n=x.shape[0]
    if n<5 or any(a.shape[0]!=n or a.shape[1]==0 for a in (x,y,z,t)):
        raise BiologicalEvaluationError('incomplete matrix rows or empty view')
    if len(donor_keys)!=n or len(rna_cell_ids)!=n or len(atac_cell_ids)!=n:
        raise BiologicalEvaluationError('donor/cell metadata shape mismatch')
    if any(not isinstance(d,str) or not d for d in donor_keys):
        raise BiologicalEvaluationError('all donor keys must be nonempty strings')
    if len(set(rna_cell_ids))!=n or len(set(atac_cell_ids))!=n or list(rna_cell_ids)!=list(atac_cell_ids):
        raise BiologicalEvaluationError('nucleus identity not exact one-to-one RNA/ATAC paired; donor-only pairing forbidden')
    donors=np.asarray(donor_keys,dtype=str)
    unique=np.unique(donors)
    if len(unique)<4:
        raise BiologicalEvaluationError('too few independent donors')
    if np.any(~np.isfinite(y)):
        raise BiologicalEvaluationError('nonfinite or unmeasured target')
    # Predetermined PCA width; PCA, scales, ridge and outcome means train-fitted on each fold only.
    if contract.pca_components> x.shape[1] or any(np.sum(donors!=d)<contract.pca_components+2 for d in unique):
        raise BiologicalEvaluationError('PCA width incompatible with available training nuclei')
    models=('technical','same_RNA_linear','teacher_state','teacher_plus_same_RNA')
    fold_metrics=[]
    for d in unique:
        tr=donors!=d; te=~tr
        mu=x[tr].mean(axis=0); sd=x[tr].std(axis=0);sd[sd<1e-8]=1
        xt=(x-mu)/sd
        pca=PCA(n_components=contract.pca_components,svd_solver='full')
        xr=pca.fit_transform(xt[tr]); xe=pca.transform(xt[te])
        # Evaluation-only outcome-nuisance variables must be present for every arm.
        tm=t[tr].mean(axis=0);ts=t[tr].std(axis=0);ts[ts<1e-8]=1
        tt=(t-tm)/ts
        zm=z[tr].mean(axis=0);zs=z[tr].std(axis=0);zs[zs<1e-8]=1
        zz=(z-zm)/zs
        ft={'technical':(tt[tr],tt[te]),
            'same_RNA_linear':(np.c_[tt[tr],xr],np.c_[tt[te],xe]),
            'teacher_state':(np.c_[tt[tr],zz[tr]],np.c_[tt[te],zz[te]]),
            'teacher_plus_same_RNA':(np.c_[tt[tr],zz[tr],xr],np.c_[tt[te],zz[te],xe])}
        mean_y=y[tr].mean(axis=0)
        # Same train mean denominator for all models; report per-donor not per-cell sample size.
        denom=np.sum((y[te]-mean_y)**2)
        if denom<1e-10:continue
        scores={}
        for name,(train_features,test_features) in ft.items():
            model=Ridge(alpha=contract.alpha,fit_intercept=True)
            model.fit(train_features,y[tr]); pred=np.asarray(model.predict(test_features)).reshape(y[te].shape)
            scores[name]=float(1-np.sum((y[te]-pred)**2)/denom)
        fold_metrics.append({'donor':str(d),'n_nuclei':int(sum(te)),'scores':scores,
                             'teacher_increment_over_same_RNA':scores['teacher_plus_same_RNA']-scores['same_RNA_linear']})
    if len(fold_metrics)!=len(unique):
        raise BiologicalEvaluationError('missing or unscorable donor; must not silently drop')
    return {'scope':'SYNTHETIC_FIXTURE_ONLY' if synthetic_fixture else 'REQUIRES_APPROVED_FROZEN_BENCHMARK',
            'n_independent_donors':len(unique),'n_nuclei':n,'folds':fold_metrics,
            'donor_mean_r2':{name:float(np.mean([f['scores'][name] for f in fold_metrics])) for name in models},
            'mean_teacher_increment':float(np.mean([f['teacher_increment_over_same_RNA'] for f in fold_metrics])),
            'not_causal':True,'not_production_authority':True}
