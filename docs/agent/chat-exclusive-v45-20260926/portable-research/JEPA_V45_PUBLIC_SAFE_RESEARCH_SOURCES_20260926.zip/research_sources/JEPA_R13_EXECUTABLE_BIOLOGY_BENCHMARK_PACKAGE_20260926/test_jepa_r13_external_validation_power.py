import unittest
import numpy as np
from scipy.stats import t as student_t
from jepa_r13_external_validation_power import paired_t_power, effect_for_80pct_power, build

class ProspectivePower(unittest.TestCase):
    def test_null_two_sided_is_alpha(self):
        for n in (9,15,18,30):
            self.assertAlmostEqual(paired_t_power(n,0,.05),.05,places=10)
    def test_d80(self):
        for n in (9,15,18,30,50,80):
            d=effect_for_80pct_power(n,.05/6)
            self.assertAlmostEqual(paired_t_power(n,d,.05/6),.8,places=6)
    def test_monotonic_n(self):
        self.assertLess(effect_for_80pct_power(18),effect_for_80pct_power(9))
    def test_multiplicity_penalty(self):
        self.assertGreater(effect_for_80pct_power(18,.05/6),effect_for_80pct_power(18,.05))
    def test_fake_donor_duplication_changes_answer_and_is_disallowed(self):
        from jepa_r13_external_validation_power import paired_t_power
        self.assertNotAlmostEqual(paired_t_power(18,.5),paired_t_power(180,.5))
        self.assertRaises(ValueError,paired_t_power,18.0,.5)
    def test_negative_input(self):
        for args in ((2,.5,.05),(18,-.1,.05),(18,.5,0),(18,.5,1)):
            self.assertRaises(ValueError,paired_t_power,*args)
    def test_monte_carlo_cross_check(self):
        rng=np.random.default_rng(20260926)
        n=18; d=.75; m=20000; alpha=.05
        # null/effect distribution of independent DONOR-level contrasts only
        x=rng.normal(d,1,size=(m,n))
        tstat=x.mean(axis=1)/(x.std(axis=1,ddof=1)/np.sqrt(n))
        empirical=np.mean(abs(tstat)>student_t.ppf(1-alpha/2,n-1))
        self.assertLess(abs(empirical-paired_t_power(n,d,alpha)),.025)
    def test_no_outcomes_in_results(self):
        d=build()
        self.assertTrue(d['not_authorized']['atac_outcome_inspection'])
        self.assertEqual(len(d['cohorts']),3)
        self.assertTrue(all(c['n_donors'] in (9,15,18) for c in d['cohorts']))
if __name__=='__main__':unittest.main()
