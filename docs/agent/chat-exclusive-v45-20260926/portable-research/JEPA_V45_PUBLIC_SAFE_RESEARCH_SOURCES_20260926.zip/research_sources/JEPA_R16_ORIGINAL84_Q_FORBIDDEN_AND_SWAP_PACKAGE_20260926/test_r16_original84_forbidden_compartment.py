"""Positive, negative, replay and deliberate-unsafe tests on authenticated historical evidence."""
from __future__ import annotations
import json, math, sys, unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import r16_original84_forbidden_compartment as R

class R16Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.summary,cls.rows=R.run()
  cls.raw,cls.mask,cls.ops,cls.keys,cls.libs,cls.meta,cls.addr,cls.root,cls.views,cls.stored,cls.geom=R.load()

 def test_original_archive_digest(self):
  self.assertEqual(self.summary['source_archives']['calibration_zip_sha256'],R.CALIB_SHA)
 def test_historical_coverage(self):
  self.assertEqual(self.geom['n_original_cells'],84)
  self.assertEqual(self.geom['n_original_operators'],42)
  self.assertEqual(self.geom['n_operators_with_exactly_two_cells'],42)
 def test_matched_source_library(self):self.assertEqual(self.geom['n_joined_stable_keys'],84)
 def test_recovered_raw_integer_gate(self):self.assertLess(self.geom['max_count_integer_residual'],.001)
 def test_replay_original_logged_expression(self):self.assertLess(self.geom['max_log_reconstruction_residual'],3e-7)
 def test_exact_original_stored_view_semantics(self):
  self.assertTrue(np.array_equal(self.stored,np.where(self.views,0.,np.log1p(self.raw.astype(float)*10000/self.libs[:,None]).astype('float32')[:,None,:])))
 def test_three_original_programs(self):self.assertEqual(set(self.summary['program_results']),set(R.PROGS))
 def test_every_query_42_operators(self):
  for d in self.summary['program_results'].values():self.assertEqual(d['operators_with_q_interventions'],42)
 def test_every_query_336_real_mask_views(self):
  for d in self.summary['program_results'].values():self.assertEqual(d['stored_masked_views_physically_replayed'],336)
 def test_all_forbidden_q_safe(self):
  for d in self.summary['program_results'].values():self.assertEqual(d['all_forbidden_max_token_shift'],0.0)
 def test_q_only_q_safe(self):
  for prog,rows in self.rows.items():
   self.assertTrue(all(r['q_only_token_max']==0 for r in rows if r['intervention']=='q'))
 def test_q_only_leaks_hidden_panel_and_reference(self):
  for prog,rows in self.rows.items():
   self.assertTrue(any(r['q_only_token_max']>0 for r in rows if r['intervention']=='partner'))
   self.assertTrue(any(r['q_only_token_max']>0 for r in rows if r['intervention']=='reference'))
 def test_naive_full_library_leaks_q(self):
  for prog,rows in self.rows.items():
   self.assertTrue(any(r['full_source_token_max']>0 for r in rows if r['intervention']=='q'))
 def test_all_original_panel_support_states_recorded(self):
  self.assertEqual(sum(self.summary['program_results']['HLA-DRA']['anchor_status'].values()),84)
  self.assertEqual(self.summary['program_results']['HLA-DRA']['anchor_status']['UNMEASURED'],70)
 def test_zero_reference_not_silent_zero(self):
  self.assertEqual(self.summary['program_results']['APOE']['anchor_status']['REFERENCE_ZERO'],12)
 def test_inherited_r8_constructor_was_called(self):self.assertTrue(self.summary['inherited_r8_contract_physically_invoked'])
 def test_query_swap_same_cell_common_basis_exposes_normalization_artifact(self):
  swap=self.summary['query_swap_preprocessing_audit']['APOE__vs__P2RY12']
  self.assertEqual(swap['evaluated_cell_views'],336)
  self.assertGreater(swap['q_specific_tokens_change'],0)
  self.assertEqual(swap['q_specific_tokens_change'],swap['q_specific_denominators_differ'])
 def test_query_swap_common_union_removes_preprocessing_artifact(self):
  for item in self.summary['query_swap_preprocessing_audit'].values():
   self.assertEqual(item['excluded_common_addresses'],23)
   self.assertEqual(item['max_union_token_shift'],0.)
 def test_query_swap_abstains_when_target_unmeasured(self):
  swap=self.summary['query_swap_preprocessing_audit']['APOE__vs__HLA-DRA']
  self.assertLess(swap['target_eligible_cell_views'],swap['evaluated_cell_views'])
  self.assertEqual(swap['target_eligible_cell_views'],48)
 def test_planted_query_specific_denominator_fake_query_signal(self):
  row=np.array([7,11,5,3,8],dtype=np.int64);lib=100
  complement=np.array([3],dtype=np.int64)
  a=(0,1); b=(2,4)
  x=np.log1p(row[complement]*10000/(lib-row[list(a)].sum()))
  y=np.log1p(row[complement]*10000/(lib-row[list(b)].sum()))
  self.assertNotEqual(float(x[0]),float(y[0]))
  union=tuple(sorted(set(a+b)))
  ux=np.log1p(row[complement]*10000/(lib-row[list(union)].sum()))
  uy=np.log1p(row[complement]*10000/(lib-row[list(union)].sum()))
  self.assertTrue(np.array_equal(ux,uy))
 def test_training_authorization_off(self):
  self.assertIs(self.summary['training_authorized'],False)
  self.assertIs(self.summary['protected_outcomes_opened'],False)
 # Additional tiny planted mutations: the detector is demonstrably responsive.
 def test_planted_unsafe_total_is_detected(self):
  a=np.array([7,11,5,3],dtype=np.int64);m=np.ones(4,bool);f=(0,1,2)
  s=R.student_surface(a,m,100,f,'FULL_SOURCE')
  a[0]+=9
  z=R.student_surface(a,m,109,f,'FULL_SOURCE')
  self.assertGreater(R.diff(s,z)['tokens'],0)
 def test_planted_q_only_hidden_partner_leaks(self):
  a=np.array([7,11,5,3]);m=np.ones(4,bool);f=(0,1,2)
  s=R.student_surface(a,m,100,f,'Q_ONLY_EXCLUDED')
  a[1]+=9
  z=R.student_surface(a,m,109,f,'Q_ONLY_EXCLUDED')
  self.assertEqual(R.diff(s,z)['denominator'],9.)
  self.assertGreater(R.diff(s,z)['tokens'],0.)
 def test_planted_all_forbidden_hidden_partner_stays_zero(self):
  a=np.array([7,11,5,3]);m=np.ones(4,bool);f=(0,1,2)
  s=R.student_surface(a,m,100,f,'ALL_FORBIDDEN_EXCLUDED')
  a[1]+=9
  z=R.student_surface(a,m,109,f,'ALL_FORBIDDEN_EXCLUDED')
  self.assertEqual(max(R.diff(s,z).values()),0.)
 def test_zero_count_q_mutation(self):
  a=np.array([0,3,7,1]);m=np.ones(4,bool);f=(0,1,2)
  s=R.student_surface(a,m,50,f,'ALL_FORBIDDEN_EXCLUDED')
  a[0]+=1
  z=R.student_surface(a,m,51,f,'ALL_FORBIDDEN_EXCLUDED')
  self.assertEqual(max(R.diff(s,z).values()),0.)
 def test_stored_real_views_change_allowed_only(self):
  i=0; f=R.forbidden_addresses(self.addr,'APOE')
  for v in range(4):
   a=R.student_surface(self.raw[i],self.mask[i],int(self.libs[i]),f,'ALL_FORBIDDEN_EXCLUDED',self.views[i,v])
   b=self.raw[i].copy();b[f[0]]+=10
   z=R.student_surface(b,self.mask[i],int(self.libs[i])+10,f,'ALL_FORBIDDEN_EXCLUDED',self.views[i,v])
   self.assertEqual(max(R.diff(a,z).values()),0.)
 def test_false_source_root_refusal(self):
  # Do not silently substitute a decoy archive with the correct filename.
  self.assertNotEqual(self.summary['source_archives']['calibration_zip_sha256'],'e482d9da')
 def test_r8_target_status_consistent(self):
  from JEPA_R8_STRUCTURED_TARGET_CONTRACT_20260926 import Evidence,construct_measured_anchor
  i=0; f=R.forbidden_addresses(self.addr,'APOE')
  kw=dict(same_cell_key='original84-index0',donor_key='source-donor-index0',canonical_query=f[0],query_gene_symbol='APOE',partner_address_ids=tuple(f[1:5]),partner_raw_umi=tuple(int(self.raw[i,k]) for k in f[1:5]),disjoint_reference_address_ids=tuple(f[5:]),reference_raw_umi=tuple(int(self.raw[i,k]) for k in f[5:]),assay='RNA',correspondence='SAME_ORIGINAL_CELL',original_sha256=R.CALIB_SHA)
  obj=construct_measured_anchor(Evidence(**kw,teacher_queried_umi=int(self.raw[i,f[0]])),expected_source_sha256=R.CALIB_SHA)
  self.assertFalse(obj.scientifically_validated)

if __name__=='__main__':unittest.main(verbosity=2)
