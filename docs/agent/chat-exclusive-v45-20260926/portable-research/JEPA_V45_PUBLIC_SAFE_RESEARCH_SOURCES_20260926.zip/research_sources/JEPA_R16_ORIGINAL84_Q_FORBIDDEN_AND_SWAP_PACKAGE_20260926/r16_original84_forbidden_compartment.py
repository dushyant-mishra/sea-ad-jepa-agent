"""R16 original historical 84-cell count-recovery and forbidden-ancestor intervention.

Development-only, no FULL104 blocks, no training, no validation outcome.
Original 84-row log1p10K truth-table and original operator source-library
metadata are authenticated by exact parent archive SHA-256. The count recovery
is an independently checked *inverse* of stored log1p10k float32, not a claim
that unmounted raw Level4 blocks have been opened.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, math, os, zipfile
from pathlib import Path
import numpy as np
from JEPA_R8_STRUCTURED_TARGET_CONTRACT_20260926 import Evidence,construct_measured_anchor

CALIB_SHA='07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444'
EXPR_SHA=None  # exact digest is recorded at execution and original 84 rows cross-join by stable_key
HERE=Path(__file__).resolve().parent
CALIB=os.environ.get('JEPA_R16_CALIBRATION_ZIP','/mnt/data/FOUNDATION_CALIBRATION_BUNDLE_20260824.zip')
EXPR=os.environ.get('JEPA_R16_EXPRESSION_METADATA_ZIP','/mnt/data/expression.zip')
PROGS={
 'APOE': ('APOC1','ABCA1','GPNMB','TREM2'),
 'P2RY12': ('TMEM119','CX3CR1','GPR34','C1QA'),
 'HLA-DRA': ('CD74','HLA-DPA1','HLA-DMA','IFI30'),
}
REFS=('RPLP0','EEF1A1','PGK1','HPRT1','PPIA','RPL13A','GUSB','SDHA')

def digest_file(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''): h.update(chunk)
 return h.hexdigest()

def zip_member(z,suffix):
 match=[n for n in z.namelist() if n.endswith(suffix)]
 if len(match)!=1:raise AssertionError(f'member mismatch {suffix}: {match}')
 return match[0],z.read(match[0])

def load():
 assert digest_file(CALIB)==CALIB_SHA,'wrong original calibration archive'
 with zipfile.ZipFile(CALIB) as z:
  truth_name,data=zip_member(z,'/FOUNDATION_84_CELL_TRUTH_TABLE.npz')
  truth_sha=hashlib.sha256(data).hexdigest()
  a=np.load(io.BytesIO(data),allow_pickle=False)
  x=a['expression_log1p10k']; measured=a['measured_mask']; ops=a['operator_index']; keys=a['stable_key']
  views=a['hidden_mask']; stored_student=a['final_encoder_value_input']
  assert views.shape==(84,4,41238) and stored_student.shape==views.shape
  assert not np.any(views & ~measured[:,None,:])
  assert np.array_equal(stored_student,np.where(views,0.,x[:,None,:]))
  assert x.shape==(84,41238) and measured.shape==x.shape
  assert np.array_equal(np.unique(ops,return_counts=True)[1],np.full(42,2))
  _,registry=zip_member(z,'/address_namespace.csv')
  rows=list(csv.DictReader(io.StringIO(registry.decode('utf-8-sig'))))
  addr={r['symbol']:int(r['molecular_address_index']) for r in rows if r['symbol']}
 with zipfile.ZipFile(EXPR) as z:
  meta_files=sorted(n for n in z.namelist() if n.endswith('.meta.csv'))
  assert len(meta_files)==42
  meta={}
  for name in meta_files:
   for row in csv.DictReader(io.StringIO(z.read(name).decode('utf-8-sig'))):
    k=int(row['stable_key']); assert k not in meta
    meta[k]=row
 libs=[]
 for k in keys:
  r=meta[int(k)]; n=int(r['source_library']);assert n>0
  libs.append(n)
 libs=np.asarray(libs,dtype=np.int64)
 expanded=np.expm1(x.astype(np.float64))*libs[:,None]/10000.0
 residual=np.abs(expanded-np.rint(expanded))
 # Every nonzero entry must be demonstrably consistent with one integer UMI.
 assert np.max(residual)<0.001,'integer UMI recovery not supported'
 raw=np.rint(expanded).astype(np.int64)
 assert not np.any(raw[~measured]) and np.max(raw.sum(1)-libs)<=0
 backward=np.log1p(raw.astype(np.float64)*10000.0/libs[:,None])
 nonzero=(x>0)
 reerror=np.abs(backward[nonzero]-x[nonzero].astype('float64'))
 assert np.max(reerror)<3e-7,'recovered integer UMI fails original log comparison'
 return raw,measured,ops,keys,libs,meta,addr,truth_sha,views,stored_student,{
  'max_count_integer_residual':float(np.max(residual)),
  'max_log_reconstruction_residual':float(np.max(reerror)),
  'n_nonzero_entries':int(nonzero.sum()),'n_original_cells':84,
  'n_original_operators':42,'n_joined_stable_keys':84,
  'n_operators_with_exactly_two_cells':42,
 }

def forbidden_addresses(addr,prog):
 symbols=(prog,)+PROGS[prog]+REFS
 ids=tuple(addr[x] for x in symbols)
 assert len(set(ids))==13
 return ids

def student_surface(row,measured,lib,forbidden,denominator,extra_hidden=None):
 allowed=measured.copy();allowed[list(forbidden)]=False
 if extra_hidden is not None:allowed[np.asarray(extra_hidden,dtype=bool)]=False
 if denominator=='FULL_SOURCE': den=lib
 elif denominator=='Q_ONLY_EXCLUDED':den=lib-int(row[forbidden[0]])
 elif denominator=='ALL_FORBIDDEN_EXCLUDED':den=lib-int(row[list(forbidden)].sum())
 else:raise ValueError('unknown denominator')
 if den<1:raise ValueError('insufficient complement after exclusion')
 z=np.log1p(row[allowed].astype('float64')*10000.0/den)
 return {'tokens':z,'denominator':float(den),
   'qc_visible_total':int(row[allowed].sum()),'qc_visible_detected':int(np.count_nonzero(row[allowed])),
   'mean_token':float(z.mean()) if len(z) else 0.0,
   'max_token':float(z.max()) if len(z) else 0.0,
   'visible_support':allowed}

def diff(a,b):
 d={}
 for k in a:
  x,y=np.asarray(a[k]),np.asarray(b[k]); assert x.shape==y.shape
  d[k]=float(np.max(np.abs(x.astype('float64')-y.astype('float64')))) if x.size else 0.
 return d

def anchor(row,measured,forbidden):
 # Same R8 four-partner/eight-reference activity, conditional on measured support.
 partners=np.array(forbidden[1:5]);refs=np.array(forbidden[5:])
 if not np.all(measured[partners]) or not np.all(measured[refs]):return None,'UNMEASURED'
 p=int(row[partners].sum());r=int(row[refs].sum())
 if not r:return None,'REFERENCE_ZERO'
 activity=math.log1p(10000*p/r)
 return activity,'POSITIVE' if p else 'MEASURED_ZERO'

def query_identity_normalization_audit(raw,measured,views,libs,addr):
 """Query-swap primary anti-cheat: same cell and common student gene set.

 For a fixed cell and identical complementary raw RNA, per-query 13-gene
 denominators can differ when ONLY query identity changes. A 23-gene union
 denominator and fixed complement must not. This isolates preprocessing from
 intended q-conditional target changes; it does not test trained neural states.
 """
 from itertools import combinations
 families={name:forbidden_addresses(addr,name) for name in PROGS}
 union=tuple(sorted(set().union(*families.values())))
 assert len(union)==23,'fixed 3q+12partner+8reference common coordinate basis'
 out={}
 for qa,qb in combinations(PROGS,2):
  a,b=families[qa],families[qb]
  r={'evaluated_cell_views':0,'q_specific_denominators_differ':0,
     'q_specific_tokens_change':0,'max_q_specific_token_shift':0.,
     'max_union_token_shift':0.,'excluded_common_addresses':len(union),
     'target_eligible_cell_views':0}
  for i in range(len(raw)):
   # Target availability must be recognized; never label an unmeasured
   # HLA-DRA panel as an evaluable biological query swap.
   eligible=(anchor(raw[i],measured[i],a)[0] is not None and
             anchor(raw[i],measured[i],b)[0] is not None)
   for view in range(4):
    visible=measured[i].copy();visible[list(union)]=False;visible[views[i,view]]=False
    observed=raw[i,visible]
    if not np.any(observed>0):continue
    da=int(libs[i])-int(raw[i,list(a)].sum())
    db=int(libs[i])-int(raw[i,list(b)].sum())
    du=int(libs[i])-int(raw[i,list(union)].sum())
    assert min(da,db,du)>0
    t1=np.log1p(observed.astype(float)*10000/da)
    t2=np.log1p(observed.astype(float)*10000/db)
    u1=np.log1p(observed.astype(float)*10000/du)
    u2=np.log1p(observed.astype(float)*10000/du)
    d=float(np.max(np.abs(t1-t2)))
    ud=float(np.max(np.abs(u1-u2)))
    r['evaluated_cell_views']+=1
    r['target_eligible_cell_views']+=int(eligible)
    r['q_specific_denominators_differ']+=int(da!=db)
    r['q_specific_tokens_change']+=int(d>0.)
    r['max_q_specific_token_shift']=max(r['max_q_specific_token_shift'],d)
    r['max_union_token_shift']=max(r['max_union_token_shift'],ud)
  assert r['evaluated_cell_views']==336
  assert r['max_union_token_shift']==0.
  out[f'{qa}__vs__{qb}']=r
 return out

def run():
 raw,measured,ops,keys,libs,meta,addr,truth_sha,views,stored_student,geom=load()
 results={}; positives={}; all_tests=[]
 for name in PROGS:
  f=forbidden_addresses(addr,name)
  rows=[]; view_check_count=0; max_stored_replay_error=0.0
  for i in range(len(raw)):
   if not measured[i,f[0]]:continue
   base=raw[i]; mask=measured[i];lib=int(libs[i]);
   # q count mutation changes the full-source library as a genuine raw-count edit.
   q2=base.copy();delta=1 if base[f[0]]==0 else min(100,max(1,int(base[f[0]])))
   q2[f[0]]+=delta
   bq={d:student_surface(base,mask,lib,f,d) for d in ('FULL_SOURCE','Q_ONLY_EXCLUDED','ALL_FORBIDDEN_EXCLUDED')}
   aq={d:student_surface(q2,mask,lib+delta,f,d) for d in bq}
   d_q={d:diff(bq[d],aq[d]) for d in bq}
   # Independently mutate a forbidden partner and a forbidden reference.
   for compartment,positions in (('partner',f[1:5]),('reference',f[5:])):
    available=[p for p in positions if mask[p]]
    if not available:continue
    idx=available[0];edited=base.copy();edited[idx]+=7
    dp={d:diff(bq[d],student_surface(edited,mask,lib+7,f,d)) for d in bq}
    assert max(dp['ALL_FORBIDDEN_EXCLUDED'].values())==0.
    assert dp['Q_ONLY_EXCLUDED']['denominator']==7.
    rows.append({'operator':int(ops[i]),'cell_key_sha256':hashlib.sha256(str(int(keys[i])).encode()).hexdigest(),
     'intervention':compartment,'full_source_token_max':dp['FULL_SOURCE']['tokens'],
     'q_only_token_max':dp['Q_ONLY_EXCLUDED']['tokens'],
     'all_forbidden_token_max':dp['ALL_FORBIDDEN_EXCLUDED']['tokens']})
   assert max(d_q['Q_ONLY_EXCLUDED'].values())==0.
   assert max(d_q['ALL_FORBIDDEN_EXCLUDED'].values())==0.
   # If at least one visible positive gene exists, the unsafe denominator must affect it.
   if np.any(base[bq['FULL_SOURCE']['visible_support']]>0):
    assert d_q['FULL_SOURCE']['tokens']>0.
   # Replay ALL FOUR physically stored historical masking views; the exact
   # stored source-normalized final encoder values must match the recovered
   # integer-count replay, before adding the stronger forbidden compartment.
   for v in range(4):
    h=views[i,v]
    replay=np.log1p(base[mask & ~h].astype('float64')*10000.0/lib)
    expected=stored_student[i,v,mask & ~h]
    er=float(np.max(np.abs(replay-expected))) if replay.size else 0.
    assert er<3e-7,'stored historical encoder input fails raw reconstruction'
    max_stored_replay_error=max(max_stored_replay_error,er)
    vb={d:student_surface(base,mask,lib,f,d,h) for d in bq}
    vq={d:student_surface(q2,mask,lib+delta,f,d,h) for d in bq}
    assert max(diff(vb['ALL_FORBIDDEN_EXCLUDED'],vq['ALL_FORBIDDEN_EXCLUDED']).values())==0.
    assert max(diff(vb['Q_ONLY_EXCLUDED'],vq['Q_ONLY_EXCLUDED']).values())==0.
    # Check a teacher-panel mutation in each actual stored view as well.
    panel_avail=[p for p in f[1:] if mask[p]]
    if panel_avail:
     pe=base.copy();pe[panel_avail[0]]+=7
     vd={d:student_surface(pe,mask,lib+7,f,d,h) for d in bq}
     assert max(diff(vb['ALL_FORBIDDEN_EXCLUDED'],vd['ALL_FORBIDDEN_EXCLUDED']).values())==0.
     assert diff(vb['Q_ONLY_EXCLUDED'],vd['Q_ONLY_EXCLUDED'])['denominator']==7.
    view_check_count+=1
   ab,st=anchor(base,mask,f); am,sm=anchor(q2,mask,f)
   assert st==sm
   if ab is not None:assert ab==am
   # Invoke the exact inherited R8 target constructor, rather than relying
   # on the simple independent activity formula alone.
   eargs=dict(same_cell_key=str(int(keys[i])),donor_key=meta[int(keys[i])]['donor_id'],
       canonical_query=int(f[0]),query_gene_symbol=name,partner_address_ids=tuple(map(int,f[1:5])),
       partner_raw_umi=tuple(int(base[k]) if mask[k] else None for k in f[1:5]),
       disjoint_reference_address_ids=tuple(map(int,f[5:])),
       reference_raw_umi=tuple(int(base[k]) if mask[k] else None for k in f[5:]),
       assay='RNA',correspondence='SAME_ORIGINAL_CELL',original_sha256=CALIB_SHA)
   r8base=construct_measured_anchor(Evidence(**eargs,teacher_queried_umi=int(base[f[0]])),
       expected_source_sha256=CALIB_SHA)
   r8mutation=construct_measured_anchor(Evidence(**eargs,teacher_queried_umi=int(q2[f[0]])),
       expected_source_sha256=CALIB_SHA)
   assert r8base==r8mutation,'R8 measured anchor changed under q-only mutation'
   if ab is None:assert r8base.log10k_activity is None
   else:assert abs(r8base.log10k_activity-ab)<1e-12
   rows.append({'operator':int(ops[i]),'cell_key_sha256':hashlib.sha256(str(int(keys[i])).encode()).hexdigest(),
    'intervention':'q','q_raw':int(base[f[0]]),'q_delta':int(delta),
    'full_source_token_max':d_q['FULL_SOURCE']['tokens'],
    'q_only_token_max':d_q['Q_ONLY_EXCLUDED']['tokens'],
    'all_forbidden_token_max':d_q['ALL_FORBIDDEN_EXCLUDED']['tokens'],
    'measured_anchor_status':st})
  assert len([r for r in rows if r['intervention']=='q'])==sum(measured[:,f[0]])
  results[name]={
   'query_index':f[0],'partner_indices':list(f[1:5]),'reference_indices':list(f[5:]),
   'eligible_q_rows':int(np.sum(measured[:,f[0]])),
   'q_positive_original_rows':int(np.sum((raw[:,f[0]]>0)&measured[:,f[0]])),
   'q_interventions':sum(x['intervention']=='q' for x in rows),
   'partner_interventions':sum(x['intervention']=='partner' for x in rows),
   'reference_interventions':sum(x['intervention']=='reference' for x in rows),
   'operators_with_q_interventions':len(set(r['operator'] for r in rows if r['intervention']=='q')),
   'stored_masked_views_physically_replayed':view_check_count,
   'max_stored_encoder_view_replay_error':max_stored_replay_error,
   'anchor_status':{st:sum(r.get('measured_anchor_status')==st for r in rows) for st in ('POSITIVE','MEASURED_ZERO','REFERENCE_ZERO','UNMEASURED')},
   'q_full_source_max_token_shift':max(r['full_source_token_max'] for r in rows if r['intervention']=='q'),
   'q_only_partner_or_reference_max_token_shift':max((r['q_only_token_max'] for r in rows if r['intervention']!='q'),default=0.),
   'all_forbidden_max_token_shift':max(r['all_forbidden_token_max'] for r in rows),
  }
  assert results[name]['all_forbidden_max_token_shift']==0
  assert results[name]['q_interventions']==84
  assert view_check_count==84*4
  positives[name]=rows
 summary={'schema':'JEPA_R16_ORIGINAL84_FORBIDDEN_COMPARTMENT_INTERVENTION_V1',
   'scope':'HISTORICAL_84_ORIGINAL_LOGGED_CELLS_INVERTED_TO_INTEGER_COUNTS__NOT_FULL104_BLOCK_EXECUTION',
   'query_swap_preprocessing_audit':query_identity_normalization_audit(raw,measured,views,libs,addr),
   'source_archives':{'calibration_zip_sha256':digest_file(CALIB),'expression_metadata_zip_sha256':digest_file(EXPR),
     'truth_npz_member_sha256':truth_sha,
     'inherited_r8_constructor_sha256':digest_file(HERE/'JEPA_R8_STRUCTURED_TARGET_CONTRACT_20260926.py')},'geometry':geom,'program_results':results,
   'conclusion':'q-only exclusion solves q channel, NOT partner/reference channel. ALL forbidden ancestors must be removed from denominator. For query swaps, a common 23-gene union complement is necessary to remove per-query normalization/input-coordinate differences.',
   'inherited_r8_contract_physically_invoked':True,
   'caveats':['source_library exact from original metadata; original integer counts reconstructed from original log1p10K float32 with a maximum error gate',
     '84 historical cells span 42 operators; NOT a microglial statistical cohort or FULL104 raw Level4 block run',
     'q mutations at the count/denominator interface; not a biological perturbation',
     'no model training, teacher neural forward, protected or external outcome read',
     'per-query ALL_FORBIDDEN denominator is versioned research candidate, not approved production normalization',
     'other full-source technical covariates or unlisted descendants remain outside this narrow numerical surface'],
   'training_authorized':False,'protected_outcomes_opened':False}
 return summary,positives

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--calibration',default=CALIB)
 ap.add_argument('--expression-metadata',default=EXPR)
 ap.add_argument('--out-dir',default=str(HERE))
 args=ap.parse_args()
 CALIB=args.calibration; EXPR=args.expression_metadata
 summary,rows=run();out=Path(args.out_dir);out.mkdir(parents=True,exist_ok=True)
 (out/'R16_RESULTS.json').write_text(json.dumps(summary,indent=2))
 (out/'R16_ROW_LEVEL.json').write_text(json.dumps(rows,indent=2))
 for p,v in summary['program_results'].items():print(p,v)
 print('PASS original84 reconstruction, 42 operators, 3 queries, q/partner/reference mutation and abstentions')
