"""R8 research-only exact same-cell observed state. NOT a qualified biology target.
Output is a developmental measurement ANCHOR, not a whole biological world state.
Unpaired assays, donor-level matches and absent measurements cannot form one target.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import log,log1p,sqrt,isfinite
from typing import Optional

class TargetEvidenceError(ValueError):pass
@dataclass(frozen=True)
class Evidence:
    same_cell_key:str
    donor_key:str
    canonical_query:int
    query_gene_symbol:str
    partner_address_ids:tuple[int,...]
    partner_raw_umi:tuple[Optional[int],...]
    disjoint_reference_address_ids:tuple[int,...]
    reference_raw_umi:tuple[Optional[int],...]
    assay:str
    correspondence:str
    original_sha256:str
    teacher_queried_umi:Optional[int]=None

@dataclass(frozen=True)
class MeasuredAnchor:
    cell_key:str
    donor_key:str
    canonical_query:int
    partner_address_ids:tuple[int,...]
    log10k_activity:Optional[float]
    clr_composition:Optional[tuple[float,...]]
    activity_sampling_sd_approx:Optional[float]
    composition_sampling_sd_approx:Optional[tuple[float,...]]
    observed_partner_count:int
    observed_reference_count:int
    status:str
    teacher_query_count_was_supplied:bool
    causal_claim:bool=False
    scientifically_validated:bool=False

def construct_measured_anchor(e:Evidence,*,expected_source_sha256:str)->MeasuredAnchor:
    if e.assay!='RNA' or e.correspondence!='SAME_ORIGINAL_CELL' or not e.same_cell_key or not e.donor_key:
        raise TargetEvidenceError('not authenticated original same-cell RNA')
    if not isinstance(e.canonical_query,int) or isinstance(e.canonical_query,bool) or e.canonical_query<0:
        raise TargetEvidenceError('invalid canonical query address')
    if e.original_sha256!=expected_source_sha256 or len(expected_source_sha256)!=64 or any(c not in '0123456789abcdef' for c in expected_source_sha256):
        raise TargetEvidenceError('original source root mismatch')
    if len(e.partner_address_ids)!=4 or len(e.partner_raw_umi)!=4 or len(e.disjoint_reference_address_ids)!=8 or len(e.reference_raw_umi)!=8:
        raise TargetEvidenceError('four partners and eight disjoint reference genes required')
    all_addr=(e.canonical_query,)+e.partner_address_ids+e.disjoint_reference_address_ids
    if any(type(a) is not int or a<0 or a>=41238 for a in all_addr) or len(set(all_addr))!=len(all_addr):
        raise TargetEvidenceError('duplicate, q-containing, or out-of-registry evidence')
    if e.teacher_queried_umi is not None and (type(e.teacher_queried_umi) is not int or e.teacher_queried_umi<0):
        raise TargetEvidenceError('invalid optional teacher queried count')
    for v in e.partner_raw_umi+e.reference_raw_umi:
        if v is not None and (type(v) is not int or v<0):raise TargetEvidenceError('counts must be nonnegative exact raw UMIs or missing')
    common=dict(cell_key=e.same_cell_key,donor_key=e.donor_key,canonical_query=e.canonical_query,
        partner_address_ids=e.partner_address_ids,teacher_query_count_was_supplied=e.teacher_queried_umi is not None)
    if any(x is None for x in e.partner_raw_umi):
        return MeasuredAnchor(**common,log10k_activity=None,clr_composition=None,activity_sampling_sd_approx=None,
            composition_sampling_sd_approx=None,observed_partner_count=0,observed_reference_count=0,status='ABSTAIN_PARTNER_UNMEASURED')
    if any(x is None for x in e.reference_raw_umi):
        return MeasuredAnchor(**common,log10k_activity=None,clr_composition=None,activity_sampling_sd_approx=None,
            composition_sampling_sd_approx=None,observed_partner_count=0,observed_reference_count=0,status='ABSTAIN_REFERENCE_UNMEASURED')
    p=sum(e.partner_raw_umi);r=sum(e.reference_raw_umi)
    if r==0:
        return MeasuredAnchor(**common,log10k_activity=None,clr_composition=None,activity_sampling_sd_approx=None,
            composition_sampling_sd_approx=None,observed_partner_count=p,observed_reference_count=0,status='ABSTAIN_REFERENCE_ZERO')
    activity=log1p(10000*p/r)
    # This is measurement uncertainty only, not a posterior for genuine cell state.
    sd=sqrt(1/(p+.5)+1/(r+.5))
    if p==0:
        return MeasuredAnchor(**common,log10k_activity=0.,clr_composition=None,activity_sampling_sd_approx=sd,
            composition_sampling_sd_approx=None,observed_partner_count=0,observed_reference_count=r,status='MEASURED_ZERO_COMPOSITION_UNDEFINED')
    probs=[(x+.5)/(p+2.) for x in e.partner_raw_umi];ll=[log(x) for x in probs];mu=sum(ll)/4
    clr=tuple(x-mu for x in ll)
    return MeasuredAnchor(**common,log10k_activity=activity,clr_composition=clr,
        activity_sampling_sd_approx=sd,composition_sampling_sd_approx=tuple(sqrt(1/(x+.5)) for x in e.partner_raw_umi),
        observed_partner_count=p,observed_reference_count=r,status='MEASURED_NONZERO')
