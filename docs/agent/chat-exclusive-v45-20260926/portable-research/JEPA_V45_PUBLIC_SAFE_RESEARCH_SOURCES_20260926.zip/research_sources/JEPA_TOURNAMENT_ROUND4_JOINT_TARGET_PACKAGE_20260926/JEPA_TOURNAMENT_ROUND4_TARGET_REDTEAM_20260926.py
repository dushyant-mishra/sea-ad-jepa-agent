#!/usr/bin/env python3
"""Read-only, non-authorizing checks of R4/R4B results and code anti-repeat safeguards."""
from pathlib import Path
import json,ast,hashlib,numpy as np
R=Path('/mnt/data'); old=json.loads((R/'JEPA_TOURNAMENT_ROUND4_RAW_TARGET_CORRECTED_RESULTS_20260926.json').read_text());new=json.loads((R/'JEPA_TOURNAMENT_ROUND4B_QSAFE_TARGET_RESULTS_20260926.json').read_text())
checks=[]
def check(n,x):
    assert x,n;checks.append(n)
for x,name in [(old,'raw_corrected'),(new,'q_safe')]:
 check(name+'_research_only',x['training_authorized'] is False and x['protected_opened'] is False)
 check(name+'_population',x['folds']==5 and x['query_per_fold']==8 and x['nonquery_context_genes_per_q']==8)
 check(name+'_40_query_fold_records',len(x['provenance'])==40 and len({(z['fold'],z['q']) for z in x['provenance']})==40)
 check(name+'_q_context_invariance',all(z['q_scalar_excluded_from_context'] and z['q_counterfactual_context_exact_invariant'] for z in x['provenance']))
 check(name+'_independent_donor_support',all(z['train_microglia_donors']>=20 for z in x['provenance']))
 check(name+'_5_disjoint_folds',set(z['fold'] for z in x['provenance'])==set(range(5)))
 check(name+'_all_scores_finite',all(np.isfinite(z['context_r2']) for z in x['records']))
for name in ['JEPA_TOURNAMENT_ROUND4_TARGET_JOINT_PROBE_20260926.py','JEPA_TOURNAMENT_ROUND4B_QSAFE_TARGET_PROBE_20260926.py']:
 s=(R/name).read_text();ast.parse(s)
 check(name+'_student_alignment', 'np.tile(context[tr],(3,1))' in s if 'ROUND4B' in name else 'np.tile(y[tr],(3,1))' in s)
 check(name+'_no_bad_repeat','.repeat(3,axis=0)' not in s)
 check(name+'_no_dead_assert','if False else True' not in s)
check('earlier_raw_wrong_labels_withdrawn','y[tr].repeat(3,axis=0)' in (R/'JEPA_TOURNAMENT_ROUND4_TARGET_JOINT_PROBE_WITHDRAWN_LABEL_ALIGNMENT_20260926.py').read_text())
check('q_safe_raw_target_different_estimands','view-local' in new['target_proposal']['teacher_q_context'] and 'raw UMI' in old['target_proposal']['teacher_q_context'])
check('q_safe_student_gt_visible_tech_in_all_folds',all(np.mean([z['context_r2'] for z in new['records'] if z['fold']==f and z['region']=='ALL' and z['arm']=='MASKED_STUDENT_PCA32'])>np.mean([z['context_r2'] for z in new['records'] if z['fold']==f and z['region']=='ALL' and z['arm']=='VISIBLE_TECH']) for f in range(5)))
check('q_safe_rich_gt_split_on_all_cells_folds',all(np.mean([z['context_r2'] for z in new['records'] if z['fold']==f and z['region']=='ALL' and z['arm']=='RICH32'])>np.mean([z['context_r2'] for z in new['records'] if z['fold']==f and z['region']=='ALL' and z['arm']=='SPLIT16_8_8']) for f in range(5)))
check('q_safe_scalar_only_below_student',new['summary']['SCALAR_ONLY']['ALL']['mean_query_fold_r2']<new['summary']['MASKED_STUDENT_PCA32']['ALL']['mean_query_fold_r2'])
check('prior_generic_neural_not_retrained',not any(z['arm'].endswith('NEURAL_JEPA') for z in new['records']))
check('q_safe_target_not_independently_validated',any('not biological ground truth' in s for s in new['limitations']))
print(json.dumps({'status':'PASS','passed':len(checks),'checks':checks,'raw_corrected_student':old['summary']['MASKED_STUDENT_PCA32'],'q_safe_student':new['summary']['MASKED_STUDENT_PCA32']},indent=2))
