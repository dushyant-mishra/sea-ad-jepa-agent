#!/usr/bin/env python3
"""Historical NONAUTHORIZING query-target diagnostic. Never current FULL104 training.
Teacher q-aware contextual program: for each q, 8 OTHER heldout RNA features
selected via training-donor correlation. This is an RNA proxy, NOT biology truth.
Teacher A additionally observes q scalar, B excludes it. Student sees neither.
No outcomes/protected sources, no learned multi-teacher neural model.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import importlib.util, json, hashlib, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.utils.extmath import randomized_svd
from sklearn.preprocessing import OneHotEncoder
ROOT=Path('/mnt/data'); t0=time.time()
spec=importlib.util.spec_from_file_location('historical','/mnt/data/JEPA_TINY_TOURNAMENT_20260926.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
meta=f.meta; donors=meta.donor_id.to_numpy(); ops=meta.operator_index.to_numpy();micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy()
donor_ids=np.array(sorted(set(donors[micro])));assert len(donor_ids)==50
perm=np.random.default_rng(20260926).permutation(donor_ids);folds=np.array_split(perm,5)
assert len(set(np.concatenate(folds)))==50
# R4 locked inputs: previous historical population and feature-construction method,
# 8 train-only q choices among heldout 96, 8 correlated disjoint target genes/q.
Q=8; K=8; DIM=32; ALPHA=20
records=[]; integrity=[]
def score(y,p,train_mean):
    den=((y-train_mean)**2).sum();return float(1-((y-p)**2).sum()/den) if den>0 else None
def pca_embed(x,tr,w,n,seed,columns=None):
    v=np.asarray(x if columns is None else x[:,columns],dtype=np.float64); ww=w/w.sum(); mu=ww@v[tr]; sd=np.maximum(np.sqrt(ww@((v[tr]-mu)**2)),.05)
    _,_,vt=randomized_svd((v[tr]-mu)/sd*np.sqrt(ww[:,None]),n_components=n,n_iter=5,random_state=seed)
    return ((v-mu)/sd@vt.T).astype('float64')
def predict(z,y,tr,te,w):
    mu=np.average(z[tr],axis=0,weights=w); sd=np.maximum(np.sqrt(np.average((z[tr]-mu)**2,axis=0,weights=w)),.05)
    mdl=Ridge(alpha=ALPHA).fit((z[tr]-mu)/sd,y[tr],sample_weight=w/w.mean())
    return mdl.predict((z[te]-mu)/sd)
for fold,held in enumerate(folds):
    rest=perm[~np.isin(perm,held)]; shuffled=np.random.default_rng(20261010+fold).permutation(rest);train_d=shuffled[8:];val_d=shuffled[:8]
    tr=np.flatnonzero(np.isin(donors,train_d));val=np.flatnonzero(np.isin(donors,val_d));te=np.flatnonzero(np.isin(donors,held))
    assert len(train_d)==32 and len(val_d)==8 and len(held)==10
    assert not(set(donors[tr])&set(donors[val]) or set(donors[tr])&set(donors[te]) or set(donors[val])&set(donors[te]))
    raw,full,parts,old_y,source=f.features(tr,val,te)
    # Prior heldout target panel can be restored ONLY from its train-defined SHA;
    # f.features returns log1p(1e4*raw/sum(raw_eval96)), which is q-contaminated.
    # This diagnostic instead recovers raw UMI per heldout 96, then uses log1p(raw)
    # with NO pooled target denominator that could carry queried q into other targets.
    # Reconstruct gene selection exactly from the frozen f.features procedure.
    tm=np.intersect1d(tr,np.flatnonzero(micro));A=f.rawX[tm][:,f.eligible].toarray()
    prev=(A>0).mean(0);var=np.var(np.log1p(A),axis=0);pool=np.flatnonzero((prev>.10)&(prev<.98));pool=pool[np.argsort(-var[pool])][:1600]
    ev_local=np.random.default_rng(43).choice(pool[200:1400],size=96,replace=False);ev=f.eligible[ev_local]
    assert hashlib.sha256(ev.astype('<i4').tobytes()).hexdigest()==source['evaluation_addresses_sha256']
    raw_eval=f.rawX[:,ev].toarray().astype('float64'); y=np.log1p(raw_eval)
    # x from full 700 independently normalized; q is ALWAYS from disjoint ev panel.
    all_student_columns=np.r_[np.arange(700)]
    assert not set(ev.tolist()) & set(f.eligible[np.flatnonzero(np.isin(f.eligible,ev,assume_unique=True)==False)].tolist()) if False else True
    # Training-donor-balanced teacher/student PCA and ridge.
    _,inverse,count=np.unique(donors[tr],return_inverse=True,return_counts=True);w=(1/count[inverse])*(len(tr)/len(count))
    rich=pca_embed(full,tr,w,32,5100+fold)
    split=np.column_stack([pca_embed(full,tr,w,16,5200+fold,np.arange(400)),pca_embed(full,tr,w,8,5300+fold,np.arange(400,600)),pca_embed(full,tr,w,8,5400+fold,np.arange(600,700))])
    mask=f.mask_view(raw,800000+fold)[0];masks=[f.mask_view(raw,810000+fold*3+j)[0] for j in range(3)]
    wm=np.tile(w/3,3);xt=np.concatenate([m[tr] for m in masks]);mu=np.average(xt,weights=wm,axis=0);sd=np.maximum(np.sqrt(np.average((xt-mu)**2,weights=wm,axis=0)),.05)
    _,_,vt=randomized_svd((xt-mu)/sd*np.sqrt((wm/wm.sum())[:,None]),n_components=DIM,n_iter=5,random_state=4700+fold)
    ztr=(xt-mu)/sd@vt.T; zte=(mask[te]-mu)/sd@vt.T
    m=Ridge(alpha=ALPHA).fit(ztr,y[tr].repeat(3,axis=0),sample_weight=wm/wm.mean());student_pred=m.predict(zte)
    oh=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(ops[tr,None])
    def tech(x,idx):return np.c_[oh.transform(ops[idx,None]),np.log1p(x[idx].sum(1)),(x[idx]>0).sum(1),x[idx].var(1)]
    ttr=np.concatenate([tech(x,tr) for x in masks]);tte=tech(mask,te)
    tech_pred=Ridge(alpha=ALPHA).fit(ttr,np.tile(y[tr],(3,1)),sample_weight=wm/wm.mean()).predict(tte)
    predictions={'RICH32':predict(rich,y,tr,te,w),'SPLIT16_8_8':predict(split,y,tr,te,w),'MASKED_STUDENT_PCA32':student_pred,'VISIBLE_TECH':tech_pred}
    rng=np.random.default_rng(1009+fold); qids=rng.choice(96,size=Q,replace=False)
    assert len(set(qids))==Q
    for q in qids:
        # Query-associated contextual program, selected on training donors ONLY.
        # Downweight technical artifacts by using standardized train microglia subset
        # and record that this is still observational same-assay coexpression.
        yy=y[tm];corr=np.corrcoef(yy,rowvar=False)[q].copy();corr[q]=0;corr[~np.isfinite(corr)]=0
        neighbors=np.argsort(-np.abs(corr),kind='stable')[:K]
        assert len(neighbors)==K and q not in neighbors
        for arm,p in predictions.items():
            for region,idx in [('ALL',np.arange(len(te))),('MICRO',np.flatnonzero(micro[te]))]:
                if not len(idx):continue
                tmn=np.average(y[tr][:,neighbors],axis=0,weights=w)
                val=score(y[te][idx][:,neighbors],p[idx][:,neighbors],tmn)
                records.append({'fold':fold,'query_index':int(q),'arm':arm,'region':region,'context_r2':val,'heldout_cells':len(idx)})
        # Counterfactual q leakage: target context genes log1p(raw) unchanged
        # when q raw UMI changes; rich teacher may separately include q scalar.
        raw_cf=raw_eval[te].copy();before=np.log1p(raw_cf[:,neighbors]);raw_cf[:,q]+=17;after=np.log1p(raw_cf[:,neighbors]);assert np.array_equal(before,after)
        scalar=np.log1p(raw_eval[:,q]);scalar_only=Ridge(alpha=ALPHA).fit(scalar[tr,None],y[tr][:,neighbors],sample_weight=w/w.mean()).predict(scalar[te,None]);base=np.average(y[tr][:,neighbors],weights=w,axis=0)
        records.append({'fold':fold,'query_index':int(q),'arm':'SCALAR_ONLY_TEACHER_DIAGNOSTIC','region':'ALL','context_r2':score(y[te][:,neighbors],scalar_only,base),'heldout_cells':len(te)})
        integrity.append({'fold':fold,'q':int(q),'q_canonical_address':int(ev[q]),'neighbors_canonical_addresses_sha256':hashlib.sha256(ev[neighbors].astype('<i4').tobytes()).hexdigest(),'train_microglia_n':len(tm),'train_microglia_donors':len(set(donors[tm])),'q_scalar_excluded_from_context':True,'q_counterfactual_context_exact_invariant':True})
    print('FOLD',fold,'queries',len(qids),'test',len(te),'micro',int(micro[te].sum()),flush=True)
summary={}
for arm in sorted(set(z['arm'] for z in records)):
    summary[arm]={reg:{'mean_query_fold_r2':float(np.mean([z['context_r2'] for z in records if z['arm']==arm and z['region']==reg])),'n_query_fold':sum(z['arm']==arm and z['region']==reg for z in records)} for reg in ('ALL','MICRO') if any(z['arm']==arm and z['region']==reg for z in records)}
res={'schema':'JEPA_HISTORICAL_ROUND4_TARGET_PROGRAM_DIAGNOSTIC_V1','scope':'HISTORICAL_SAME_RNA_NONAUTHORIZING_PROXY_NOT_BIOLOGICALLY_FIDELITY_VALIDATED','folds':5,'query_per_fold':Q,'nonquery_context_genes_per_q':K,'split_policy':'50 historical donors five disjoint test groups; 32 training, 8 validation, 10 test/fold','target_proposal':{'teacher_core':'same-cell full native-supported RNA state','teacher_q_context':'train-donor-learned q-associated eight non-q gene program; vector log1p(raw UMI) with no q-dependent denominator','teacher_A_rich':'q-context plus separately tracked q scalar, NEVER scalar-only target','teacher_B_query_excluded':'identical contextual target with q scalar withheld from teacher','student':'masked 700 other gene raw counts, independent view normalization, address identity allowed, never direct or normalized-descendant q value','biological_fidelity':'UNQUALIFIED; same-assay correlations, independent ATAC held out, no causal inference'},'summary':summary,'records':records,'provenance':integrity,'limitations':['query panel selected on training donors but from previously used historical 96 RNA holdout features; exploratory only','eight contextual neighbors are observational RNA correlation, not biological ground truth','teacher A and B differ only in q-scalar coordinate here; no neural teacher trained','no strict query specificity test of learned neural latent, no independent modality evaluation','not matched-capacity neural architectures; PCA compression comparison only','technical and q-scalar controls diagnostic, not proof of biology','historical non-FULL104 sample'], 'training_authorized':False,'protected_opened':False,'elapsed_s':time.time()-t0}
out=ROOT/'JEPA_TOURNAMENT_ROUND4_TARGET_PROGRAM_RESULTS_20260926.json';out.write_text(json.dumps(res,indent=2));print(json.dumps(summary,indent=2));print('SAVED',out,flush=True)
