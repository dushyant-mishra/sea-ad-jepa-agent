"""Non-authorizing design-time firewall: prohibit selection on reserved ATAC outcomes.

Does not certify biological fidelity, sample independence, source hashes, or V5 authority.
Reject unknown fields by allowlist; observed ATAC summaries are evaluation-only.
"""
from __future__ import annotations

SAFE_DESIGN_FIELDS = frozenset({
    'canonical_address_id', 'canonical_address_index', 'stable_ensembl_id',
    'canonical_registry_status', 'assay_feature_present', 'mapping_ambiguity',
    'assay_reference_build', 'annotation_reference_build', 'annotation_promoter_window',
    'gene_symbol', 'original_rna_measurement_support',
})
FORBIDDEN_OUTCOME_FIELDS = frozenset({
    'atac_accessibility_state', 'atac_microglia_accessibility_state',
    'regulatory_evidence_state', 'matched_rna_atac_state',
    'atac_detected_nuclei', 'atac_accessible_promoter',
    'atac_donor_activity', 'atac_peak_detection_fraction',
})

class DesignDataLeak(ValueError):
    pass

def validate_design_fields(fields, *, reason='teacher_target_selection'):
    if reason not in ('teacher_target_selection', 'teacher_architecture_selection',
                      'threshold_setting', 'feature_selection'):
        raise DesignDataLeak('unknown design use')
    names = tuple(fields)
    if not names or len(names) != len(set(names)):
        raise DesignDataLeak('empty or repeated design fields')
    forbidden = set(names) & FORBIDDEN_OUTCOME_FIELDS
    if forbidden:
        raise DesignDataLeak('reserved ATAC outcome dependency: ' + ','.join(sorted(forbidden)))
    unknown = set(names) - SAFE_DESIGN_FIELDS
    if unknown:
        raise DesignDataLeak('unreviewed field not authorized: ' + ','.join(sorted(unknown)))
    return tuple(names)

def validate_crosswalk_transfer(*, source_class, target_role, donor_pairing, training_authorized=False):
    if training_authorized is not False:
        raise DesignDataLeak('this research interface cannot authorize training')
    if donor_pairing != 'SEPARATE_NUCLEI_DONOR_ONLY':
        raise DesignDataLeak('Morabito is not a same-nucleus multiome')
    if source_class == 'ATAC_OBSERVED_ACCESSIBILITY' and target_role in (
        'FEATURE_SELECTION', 'TEACHER_TRAINING', 'MODEL_SELECTION', 'THRESHOLD_SELECTION'):
        raise DesignDataLeak('reserved ATAC used to optimize its own independent test')
    if source_class == 'ANNOTATION_ONLY' and target_role == 'FEATURE_SELECTION':
        return True
    if source_class == 'ATAC_OBSERVED_ACCESSIBILITY' and target_role == 'QUARANTINED_EVALUATION_ONLY':
        return True
    raise DesignDataLeak('unrecognized source-to-role pairing')
