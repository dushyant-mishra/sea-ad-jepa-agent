import unittest
from jepa_r11_atac_firewall import DesignDataLeak, validate_design_fields, validate_crosswalk_transfer

class FirewallTests(unittest.TestCase):
    def test_annotation_features_allowed(self):
        self.assertEqual(len(validate_design_fields(['canonical_address_id','assay_feature_present'])),2)
    def test_atac_accessibility_rejected(self):
        with self.assertRaises(DesignDataLeak):
            validate_design_fields(['gene_symbol','atac_microglia_accessibility_state'])
    def test_matched_eligibility_rejected(self):
        with self.assertRaises(DesignDataLeak):
            validate_design_fields(['matched_rna_atac_state'])
    def test_unknown_field_fails_closed(self):
        with self.assertRaises(DesignDataLeak):
            validate_design_fields(['gene_symbol','promoter_count_after_atac_detection'])
    def test_duplicate_fields_rejected(self):
        with self.assertRaises(DesignDataLeak):
            validate_design_fields(['gene_symbol','gene_symbol'])
    def test_annotation_support_only_accepted(self):
        self.assertTrue(validate_crosswalk_transfer(source_class='ANNOTATION_ONLY',target_role='FEATURE_SELECTION',donor_pairing='SEPARATE_NUCLEI_DONOR_ONLY'))
    def test_observed_atac_selection_refused(self):
        with self.assertRaises(DesignDataLeak):
            validate_crosswalk_transfer(source_class='ATAC_OBSERVED_ACCESSIBILITY',target_role='FEATURE_SELECTION',donor_pairing='SEPARATE_NUCLEI_DONOR_ONLY')
    def test_observed_atac_quarantine_allowed(self):
        self.assertTrue(validate_crosswalk_transfer(source_class='ATAC_OBSERVED_ACCESSIBILITY',target_role='QUARANTINED_EVALUATION_ONLY',donor_pairing='SEPARATE_NUCLEI_DONOR_ONLY'))
    def test_fake_same_cell_rejected(self):
        with self.assertRaises(DesignDataLeak):
            validate_crosswalk_transfer(source_class='ANNOTATION_ONLY',target_role='FEATURE_SELECTION',donor_pairing='SAME_CELL')
    def test_training_authorization_rejected(self):
        with self.assertRaises(DesignDataLeak):
            validate_crosswalk_transfer(source_class='ANNOTATION_ONLY',target_role='FEATURE_SELECTION',donor_pairing='SEPARATE_NUCLEI_DONOR_ONLY',training_authorized=True)

if __name__ == '__main__': unittest.main()
