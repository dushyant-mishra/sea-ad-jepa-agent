#!/usr/bin/env python3
"""Research-only fail-closed R10 scientific readiness semantics; no ATAC outcome access."""
import json,unittest,copy
from pathlib import Path
R=Path('/mnt/data')
class ReadinessError(ValueError):pass

def review(plan,results):
 e=plan['external_biology'];g=plan['go_no_go'];t=plan['current_target'];m=plan['r10_measurement']
 if e['cell_level_rna_atac_pairing'] is not False or e['inferential_unit']!='donor' or e['n_shared_donors']!=18:raise ReadinessError('separate nuclei and donor n=18')
 if e['stage75f_rna_edges_accepted_as_independent_outcome'] or e['same_modality_rna_readout_accepted_as_external_validation']:raise ReadinessError('circular outcome')
 if e['outcome_data_inspected_in_R10'] or e['execution_authorized']:raise ReadinessError('reserved data must remain unopened')
 if t['latent_biological_state_qualified'] or t['trainable_teacher_architecture_selected']:raise ReadinessError('premature target or architecture certification')
 if results['biological_replicates_created']!=0 or results['number_independent_molecule_partitions']!=100 or m['new_independent_biological_replicates']!=0:raise ReadinessError('pseudo replication')
 if results['scientific_target_qualified'] or results['training_authorized'] or results['protected_outcomes_opened']:raise ReadinessError('scientific authority escalation')
 if e['original_lane_d_spec_status']!='DESIGNED_NOT_EXECUTED' or e['original_lane_d_head']!='0e36cede000c6c0eee66ab2b11ed43d41f7b9580':raise ReadinessError('lane D version mismatch')
 if e['original_lane_d_spec_blob_sha1']!='6978b7725e5c063c6e941ca2b6be79506d65c750':raise ReadinessError('lane D original spec mismatch')
 if any(e[f'original_lane_d_prerequisite_P{i}_'+suffix] for i,suffix in ((1,'frozen_encoder'),(2,'registry_projection'),(3,'atac_outcome_producer'),(4,'structural_distinctness'),(5,'signed_thresholds_power'))):raise ReadinessError('unverified requirement claimed passed')
 if e['original_lane_d_prerequisite_P6_leakage_review'] is not True:raise ReadinessError('leakage register not reviewed')
 if not all(g[x] is True for x in ('prospective_science_freeze_required','independent_measurement_required','donor_multiplicity_and_power_prespecified','real_vs_shuffled_controls_structurally_distinct','same_data_cannot_select_and_validate_target','single_rich_vs_shared_heads_vs_complementary_team_requires_matched_compute','teacher_only_first','student_comparison_only_after_teacher_fidelity')):raise ReadinessError('missing go/no-go requirement')
 if any(g[x] for x in ('training_authorized','audit_b_n1_opened','d_shared_opened','protected_full104_outcomes_opened')):raise ReadinessError('forbidden gate opened')
 if g['current_authority_roots_closed']!=0 or g['current_authority_roots_total']!=33:raise ReadinessError('unsupported roots closure')
 if any(p['positive_cells']>results['n_microglia'] or p['positive_donors']>results['n_donors'] or p['donor_cell_count_min']<1 for p in results['programs'].values()):raise ReadinessError('invalid independent support')
 return 'READY_FOR_SCIENTIFIC_DESIGN_REVIEW_ONLY__NOT_READY_TO_RUN_ATAC_OR_FULL104'

class Gates(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=json.loads((R/'JEPA_R10_TEACHER_FIDELITY_GO_NO_GO_20260926.json').read_text());cls.r=json.loads((R/'JEPA_R10_REPEATED_MEASUREMENT_RELIABILITY_RESULTS_20260926.json').read_text())
 def test_01_reference_state_is_fail_closed(self):self.assertIn('NOT_READY',review(self.p,self.r))
 def mutate(self,path,value):
  d=copy.deepcopy(self.p);o=d
  for a in path[:-1]:o=o[a]
  o[path[-1]]=value
  with self.assertRaises(ReadinessError):review(d,self.r)
 def test_02_fake_paired_nuclei_rejected(self):self.mutate(['external_biology','cell_level_rna_atac_pairing'],True)
 def test_03_fake_cell_inference_rejected(self):self.mutate(['external_biology','inferential_unit'],'cell')
 def test_04_pseudoreplicate_split_molecules_rejected(self):
  r=copy.deepcopy(self.r);r['biological_replicates_created']=100
  with self.assertRaises(ReadinessError):review(self.p,r)
 def test_05_circular_tf_edges_rejected(self):self.mutate(['external_biology','stage75f_rna_edges_accepted_as_independent_outcome'],True)
 def test_06_same_rna_falsely_external_rejected(self):self.mutate(['external_biology','same_modality_rna_readout_accepted_as_external_validation'],True)
 def test_07_open_outcome_rejected(self):self.mutate(['external_biology','outcome_data_inspected_in_R10'],True)
 def test_08_claimed_qualified_target_rejected(self):self.mutate(['current_target','latent_biological_state_qualified'],True)
 def test_09_claimed_selected_team_rejected(self):self.mutate(['current_target','trainable_teacher_architecture_selected'],True)
 def test_10_false_frozen_encoder_rejected(self):self.mutate(['external_biology','original_lane_d_prerequisite_P1_frozen_encoder'],True)
 def test_11_wrong_lane_d_spec_rejected(self):self.mutate(['external_biology','original_lane_d_spec_blob_sha1'],'0'*40)
 def test_12_leakage_register_missing_rejected(self):self.mutate(['external_biology','original_lane_d_prerequisite_P6_leakage_review'],False)
 def test_13_training_gate_rejected(self):self.mutate(['go_no_go','training_authorized'],True)
 def test_14_unsupported_root_promotion_rejected(self):self.mutate(['go_no_go','current_authority_roots_closed'],33)
 def test_15_missing_independent_measurement_rejected(self):self.mutate(['go_no_go','independent_measurement_required'],False)
 def test_16_invalid_donor_support_rejected(self):
  r=copy.deepcopy(self.r);r['programs']['APOE_LIPID']['positive_donors']=51
  with self.assertRaises(ReadinessError):review(self.p,r)
if __name__=='__main__':unittest.main(verbosity=2)
