#!/usr/bin/env python3
"""Historical R10 target measurement repeatability. Independent ATAC NOT accessed.
Repeated splits of SAME molecules are a sampling proxy, never donor/biological replication.
"""
import os
for v in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[v]='1'
import io,zipfile,hashlib,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy import sparse
ROOT=Path('/mnt/data');B=ROOT/'FOUNDATION_CALIBRATION_BUNDLE_20260824.zip'
SHA='07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444'
h=hashlib.sha256()
with B.open('rb') as f:
 for chunk in iter(lambda:f.read(8<<20),b''):h.update(chunk)
assert h.hexdigest()==SHA
with zipfile.ZipFile(B) as z:
 ns=pd.read_csv(z.open(next(n for n in z.namelist() if n.endswith('address_namespace.csv'))))
 sy=ns[ns.identity_class=='current_exact'].set_index('symbol')['molecular_address_index'].to_dict()
 with np.load(io.BytesIO(z.read(next(n for n in z.namelist() if n.endswith('FOUNDATION_OPERATOR_ADDRESS_OBSERVATION_STATE.npz')))),allow_pickle=False) as d:support=d['states'].copy()
meta=pd.read_csv('/tmp/jepa_tour_meta.csv'); X=sparse.load_npz('/tmp/jepa_tour_logexpr.npz'); micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy();I=np.flatnonzero(micro);ops=meta.operator_index.to_numpy()[I]; donor=meta.donor_id.to_numpy()[I]
assert len(I)==361 and len(set(donor))==50 and len(set(ops))==2 and X.shape[1]==41238
programs={'APOE_LIPID':['APOC1','ABCA1','GPNMB','TREM2'],'P2RY12_HOMEOSTATIC':['TMEM119','CX3CR1','GPR34','C1QA'],'HLA_DRA_ANTIGEN':['CD74','HLA-DPA1','HLA-DMA','IFI30']}
queries={'APOE_LIPID':'APOE','P2RY12_HOMEOSTATIC':'P2RY12','HLA_DRA_ANTIGEN':'HLA-DRA'}
readout={'APOE_LIPID':['CTSD','LPL'],'P2RY12_HOMEOSTATIC':['SALL1','CSF1R'],'HLA_DRA_ANTIGEN':['HLA-DMB','CTSS']}
ref=['RPLP0','EEF1A1','PGK1','HPRT1','PPIA','RPL13A','GUSB','SDHA']
ban=set(int(sy[x]) for g in programs for x in programs[g]+readout[g]+[queries[g]])|set(int(sy[x]) for x in ref)
assert len(ban)==29
# Original all-positive-row 1 UMI gives the sample-specific normalization scale.
base=np.expm1(np.minimum.reduceat(X.data,X.indptr[:-1]))
assert np.all(base>0)
def recover(cols):
 a=X[I][:,cols].toarray(); counts=np.expm1(a)/base[I,None]; delta=np.max(abs(counts-np.rint(counts)))
 assert delta<1e-5,delta
 return np.rint(counts).astype(np.int64)
large=np.zeros(len(I),dtype=np.int64)
for i,j in enumerate(I):
 sl=slice(X.indptr[j],X.indptr[j+1]); idx=X.indices[sl];counts=np.expm1(X.data[sl])/base[j]; keep=~np.isin(idx,list(ban));large[i]=np.rint(counts[keep]).astype(np.int64).sum()
assert np.all(large>0)
ref8=recover([int(sy[x]) for x in ref]).sum(1)
assert int((ref8>0).sum())==271
results={'source_root':SHA,'source_type':'historical_84_cell_calibration_support_plus_preexisting_50k_discovery_derived_cache','physical_cache_lineage_to_original_discovery_zip_reauthenticated':False,'n_microglia':len(I),'n_donors':len(set(donor)),'n_operators':len(set(ops)),'number_independent_molecule_partitions':100,'biological_replicates_created':0,'seed':20260926,'programs':{},'scientific_target_qualified':False,'training_authorized':False,'protected_outcomes_opened':False}

def corr(a,b,mask):
 if mask.sum()<12 or np.std(a[mask])<1e-10 or np.std(b[mask])<1e-10:return np.nan
 return float(np.corrcoef(a[mask],b[mask])[0,1])
for ki,(name,genes) in enumerate(programs.items()):
 cols=[int(sy[x]) for x in genes]; q=int(sy[queries[name]])
 assert not (set(cols)&ban-set(cols))
 assert np.all(support[ops[:,None],np.asarray(cols)[None,:]]==1)
 p=recover(cols); ps=p.sum(1);positive=ps>0
 assert int(positive.sum()) in (214,206,217),(name,positive.sum())
 rng=np.random.default_rng(20260926+ki)
 all_corr=[]; pos_corr=[]; ref8_corr=[]; ref8_abstain=[];both_nonzero=[]
 for rep in range(100):
  a=rng.binomial(p,.5);b=p-a
  ra=rng.binomial(large,.5);rb=large-ra
  x=np.log1p(1e4*2*a.sum(1)/np.maximum(2*ra,1));y=np.log1p(1e4*2*b.sum(1)/np.maximum(2*rb,1))
  all_corr.append(corr(x,y,np.ones(len(I),dtype=bool)))
  pos_corr.append(corr(x,y,positive))
  both_nonzero.append(int(np.sum((a.sum(1)>0)&(b.sum(1)>0))))
  ha=rng.binomial(ref8,.5);hb=ref8-ha
  # Both reference halves must be nonzero; zero/absent abstains.
  valid=(ha>0)&(hb>0)
  ref8_abstain.append(int((~valid).sum()))
  xx=np.log1p(1e4*a.sum(1)/np.maximum(ha,1));yy=np.log1p(1e4*b.sum(1)/np.maximum(hb,1))
  ref8_corr.append(corr(xx,yy,valid))
 def desc(x):
  a=np.asarray(x,float);a=a[np.isfinite(a)];return {'mean':float(a.mean()),'p05':float(np.quantile(a,.05)),'p95':float(np.quantile(a,.95)),'min':float(a.min()),'max':float(a.max())}
 # No biological replicate inference; donor support counts show estimability.
 per_donor={str(d):{'cells':int(np.sum(donor==d)),'nonzero_cells':int(np.sum(positive[donor==d]))} for d in np.unique(donor)}
 results['programs'][name]={'q_address':q,'panel_addresses':cols,'positive_cells':int(positive.sum()),'zero_cells':int((~positive).sum()),'median_positive_umi':float(np.median(ps[positive])),'positive_donors':int(sum(v['nonzero_cells']>0 for v in per_donor.values())),'all_cell_repeated_thin_corr':desc(all_corr),'positive_cell_repeated_thin_corr':desc(pos_corr),'eight_reference_both_halves_positive_corr':desc(ref8_corr),'eight_reference_half_split_abstention':desc(ref8_abstain),'both_target_halves_positive':desc(both_nonzero),'donor_cell_count_min':min(v['cells'] for v in per_donor.values()),'donor_nonzero_count_min':min(v['nonzero_cells'] for v in per_donor.values()),'same_assay_not_independent_validation':True}
 print(name,results['programs'][name]['all_cell_repeated_thin_corr'], 'fixed8',results['programs'][name]['eight_reference_both_halves_positive_corr'],flush=True)
(ROOT/'JEPA_R10_REPEATED_MEASUREMENT_RELIABILITY_RESULTS_20260926.json').write_text(json.dumps(results,indent=2)+'\n')
print('R10_REPEATED_MEASUREMENT_DIAGNOSTIC_COMPLETE_NOT_BIOLOGICAL_VALIDATION',flush=True)
