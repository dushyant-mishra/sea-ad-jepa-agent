#!/usr/bin/env python3
"""Non-authorizing integrity / planted shortcut tests for JEPA R7 same-assay program diagnostics."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import hashlib,zipfile,io,json
import numpy as np
from sklearn.linear_model import Ridge
R=Path('/mnt/data');passed=[]
def check(b,name):
 if not b:raise AssertionError(name)
 passed.append(name)
programs=None; records=[]; modes={}
for mode in ('COMPOSITION','LOG_RAW'):
 j=json.loads((R/f'JEPA_R7_PROGRAM_FALSIFIER_{mode}_RESULTS_20260926.json').read_text())
 modes[mode]=j
 check(j['schema']=='JEPA_R7_PREDECLARED_BIOLOGICAL_PROGRAM_FALSIFIER_NONAUTHORIZING','R7_SCHEMA_'+mode)
 check(j['target_mode']==mode and not j['training_authorized'] and not j['protected_opened'] and not j['independent_biological_validation'],'R7_GOVERNANCE_'+mode)
 check(j['n_folds']==5 and j['n_distinct_test_donors']==50,'R7_FOLD_COUNTS_'+mode)
 check(len(j['source_folds'])==5 and all(z['n_test_donors']==10 and z['n_train_donors']==32 and z['n_val_donors']==8 for z in j['source_folds']),'R7_DONOR_SPLIT_'+mode)
 check(len(j['checks'])==15 and all(z['student_disjoint'] and z['q_target_count_independent'] and z['all_target_support'] for z in j['checks']),'R7_SOURCE_INPUT_POLICY_'+mode)
 check(all(z['r2'] is None or np.isfinite(z['r2']) for z in j['records']),'R7_ALL_SCORES_FINITE_'+mode)
 check(all(len(set([*p['target'],*p['heldout'],p['q']]))==7 for p in j['programs_predeclared_before_run'].values()),'R7_PREDECLARED_GENE_DISJOINT_'+mode)
 check(all(z['n_micro_train']>100 and z['n_micro_test']>=30 for z in j['source_folds']),'R7_TEST_POPULATION_'+mode)
 if programs is None:programs=j['programs_predeclared_before_run']
 else:check(programs==j['programs_predeclared_before_run'],'R7_PAIR_SAME_TARGET_GENES')
 for a in j['records']:
  if a['section']=='TEACHER_FIDELITY_RNA_ONLY':
   check(a['n_test_donors']>=4 and a['n_test_micro']>=18,'R7_TEACHER_EVALUATION_NONEMPTY_'+mode+'_'+a['program']+'_'+str(a['fold'])+'_'+a['arm'])
# Disjoint original address mapping and support for heldout LPL: structural absence cannot become an observed zero.
with zipfile.ZipFile(R/'FOUNDATION_CALIBRATION_BUNDLE_20260824.zip') as z:
 p=next(x for x in z.namelist() if x.endswith('FOUNDATION_OPERATOR_ADDRESS_OBSERVATION_STATE.npz'))
 with np.load(io.BytesIO(z.read(p)),allow_pickle=False) as v:states=v['states']
check(np.sum(states[:,13734]!=1)>0,'LPL_STRUCTURAL_MISSING_PRESENT')
check(all(z['heldout_support_fraction']<1 for z in modes['COMPOSITION']['checks'] if z['program']=='APOE_LIPID'),'LPL_UNMEASURED_NOT_ASSUMED_ALL_SUPPORT')
check(all(z['heldout_support_fraction']==1 for z in modes['COMPOSITION']['checks'] if z['program']!='APOE_LIPID'),'OTHER_READOUT_SUPPORT_ALL_IN_USED_OPS')
# Target object is composition, NOT total activation: exactly unchanged under a common integer multiplier.
raw=np.array([[3.,1.,2.,4.],[0.,7.,2.,1.]],dtype=np.float64)
def norm(x):return np.log1p((10000*x)/(x.sum(1,keepdims=True)))
check(np.allclose(norm(raw),norm(raw*3),atol=1e-12),'COMPOSITION_ERASES_COMMON_PROGRAM_AMPLITUDE')
check(not np.allclose(np.log1p(raw),np.log1p(raw*3)),'LOG_COUNTS_RETAIN_AMPLITUDE_BUT_REQUIRE_TECHNICAL_CONTROL')
# Query counterfactual: q count changes, no q nor q-derived denominator reaches STUDENT/teacher measured partner target.
sraw=np.array([[4.,1.,2.],[1.,3.,0.]])
t=np.array([[2.,1.,4.,3.],[1.,2.,3.,1.]])
q=np.array([3.,4.]);student=np.log1p(10000*sraw/sraw.sum(1,keepdims=True));tt=norm(t)
q2=q+31
check(np.array_equal(student,np.log1p(10000*sraw/sraw.sum(1,keepdims=True))) and np.array_equal(tt,norm(t)),'Q_COUNTERFACTUAL_LAWFUL_PATH_INVARIANT')
leak=np.log1p(10000*sraw/(sraw.sum(1,keepdims=True)+q[:,None]));leak2=np.log1p(10000*sraw/(sraw.sum(1,keepdims=True)+q2[:,None]));check(not np.allclose(leak,leak2),'PLANTED_FULL_DENOMINATOR_LEAK_DETECTED')
# All-zero panel is not a real measured nonzero program; in ordinary R7 source: target support abstains.
check(np.array_equal(t.sum(1)>0,np.array([True,True])) and not np.any(np.zeros_like(t).sum(1)>0),'ALL_ZERO_PANEL_ABSTAINS')
# Planted signal positive and train-label permutation negative: ensure score can detect signal and refuse fake positives.
rng=np.random.default_rng(9);X=rng.normal(size=(160,8));Y=np.c_[2.3*X[:,0]+rng.normal(scale=.1,size=160),-X[:,1]+rng.normal(scale=.1,size=160)]
model=Ridge(alpha=1).fit(X[:100],Y[:100]);pred=model.predict(X[100:]);base=Y[:100].mean(0);R2=1-np.square(pred-Y[100:]).sum()/np.square(Y[100:]-base).sum()
check(R2>.85,'POSITIVE_PLANTED_TEACHER_BIO_SIGNAL_DETECTED')
shuffled=Y[:100][rng.permutation(100)];m=Ridge(alpha=1).fit(X[:100],shuffled);ps=m.predict(X[100:]);r2null=1-np.square(ps-Y[100:]).sum()/np.square(Y[100:]-base).sum();check(r2null<.2,'SHUFFLED_TEACHER_LINK_REJECTED')
# Verify the previously mounted original local archive against exact V42 custody manifest.
h=hashlib.sha256();n=0
with (R/'FOUNDATION_CALIBRATION_BUNDLE_20260824.zip').open('rb') as f:
 for chunk in iter(lambda:f.read(8<<20),b''):h.update(chunk);n+=len(chunk)
check(n==410278055 and h.hexdigest()=='07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444','ORIGINAL_CALIBRATION_BYTE_SHA')
summary={'schema':'JEPA_R7_REDTEAM_NONAUTHORIZING','passed_count':len(passed),'passed':passed,'positive_synthetic_r2':float(R2),'shuffled_synthetic_r2':float(r2null),'original_bundle_sha256':h.hexdigest(),'training_authorized':False,'independent_biology_validated':False}
(R/'JEPA_R7_REDTEAM_RESULTS_20260926.json').write_text(json.dumps(summary,indent=2));print('PASSED',len(passed),'PLANTED',R2,'SHUFFLED',r2null)
