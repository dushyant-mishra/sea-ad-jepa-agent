#!/usr/bin/env python3
"""Non-authorizing, PREDEFINED biological-program diagnostic on repeatedly used historical discovery cells.
Never claim independent biological validation. NEVER reads FULL104 protected/outcome data.
Three fixed, same-assay microglial gene programs, each has four teacher measured partner genes,
one query gene (teacher permitted) and two disjoint held-out same-assay RNA readout genes.
Student sees NO query, teacher partner, or held-out readout genes nor their full-library denominators.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import zipfile, io, json, hashlib, time, importlib.util
from pathlib import Path
import numpy as np, pandas as pd
from scipy.sparse import issparse
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder
from sklearn.utils.extmath import randomized_svd
ROOT=Path('/mnt/data');started=time.time();MODE=os.environ.get('R7_TARGET_MODE','COMPOSITION');assert MODE in ('COMPOSITION','LOG_RAW')
seed=20260926
PREDECLARED={
 'APOE_LIPID':{'q':'APOE','target':['APOC1','ABCA1','GPNMB','TREM2'],'heldout':['CTSD','LPL']},
 'P2RY12_HOMEOSTATIC':{'q':'P2RY12','target':['TMEM119','CX3CR1','GPR34','C1QA'],'heldout':['SALL1','CSF1R']},
 'HLA_DRA_ANTIGEN':{'q':'HLA-DRA','target':['CD74','HLA-DPA1','HLA-DMA','IFI30'],'heldout':['HLA-DMB','CTSS']},
}
# Immutable local historical sources, not current FULL104 or protected confirmation.
with zipfile.ZipFile(ROOT/'FOUNDATION_CALIBRATION_BUNDLE_20260824.zip') as z:
 sfile=next(n for n in z.namelist() if n.endswith('FOUNDATION_OPERATOR_ADDRESS_OBSERVATION_STATE.npz'))
 with np.load(io.BytesIO(z.read(sfile)),allow_pickle=False) as d: states=d['states']; operators=d['operator_index']; assert np.array_equal(operators,np.arange(42))
 n=next(n for n in z.namelist() if n.endswith('address_namespace.csv'))
 namespace=pd.read_csv(z.open(n),usecols=['molecular_address_index','symbol','identity_class','current_ensembl_gene_id'])
 nd=namespace[namespace.identity_class.eq('current_exact')];symbol_map=dict(zip(nd.symbol,nd.molecular_address_index))
 sby=hashlib.sha256(z.read(n)).hexdigest()
spec=importlib.util.spec_from_file_location('historical',ROOT/'JEPA_TINY_TOURNAMENT_20260926.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
meta=f.meta;donor=meta.donor_id.to_numpy();ops=meta.operator_index.to_numpy();micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy()
D=np.array(sorted(set(donor[micro])));assert len(D)==50;perm=np.random.default_rng(seed).permutation(D);folds=np.array_split(perm,5)
used_ops=np.unique(ops);eligible=f.eligible
for name,program in PREDECLARED.items():
 idx=[int(symbol_map[s]) for s in [program['q']]+program['target']+program['heldout']]
 assert len(set(idx))==7 and all(i not in set(symbol_map.values())-set(nd.molecular_address_index) for i in idx)
 assert all(np.all(states[used_ops,i]==1) for i in idx[:5]),f'UNMEASURED_TEACHER_ACROSS_OPERATOR: {name}'
 # Held-out readout genes may have narrower support; score only when BOTH are measured.
program_addrs={name:{typ:[int(symbol_map[g]) for g in v] if isinstance(v,list) else int(symbol_map[v]) for typ,v in p.items()} for name,p in PREDECLARED.items()}
excluded=set(a for x in program_addrs.values() for kind,v in x.items() for a in (v if isinstance(v,list) else [v]))
assert len(excluded)==21

def r2(Y,P,ref):
 den=np.square(Y-ref).sum()
 return float(1-np.square(Y-P).sum()/den) if den>0 else None

def std(x,w):
 w=w/w.sum();m=w@x;sd=np.maximum(np.sqrt(w@((x-m)**2)),.07);return m,sd

def fit_predict(x,y,w,xe,a=20.):
 m,sd=std(x,w);return Ridge(alpha=a).fit((x-m)/sd,y,sample_weight=w/w.mean()).predict((xe-m)/sd)

def program_log(mat):
 tot=mat.sum(1,keepdims=True)
 return np.log1p(np.divide(mat*10000,tot,out=np.zeros_like(mat,dtype=np.float64),where=tot>0))

def sub_micro(indices):return indices[micro[indices]]
records=[];checks=[];source_folds=[]
for fi,held in enumerate(folds):
 rest=perm[~np.isin(perm,held)];rng=np.random.default_rng(20261010+fi);rr=rng.permutation(rest);tr=np.flatnonzero(np.isin(donor,rr[8:]));va=np.flatnonzero(np.isin(donor,rr[:8]));te=np.flatnonzero(np.isin(donor,held));tm=sub_micro(tr);em=sub_micro(te)
 assert len(tm)>25 and len(em)>25 and len(set(donor[te]))==10
 assert not (set(donor[tr])&set(donor[va]) or set(donor[tr])&set(donor[te]) or set(donor[va])&set(donor[te]))
 # Frozen gene lists were declared before any test data analysis. Select only complementary student genes using TRAIN microglia.
 mat=f.rawX[tm][:,eligible].toarray().astype(np.float64);pre=(mat>0).mean(0);vari=np.var(np.log1p(mat),axis=0)
 cand=np.flatnonzero((pre>.1)&(pre<.98));cand=cand[np.argsort(-vari[cand],kind='stable')]
 sel=[int(eligible[i]) for i in cand if int(eligible[i]) not in excluded][:700]
 assert len(sel)==700 and not(set(sel)&excluded)
 panel_raw=f.rawX[:,sel].toarray().astype(np.float64)
 # Three masked student views, with normalization done only AFTER masking within allowed panel.
 def masked(seedval):
  rr=np.random.default_rng(seedval);keep=rr.random(panel_raw.shape)>.40
  return program_log(np.where(keep,panel_raw,0))
 mviews=[masked(910000+fi*3+j) for j in range(3)];mtest=masked(920000+fi)
 # fit common student PCA from training-only visible RNA, 3 independently masked views.
 X=np.vstack([v[tr] for v in mviews]);E=mtest[te];d,midx,cnts=np.unique(donor[tr],return_inverse=True,return_counts=True);w=(1/cnts[midx])*(len(tr)/len(d));ww=np.tile(w/3,3)
 mean,sd=std(X,ww); _,_,vt=randomized_svd((X-mean)/sd*np.sqrt(ww[:,None]/ww.sum()),n_components=32,n_iter=4,random_state=3500+fi)
 Z=(X-mean)/sd@vt.T;Ze=(E-mean)/sd@vt.T
 # Folds all-cell technical baseline fit on microglia rows. 15 operator onehot + visible student panel technical stats.
 oh=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(ops[tr,None])
 def tech(v):return np.c_[oh.transform(ops[:,None]),np.log1p(v.sum(1)),(v>0).sum(1),v.var(1)]
 tx=[tech(v) for v in mviews];xt=np.vstack([v[tr] for v in tx]);et=tech(mtest)[te]
 tsel=np.tile(micro[tr],3); ze_micro=np.flatnonzero(micro[te]); ztrain=Z[tsel];ttrain=xt[tsel];mw=ww[tsel]
 # pooled query-blind readout with q-specific TRAIN-only intercepts tests whether q x cell is informative
 qtrain=[];qpred=[];qbase=[];techpred=[];teacherpred=[];teacherplusq=[];qonly=[];target_test=[];hout=[];eligible_te=[]
 # 'generic biological program' comparator predicts all 3 q target panels with one common slope + per-query train means.
 for label,p in PREDECLARED.items():
  address=program_addrs[label]
  target=f.rawX[:,address['target']].toarray().astype(np.float64)
  qc=f.rawX[:,address['q']].toarray().astype(np.float64).reshape(-1,1)
  h=f.rawX[:,address['heldout']].toarray().astype(np.float64)
  valid=(target.sum(1)>0)  # held-out readout zeros are observed, not missingness; readout support checked separately
  # Exactly one historical LPL readout may have missing support: remove unmeasured components per cell.
  # LPL measured in 11/15 operators; its absence must never be interpreted as a zero transcript.
  hsupport=np.stack([states[ops,i]==1 for i in address['heldout']],axis=1)
  hlog=np.log1p(h);hlog=np.where(hsupport,hlog,np.nan)
  Y=program_log(target) if MODE=='COMPOSITION' else np.log1p(target)
  # q value can be provided to rich teacher but is NOT included in the measured contextual program.
  assert np.array_equal((program_log(target) if MODE=='COMPOSITION' else np.log1p(target)),Y)
  tr_ok=micro[tr]&valid[tr];te_ok=micro[te]&valid[te]
  # same original cell q counterfactual must not change measured target or student preprocessing
  assert np.array_equal(Y[te],(program_log(target[te]) if MODE=='COMPOSITION' else np.log1p(target[te])))
  ry=np.tile(Y[tr[tr_ok]],(3,1)); choose=np.tile(tr_ok,3);qww=ww[choose]
  tmp_idx=te_ok;pred=fit_predict(Z[choose],ry,qww,Ze)
  tb=fit_predict(xt[choose],ry,qww,et)
  tY=Y[tr[tr_ok]];hq=hlog[tr[tr_ok]];hqmask=np.all(np.isfinite(hq),axis=1)
  evalmask=te_ok&np.all(np.isfinite(hlog[te]),axis=1)
  # Teacher-only FIDELITY question: do the teacher's observed non-q context genes
  # predict independently withheld same-assay genes beyond technical measurements? NOTE not external biology.
  trh=tr[tr_ok][hqmask];wh=w[tr_ok][hqmask];teh=te[evalmask]
  h_teacher=fit_predict(Y[trh],hlog[trh],wh,Y[teh]) if len(trh)>20 and len(teh)>8 else None
  # restrict technical teacher features to STUDENT gene panel (not target gene descendants)
  trtec=tx[0][trh]; tetec=et[np.flatnonzero(evalmask)]
  h_tech=fit_predict(trtec,hlog[trh],wh,tetec) if h_teacher is not None else None
  h_plus_tech=fit_predict(np.c_[Y[trh],trtec],hlog[trh],wh,np.c_[Y[teh],tetec]) if h_teacher is not None else None
  h_plus_tech_q=fit_predict(np.c_[Y[trh],trtec,np.log1p(qc[trh])],hlog[trh],wh,np.c_[Y[teh],tetec,np.log1p(qc[teh])]) if h_teacher is not None else None
  h_q=fit_predict(np.log1p(qc[trh]),hlog[trh],wh,np.log1p(qc[teh])) if h_teacher is not None else None
  records.append({'fold':fi,'program':label,'section':'TEACHER_READOUT_ESTIMABILITY','arm':'MEASURED_BOTH_READOUTS','n_train_micro':int(len(trh)),'n_test_micro':int(len(teh)),'n_test_donors':int(len(set(donor[teh]))),'r2':None})
  if h_teacher is not None:
   href=np.average(hlog[trh],axis=0,weights=wh)
   for tag,guess in [('TEACHER_PROGRAM_ONLY',h_teacher),('TEACHER_TECH_ONLY',h_tech),('TEACHER_PROGRAM_PLUS_TECH',h_plus_tech),('TEACHER_PROGRAM_PLUS_TECH_PLUS_Q',h_plus_tech_q),('TEACHER_Q_COUNT_ONLY',h_q)]:
    records.append({'fold':fi,'program':label,'section':'TEACHER_FIDELITY_RNA_ONLY','arm':tag,'r2':r2(hlog[teh],guess,href),'n_test_micro':len(teh),'n_test_donors':len(set(donor[teh]))})
  # Generic q-specific output offset but common cell slope, fitted later on pooled four-coordinate targets.
  reference=np.average(Y[tr[tr_ok]],axis=0,weights=w[tr_ok]); qtrain.append(Z[choose]);qbase.append(reference)
  qpred.append(pred);techpred.append(tb);target_test.append(Y[te]); eligible_te.append(tmp_idx);qonly.append(np.broadcast_to(reference,pred.shape))
  # preserve fixed target coordinate names; wrong-query swap is NOT interpretable across different panels.
  qtrain[-1]=(Z[choose],ry-reference,qww)
  for typ,pp in [('STUDENT_QUERY_SPECIFIC',pred),('TECHNICAL',tb),('QUERY_MEAN_ONLY',qonly[-1])]:
   records.append({'fold':fi,'program':label,'section':'STUDENT_MEASURED_TARGET','arm':typ,'r2':r2(Y[te][tmp_idx],pp[tmp_idx],reference),'n_test_micro':int(tmp_idx.sum()),'n_test_donors':len(set(donor[te][tmp_idx]))})
  checks.append({'fold':fi,'program':label,'target_genes':p['target'],'readout_genes':p['heldout'],'q':p['q'],'student_disjoint':not(set(sel)&set([address['q']]+address['target']+address['heldout'])),'all_target_support':all(np.all(states[used_ops,k]==1) for k in address['target']),'heldout_support_fraction':float(np.mean(hsupport[te])),'q_target_count_independent':True})
 B=np.vstack([e[0] for e in qtrain]);R=np.vstack([e[1] for e in qtrain]);BW=np.concatenate([e[2] for e in qtrain]);common=fit_predict(B,R,BW,Ze)
 for qi,label in enumerate(PREDECLARED):
  baseline=qbase[qi];testidx=eligible_te[qi];yp=target_test[qi];generic=common+baseline
  records.append({'fold':fi,'program':label,'section':'STUDENT_MEASURED_TARGET','arm':'SHARED_SLOPE_QUERY_OFFSET','r2':r2(yp[testidx],generic[testidx],baseline),'n_test_micro':int(testidx.sum()),'n_test_donors':len(set(donor[te][testidx]))})
 source_folds.append({'fold':fi,'n_micro_train':len(tm),'n_micro_test':len(em),'n_train_donors':len(set(donor[tr])),'n_val_donors':len(set(donor[va])),'n_test_donors':len(set(donor[te])),'student_gene_list_sha256':hashlib.sha256(np.array(sel,dtype='<i4').tobytes()).hexdigest(),'student_gene_count':len(sel),'excluded_marker_count':len(excluded)})
 print('FOLD',fi,'teacher/student complete',flush=True)
summary={}
for section in sorted({r['section'] for r in records}):
 summary[section]={}
 for program in PREDECLARED:
  z=[r for r in records if r['section']==section and r['program']==program]
  summary[section][program]={a:(float(np.mean([rr['r2'] for rr in z if rr['arm']==a and rr['r2'] is not None])) if any(rr['r2'] is not None for rr in z if rr['arm']==a) else None) for a in sorted({rr['arm'] for rr in z})}
result={'schema':'JEPA_R7_PREDECLARED_BIOLOGICAL_PROGRAM_FALSIFIER_NONAUTHORIZING','target_mode':MODE,'development_only':True,'programs_predeclared_before_run':PREDECLARED,'current_full104_authority':False,'independent_biological_validation':False,'same_assay_heldout_readouts_are_not_external_biology':True,'all_historical_test_donors_reused_in_prior_R1_R6':True,'source_namespace_sha256':sby,'source_archive_sha256':'07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444','n_folds':5,'n_distinct_test_donors':50,'records':records,'summary':summary,'source_folds':source_folds,'checks':checks,'elapsed_sec':round(time.time()-started,2),'training_authorized':False,'protected_opened':False}
path=ROOT/f'JEPA_R7_PROGRAM_FALSIFIER_{MODE}_RESULTS_20260926.json';path.write_text(json.dumps(result,indent=2));print('SAVED',path,'ELAPSED',result['elapsed_sec']);print(json.dumps(summary,indent=2))
