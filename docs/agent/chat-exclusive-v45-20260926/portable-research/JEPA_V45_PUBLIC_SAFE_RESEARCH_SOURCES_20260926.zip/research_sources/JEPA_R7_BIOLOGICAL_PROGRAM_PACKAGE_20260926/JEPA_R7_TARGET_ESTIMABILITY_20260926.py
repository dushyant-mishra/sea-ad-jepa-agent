#!/usr/bin/env python3
"""Descriptive R7 target support/count thinning on historical, reused microglia-labelled cells.
No target selection/qualification, no additional held-out outcome inspection.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='1'
import numpy as np,scipy.sparse as sp,pandas as pd,json
from pathlib import Path
R=Path('/mnt/data');meta=pd.read_csv('/tmp/jepa_tour_meta.csv');micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy();donor=meta.donor_id.to_numpy();ops=meta.operator_index.to_numpy();X=sp.load_npz('/tmp/jepa_tour_logexpr.npz')
# Validate per original dataset inversion (expm1 ratio to smallest positive = UMI count) only in selected columns.
const={'APOE_LIPID':[6188,11425,7194,2044],'P2RY12_HOMEOSTATIC':[15109,12239,12995,13365],'HLA_DRA_ANTIGEN':[392,23673,18500,20496]};scores={}
for name,cols in const.items():
 arr=X[:,cols].toarray();min_nonzero=np.array([np.min(X.data[X.indptr[i]:X.indptr[i+1]]) for i in range(X.shape[0])]);base=np.expm1(min_nonzero)
 raw=np.rint(np.expm1(arr)/base[:,None]).astype(np.int64);assert np.max(abs(np.expm1(arr)/base[:,None]-raw))<1e-6
 T=raw[micro];total=T.sum(1);nm=total>0;dm=donor[micro]
 rng=np.random.default_rng(70000+len(cols)+sum(cols));A=rng.binomial(T,.5);B=T-A
 both=(A.sum(1)>0)&(B.sum(1)>0)
 def trans(a):
  total=a.sum(1,keepdims=True);return np.log1p(np.divide(10000*a,total,out=np.zeros_like(a,dtype=float),where=total>0))
 a=trans(A[both]);b=trans(B[both]);mid=(a+b)/2;diff=(a-b)/2;between=float(np.mean((mid-mid.mean(0))**2));noise=float(np.mean(diff**2));repeat=(between-noise)/(between+noise) if between+noise>0 else None
 bydonor={str(d):int(np.sum(nm[dm==d])) for d in sorted(set(dm))}
 scores[name]={'n_micro':int(micro.sum()),'n_nonzero_program':int(nm.sum()),'fraction_nonzero':float(nm.mean()),'donors_with_nonzero':int(sum(n>0 for n in bydonor.values())),'donors_total':len(bydonor),'donors_ge3_cells':int(sum(n>=3 for n in bydonor.values())),'median_raw_umis_nonzero':float(np.median(total[nm])) if nm.any() else 0,'test_count_thinning_both_half_nonzero':int(both.sum()),'thinning_repeatability_proxy':repeat,'per_donor_positive_counts':bydonor,'measurement_support':'all 15 used operators, all 4 teacher target genes'}
result={'schema':'JEPA_R7_HISTORICAL_TEACHER_TARGET_ESTIMABILITY_NONAUTHORIZING','source':'same historical 1561 cell sample developed repeatedly R1-R7','scope':'target counts, support and binomial thinning repeatability, not independent biological fidelity','results':scores,'train_authorized':False}
(R/'JEPA_R7_TARGET_ESTIMABILITY_RESULTS_20260926.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:{x:y for x,y in v.items() if x!='per_donor_positive_counts'} for k,v in scores.items()},indent=2))
