"""R15 review successor of V5 control sensitivity ledger. Developmental, not authority.

The test harness must classify only actual executions and must never treat a
statistically unresolved effect as an invalid experimental design.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping
import hashlib
import json
import math
import struct

FIRED = "FIRED"
QUIET = "QUIET"
REFUSED_DEGENERATE = "REFUSED_DEGENERATE"
SENSITIVE = "SENSITIVE"
VACUOUS_DID_NOT_FIRE = "VACUOUS_DID_NOT_FIRE"
FALSE_POSITIVE_ON_HEALTHY = "FALSE_POSITIVE_ON_HEALTHY"
INVALID_HEALTHY_REFUSAL = "INVALID_HEALTHY_REFUSAL"
INVALID_PLANTED_REFUSAL = "INVALID_PLANTED_REFUSAL"
SCORED_A_DEGENERATE_CONFIG = "SCORED_A_DEGENERATE_CONFIG"
INCOMPLETE_LEGS = "INCOMPLETE_LEGS"
MISMATCHED_LEGS = "MISMATCHED_LEGS"
INCONCLUSIVE = "INCONCLUSIVE"
POSITIVE_EFFECT = "POSITIVE_EFFECT"
NEGATIVE_EFFECT = "NEGATIVE_EFFECT"

class DegenerateConfiguration(ValueError):
    pass

@dataclass(frozen=True)
class LegResult:
    leg: str
    outcome: str
    detail: Mapping[str, Any] = field(default_factory=dict)
    def __post_init__(self):
        if self.leg not in ("healthy", "planted", "degenerate"):
            raise ValueError("unknown leg")
        if self.outcome not in (FIRED, QUIET, REFUSED_DEGENERATE):
            raise ValueError("unknown outcome")

def run_leg(fn: Callable[[], bool], leg: str) -> LegResult:
    if leg not in ("healthy", "planted", "degenerate"):
        raise ValueError("unknown leg")
    try:
        result = fn()
    except DegenerateConfiguration as exc:
        return LegResult(leg, REFUSED_DEGENERATE, {"reason": str(exc)})
    if type(result) is not bool:
        raise TypeError("control must return bool or raise DegenerateConfiguration")
    return LegResult(leg, FIRED if result else QUIET)

def classify(healthy: LegResult, planted: LegResult, degenerate: LegResult | None) -> str:
    if (healthy.leg != "healthy" or planted.leg != "planted" or
        (degenerate is not None and degenerate.leg != "degenerate")):
        return MISMATCHED_LEGS
    if degenerate is None:
        return INCOMPLETE_LEGS
    if healthy.outcome == FIRED:
        return FALSE_POSITIVE_ON_HEALTHY
    if healthy.outcome != QUIET:
        return INVALID_HEALTHY_REFUSAL
    if planted.outcome == REFUSED_DEGENERATE:
        return INVALID_PLANTED_REFUSAL
    if planted.outcome != FIRED:
        return VACUOUS_DID_NOT_FIRE
    if degenerate.outcome != REFUSED_DEGENERATE:
        return SCORED_A_DEGENERATE_CONFIG
    return SENSITIVE

@dataclass
class ControlSensitivityLedger:
    entries: dict[str, dict[str, Any]] = field(default_factory=dict)
    def record(self, control_id: str, *, healthy: LegResult, planted: LegResult,
               degenerate: LegResult | None, source: str, notes: str = "") -> str:
        if not control_id.strip() or not source.strip() or control_id in self.entries:
            raise ValueError("missing source/id or duplicate control")
        verdict = classify(healthy, planted, degenerate)
        self.entries[control_id] = {
            "control_id": control_id, "source": source,
            "healthy": vars(healthy), "planted": vars(planted),
            "degenerate": vars(degenerate) if degenerate is not None else None,
            "verdict": verdict, "notes": notes,
        }
        return verdict
    def summary(self) -> dict[str, Any]:
        if not self.entries:
            raise ValueError("cannot summarize empty ledger")
        counts: dict[str, int] = {}
        for item in self.entries.values():
            k = item["verdict"]
            counts[k] = counts.get(k, 0) + 1
        payload = {"schema": "V5_CONTROL_SENSITIVITY_LEDGER_V2_RESEARCH",
                   "controls": len(self.entries), "verdict_counts": counts,
                   "all_sensitive": counts.get(SENSITIVE, 0) == len(self.entries),
                   "entries": [self.entries[k] for k in sorted(self.entries)],
                   "training_authorized": False}
        payload["ledger_digest"] = hashlib.sha256(json.dumps(payload, sort_keys=True,
                                        allow_nan=False).encode()).hexdigest()
        return payload

def effect_direction(ci_lower: float, ci_upper: float) -> str:
    """Statistical uncertainty must not be confused with a degenerate comparison.

    CIs report whether zero is excluded, not whether the experiment is valid.
    """
    if not all(math.isfinite(v) for v in (ci_lower, ci_upper)) or ci_lower > ci_upper:
        raise ValueError("invalid CI")
    if ci_lower > 0:
        return POSITIVE_EFFECT
    if ci_upper < 0:
        return NEGATIVE_EFFECT
    return INCONCLUSIVE

def _canonical_float(x: float) -> str:
    if not math.isfinite(x):
        raise DegenerateConfiguration("nonfinite value in control structure")
    return struct.pack(">d", x).hex()

def canonical_array_digest(value: Any) -> str:
    """Canonical semantic representation of numeric arrays, never repr().

    Includes shape and dtype to reject a 1xN matrix impersonating an N vector.
    Rejects object and nonfinite arrays; canonicalizes endianness/strides.
    """
    import numpy as np
    arr = np.asarray(value)
    if arr.dtype.kind not in "biuf" or arr.size == 0:
        raise DegenerateConfiguration("invalid/non-numeric/empty control array")
    if arr.dtype.kind == "f" and not np.isfinite(arr).all():
        raise DegenerateConfiguration("nonfinite control array")
    kind = "float" if arr.dtype.kind == "f" else ("bool" if arr.dtype.kind == "b" else ("uint" if arr.dtype.kind == "u" else "int"))
    # normalizing byte order also makes native/little/big array encodings identical
    if kind == "float":
        vals = [_canonical_float(float(x)) for x in arr.flat]
    elif kind == "bool":
        vals = [bool(x) for x in arr.flat]
    else:
        vals = [int(x) for x in arr.flat]
    payload = {"kind": kind, "dtype_bits": 8 * arr.dtype.itemsize, "shape": list(arr.shape), "values": vals}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def require_distinct_arrays(a: Any, b: Any, *, label: str) -> tuple[str, str]:
    da, db = canonical_array_digest(a), canonical_array_digest(b)
    if da == db:
        raise DegenerateConfiguration(f"{label}: numerically identical arrays")
    return da, db

def canonical_graph_digest(edges: Any) -> str:
    """Graph equality is independent of edge row order but sensitive to weights.

    Input: iterable of (source canonical ID, destination canonical ID, weight).
    Directed, weighted, duplicate-free: duplicate edges refuse evaluation.
    """
    seen: set[tuple[str, str]] = set()
    canon = []
    for src, dst, weight in edges:
        if not isinstance(src, str) or not src or not isinstance(dst, str) or not dst:
            raise DegenerateConfiguration("missing graph node identity")
        pair = (src, dst)
        if pair in seen:
            raise DegenerateConfiguration("duplicate graph edge")
        seen.add(pair)
        canon.append((src, dst, _canonical_float(float(weight))))
    if not canon:
        raise DegenerateConfiguration("empty graph has no structure")
    raw = json.dumps(sorted(canon), separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()

def require_distinct_graphs(a: Any, b: Any) -> tuple[str, str]:
    da, db = canonical_graph_digest(a), canonical_graph_digest(b)
    if da == db:
        raise DegenerateConfiguration("graph structures are identical")
    return da, db

def require_graph_intervention_strength(
    real_edges: Any, control_edges: Any, *,
    min_changed_edge_fraction: float = 0.2,
    max_abs_weight_correlation: float = 0.5,
) -> dict[str, float | str]:
    """Separate nonidentity from an informative structural intervention.

    A distinct hash is only necessary. This also requires substantial topology
    change and a computable weighted-edge correlation on the same edge union.
    Deliberately excludes self-loops and duplicate edges from invalid controls.
    Unstable/constant correlation cannot be interpreted as low correlation.
    Thresholds are prospective *diagnostic* defaults, not V5 authority.
    """
    import numpy as np
    if not (0 < min_changed_edge_fraction <= 1 and
            0 <= max_abs_weight_correlation < 1):
        raise ValueError("invalid declared structural thresholds")
    # Snapshot iterable inputs once. Reusing generators after the digest pass
    # would otherwise silently score two empty graphs.
    real_edges, control_edges = tuple(real_edges), tuple(control_edges)
    da, db = require_distinct_graphs(real_edges, control_edges)
    def edge_dict(items):
        out = {}
        for src, dst, weight in items:
            if src == dst:
                raise DegenerateConfiguration("self-loop in structural control")
            edge = (src, dst)
            if edge in out:
                raise DegenerateConfiguration("duplicate edge")
            val = float(weight)
            if not math.isfinite(val):
                raise DegenerateConfiguration("nonfinite edge weight")
            out[edge] = val
        return out
    a, b = edge_dict(real_edges), edge_dict(control_edges)
    union = sorted(set(a) | set(b))
    if len(union) < 3:
        raise DegenerateConfiguration("too few edges for structural-correlation gate")
    fraction = len(set(a) ^ set(b)) / len(union)
    if fraction < min_changed_edge_fraction:
        raise DegenerateConfiguration("structural change below declared threshold")
    va = np.asarray([a.get(e, 0.) for e in union], dtype=float)
    vb = np.asarray([b.get(e, 0.) for e in union], dtype=float)
    if np.std(va) == 0 or np.std(vb) == 0:
        raise DegenerateConfiguration("constant adjacency; correlation undefined")
    correlation = float(np.corrcoef(va, vb)[0, 1])
    if not math.isfinite(correlation):
        raise DegenerateConfiguration("nonfinite graph correlation")
    if abs(correlation) > max_abs_weight_correlation:
        raise DegenerateConfiguration("control graph still too correlated with real graph")
    return {"real_digest": da, "control_digest": db,
            "changed_edge_fraction": fraction,
            "weighted_edge_correlation": correlation,
            "status": "STRUCTURALLY_DISTINCT_RESEARCH_DIAGNOSTIC_ONLY"}
