from __future__ import annotations
import pathlib
import sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import numpy as np
import pytest
from control_sensitivity_ledger_v2 import *

def leg(name,out):return LegResult(name,out)

@pytest.mark.parametrize("h,p,d,expected",[
 (QUIET,FIRED,REFUSED_DEGENERATE,SENSITIVE),
 (REFUSED_DEGENERATE,FIRED,REFUSED_DEGENERATE,INVALID_HEALTHY_REFUSAL),
 (FIRED,FIRED,REFUSED_DEGENERATE,FALSE_POSITIVE_ON_HEALTHY),
 (QUIET,QUIET,REFUSED_DEGENERATE,VACUOUS_DID_NOT_FIRE),
 (QUIET,REFUSED_DEGENERATE,REFUSED_DEGENERATE,INVALID_PLANTED_REFUSAL),
 (QUIET,FIRED,FIRED,SCORED_A_DEGENERATE_CONFIG),
 (QUIET,FIRED,QUIET,SCORED_A_DEGENERATE_CONFIG),
])
def test_truth_table(h,p,d,expected):
 assert classify(leg('healthy',h),leg('planted',p),leg('degenerate',d))==expected

def test_wrong_leg_labels():
 assert classify(leg('planted',QUIET),leg('healthy',FIRED),leg('degenerate',REFUSED_DEGENERATE))==MISMATCHED_LEGS
 assert classify(leg('healthy',QUIET),leg('planted',FIRED),leg('planted',REFUSED_DEGENERATE))==MISMATCHED_LEGS

def test_missing_leg():assert classify(leg('healthy',QUIET),leg('planted',FIRED),None)==INCOMPLETE_LEGS

def test_nonboolean_is_not_silent_truthiness():
 with pytest.raises(TypeError):run_leg(lambda: 'SUCCESS','planted')
 with pytest.raises(TypeError):run_leg(lambda: None,'healthy')

def test_exception_is_not_fired():
 with pytest.raises(RuntimeError):run_leg(lambda: (_ for _ in ()).throw(RuntimeError('unrelated failure')),'planted')

def test_valid_degeneracy():
 assert run_leg(lambda: (_ for _ in ()).throw(DegenerateConfiguration('not identifiable')),'degenerate').outcome==REFUSED_DEGENERATE

def test_meta_vacuity():
 led=ControlSensitivityLedger(); led.record('vac',healthy=leg('healthy',QUIET), planted=leg('planted',QUIET),degenerate=leg('degenerate',REFUSED_DEGENERATE),source='fixture')
 assert led.summary()['all_sensitive'] is False
 assert led.summary()['verdict_counts'][VACUOUS_DID_NOT_FIRE]==1

def test_digest_non_authorizing():
 led=ControlSensitivityLedger();led.record('x', healthy=leg('healthy',QUIET),planted=leg('planted',FIRED),degenerate=leg('degenerate',REFUSED_DEGENERATE),source='fixture')
 out=led.summary();assert out['all_sensitive'] and not out['training_authorized'] and len(out['ledger_digest'])==64

@pytest.mark.parametrize('bounds,expected',[
 ((-0.019597,0.000169),INCONCLUSIVE),
 ((0.00136,0.02209),POSITIVE_EFFECT),
 ((-0.022,-0.001),NEGATIVE_EFFECT),
 ((0,0),INCONCLUSIVE),
 ((0,0.1),INCONCLUSIVE),
 ((-0.1,0),INCONCLUSIVE),
])
def test_ci(bounds,expected):assert effect_direction(*bounds)==expected

@pytest.mark.parametrize('bounds',[(2,1),(0,float('nan')),(float('inf'),1)])
def test_invalid_ci(bounds):
 with pytest.raises(ValueError):effect_direction(*bounds)

def test_equivalent_array_views_refused():
 a=np.arange(24,dtype='<f8').reshape(6,4)
 b=np.asfortranarray(a).astype('>f8')
 with pytest.raises(DegenerateConfiguration):require_distinct_arrays(a,b,label='array')

def test_duplicate_float_content_refused():
 with pytest.raises(DegenerateConfiguration):require_distinct_arrays([1.,2.],[1.,2.],label='copy')

def test_array_shape_matters():
 assert canonical_array_digest(np.array([[1,2]]))!=canonical_array_digest(np.array([1,2]))

def test_different_data_distinct():require_distinct_arrays([1.,2.],[1.,2.001],label='good')

def test_nonfinite_and_object_refuse():
 for arr in ([1,float('nan')],['x','y'],[]):
  with pytest.raises(DegenerateConfiguration):canonical_array_digest(arr)

def test_graph_row_order_refused():
 a=[('a','b',1.),('b','c',2.)];b=list(reversed(a))
 with pytest.raises(DegenerateConfiguration):require_distinct_graphs(a,b)

def test_graph_weight_is_real_change():
 require_distinct_graphs([('a','b',1.)],[('a','b',2.)])

def test_graph_directed_edges_distinct():
 require_distinct_graphs([('a','b',1.)],[('b','a',1.)])

def test_graph_duplicates_refuse():
 with pytest.raises(DegenerateConfiguration):canonical_graph_digest([('a','b',1.),('a','b',1.)])

def test_empty_graph_refuses():
 with pytest.raises(DegenerateConfiguration):canonical_graph_digest([])


def test_dtype_width_bound_even_if_values_same():
 assert canonical_array_digest(np.array([1., 2.], dtype=np.float32)) != canonical_array_digest(np.array([1., 2.], dtype=np.float64))

def test_graph_hash_distinct_does_not_guarantee_meaningful_intervention():
 a=[('a','b',1.),('b','c',2.),('c','d',3.),('d','e',4.)]
 b=[('a','b',1.000001),('b','c',2.),('c','d',3.),('d','e',4.)]
 require_distinct_graphs(a,b)
 with pytest.raises(DegenerateConfiguration,match='structural change below'):
  require_graph_intervention_strength(a,b)

def test_graph_intervention_real_structural_change_passes():
 a=[('a','b',1.),('b','c',2.),('c','d',3.),('d','e',4.)]
 b=[('a','c',1.),('b','d',-2.),('c','e',3.),('d','f',-4.)]
 receipt=require_graph_intervention_strength(a,b)
 assert receipt['changed_edge_fraction']==1 and receipt['status'].startswith('STRUCTURALLY_DISTINCT')

def test_graph_intervention_identical_refuses():
 a=[('a','b',1.),('b','c',2.),('c','d',3.)]
 with pytest.raises(DegenerateConfiguration):require_graph_intervention_strength(a,list(reversed(a)))

def test_graph_intervention_weak_single_edge_refuses():
 with pytest.raises(DegenerateConfiguration):require_graph_intervention_strength([('a','b',1.)],[('b','c',2.)])


def test_graph_generator_inputs_have_same_gate_result_as_lists():
 a=[('a','b',1.),('b','c',2.),('c','d',3.),('d','e',4.)]
 b=[('a','c',1.),('b','d',-2.),('c','e',3.),('d','f',-4.)]
 result=require_graph_intervention_strength(iter(a),iter(b))
 assert result['changed_edge_fraction']==1.0
