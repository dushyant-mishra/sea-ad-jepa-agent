"""Adversarial evidence: deliberately break R15 and prove regression tests go red."""
from __future__ import annotations
import pathlib, shutil, subprocess, sys, tempfile, json
ROOT=pathlib.Path(__file__).resolve().parent
orig=(ROOT/'control_sensitivity_ledger_v2.py').read_text()
tests=(ROOT/'test_control_sensitivity_ledger_v2.py').read_text()
mutations={
 'ACCEPT_HEALTHY_REFUSAL':(
   'if healthy.outcome != QUIET:\n        return INVALID_HEALTHY_REFUSAL',
   'if healthy.outcome != QUIET and healthy.outcome != REFUSED_DEGENERATE:\n        return INVALID_HEALTHY_REFUSAL'),
 'MISLABEL_LEGS_ACCEPTED':(
   'return MISMATCHED_LEGS',
   'return SENSITIVE'),
 'INCONCLUSIVE_INTERVAL_CALLED_NEGATIVE':(
   'return INCONCLUSIVE\n\ndef _canonical_float',
   'return NEGATIVE_EFFECT\n\ndef _canonical_float'),
 'IGNORE_GRAPH_EDGE_WEIGHTS':(
   'canon.append((src, dst, _canonical_float(float(weight))))',
   'canon.append((src, dst, "IGNORED_WEIGHT"))'),
 'GRAPH_DISTINCT_HASH_ACCEPTED_AS_SUFFICIENT':(
   'if fraction < min_changed_edge_fraction:',
   'if False and fraction < min_changed_edge_fraction:'),
 'TREAT_RUNTIME_ERROR_AS_PLANTED_PASS':(
   'except DegenerateConfiguration as exc:\n        return LegResult(leg, REFUSED_DEGENERATE, {"reason": str(exc)})',
   'except RuntimeError:\n        return LegResult(leg, FIRED)\n    except DegenerateConfiguration as exc:\n        return LegResult(leg, REFUSED_DEGENERATE, {"reason": str(exc)})'),
}
results=[]
for name,(needle,repl) in mutations.items():
    assert orig.count(needle)==1,(name,orig.count(needle))
    with tempfile.TemporaryDirectory() as tmp:
        d=pathlib.Path(tmp)
        (d/'control_sensitivity_ledger_v2.py').write_text(orig.replace(needle,repl))
        (d/'test_control_sensitivity_ledger_v2.py').write_text(tests)
        p=subprocess.run([sys.executable,'-m','pytest','-q','test_control_sensitivity_ledger_v2.py'],cwd=d,text=True,capture_output=True)
        failed=p.returncode!=0
        rows=[line for line in p.stdout.splitlines() if line.startswith('FAILED ')]
        results.append({'mutation':name,'detected':failed,'failing_tests':rows[:8],'test_command':'python -m pytest -q test_control_sensitivity_ledger_v2.py'})
        print(name, 'DETECTED' if failed else 'MISSED',rows[:5])
with (ROOT/'R15_MUTATION_RESULTS.json').open('w') as fh:json.dump(results,fh,indent=2)
if not all(r['detected'] for r in results):raise SystemExit('R15_MUTATION_SUITE_FAILED')
