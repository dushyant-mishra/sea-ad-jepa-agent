"""R12 outcome-blind research target and biological-evaluation readiness contract.

Does not declare biological fidelity, issue current-V5 authority, or open ATAC.
Teacher is permitted measured q only as an explicitly assigned *input*, never
as a disguised measured-anchor coordinate. Students get disjoint lawful RNA.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json

class TargetContractError(ValueError): pass

@dataclass(frozen=True)
class QueryTargetContract:
    q: int
    partner: tuple[int, ...]
    reference: tuple[int, ...]
    student: tuple[int, ...]
    teacher_policy: str
    same_original_cell: bool = True
    measured_anchor: str = "ACTIVITY_AND_CLR_COMPOSITION_WITH_SUPPORT_AND_UNCERTAINTY"
    query_conditioning: bool = True
    independent_biology_falsifier: str = "DONOR_LEVEL_RESERVED_ATAC_ONLY"
    training_authorized: bool = False

    def validate(self):
        if type(self.q) is not int or not 0 <= self.q < 41238:
            raise TargetContractError("invalid query")
        if len(self.partner) != 4 or len(self.reference) != 8 or not self.student:
            raise TargetContractError("incomplete measured-anchor or student panel")
        if self.teacher_policy not in ("RICH_Q_OBSERVED", "Q_EXCLUDED"):
            raise TargetContractError("unknown teacher evidence policy")
        roles=(self.q,) + self.partner + self.reference + self.student
        if any(type(x) is not int or not 0 <= x < 41238 for x in roles) or len(roles)!=len(set(roles)):
            raise TargetContractError("duplicate/out-of-universe role; query, partners, reference, student must be disjoint")
        if self.same_original_cell is not True or self.query_conditioning is not True:
            raise TargetContractError("unpaired or query-agnostic target")
        if self.measured_anchor!="ACTIVITY_AND_CLR_COMPOSITION_WITH_SUPPORT_AND_UNCERTAINTY":
            raise TargetContractError("unsupported target coordinate specification")
        if self.independent_biology_falsifier!="DONOR_LEVEL_RESERVED_ATAC_ONLY":
            raise TargetContractError("reserved endpoint was replaced")
        if self.training_authorized is not False:
            raise TargetContractError("research contract cannot authorize training")
        return True

    def digest(self):
        self.validate()
        from dataclasses import asdict
        return sha256(json.dumps(asdict(self),sort_keys=True,separators=(',',':')).encode()).hexdigest()

VALID_SELECTION_FIELDS = frozenset({
    "canonical_address_id", "canonical_address_index", "stable_ensembl_id", "gene_symbol",
    "canonical_registry_status", "assay_feature_present", "mapping_ambiguity",
    "annotation_reference_build", "assay_reference_build"
})
# Deny evaluation state even when it is exposed in a mixed provenance file.
RESERVED_OUTCOME_FIELDS=frozenset({
    "original_rna_measurement_support",  # Validation-cohort RNA detection must not select training target.
    "atac_accessibility_state", "atac_microglia_accessibility_state",
    "regulatory_evidence_state", "matched_rna_atac_state", "atac_donor_activity",
    "atac_peak_detection_fraction", "atac_accessible_promoter",
})

def allow_design_columns(columns):
    names=tuple(columns)
    if not names or len(names)!=len(set(names)):
        raise TargetContractError("empty or duplicate columns")
    if set(names)&RESERVED_OUTCOME_FIELDS or set(names)-VALID_SELECTION_FIELDS:
        raise TargetContractError("evaluation outcome or unreviewed feature entered teacher selection")
    return names

REQUIRED_GATES=(
    "P1_FROZEN_SOURCE_AUTHENTICATED_TEACHER", "P2_FROZEN_REGISTRY_PROJECTION",
    "P3_OUTCOME_PRODUCER_FROZEN_UNOPENED", "P4_NEGATIVE_CONTROLS_DISTINCT",
    "P5_SIGNED_THRESHOLDS_AND_POWER", "P6_CONTAMINATION_REVIEW_UPDATED",
    "P7_NO_ATAC_BASED_TARGET_SELECTION", "P8_DONOR_LEVEL_SEPARATE_NUCLEI"
)

def evaluation_ready(gates, *, observed_atac_opened=False, no_protected_outcomes_opened=True):
    if set(gates)!=set(REQUIRED_GATES) or any(type(v) is not bool for v in gates.values()):
        raise TargetContractError("complete explicit boolean gate vector required")
    if observed_atac_opened or not no_protected_outcomes_opened:
        raise TargetContractError("outcome/protected-data opening is not a preflight action")
    return all(gates.values())

def independent_endpoint_diagnostics(*, biological_endpoint, same_original_nucleus,
                                     independent_donors, baseline, target_selected_using_endpoint):
    if biological_endpoint!="ATAC_FRAGMENT_COUNTS":
        raise TargetContractError("RNA-derived biology cannot be the independent endpoint")
    if same_original_nucleus is not False or type(independent_donors) is not int or independent_donors!=18:
        raise TargetContractError("GSE174367 assay pairing or independent units incorrect")
    if baseline!="SAME_RNA_LINEAR_PLUS_TECHNICAL":
        raise TargetContractError("independent benchmark must include a same-RNA linear comparator")
    if target_selected_using_endpoint is not False:
        raise TargetContractError("target selection contaminated by evaluation endpoint")
    return True
