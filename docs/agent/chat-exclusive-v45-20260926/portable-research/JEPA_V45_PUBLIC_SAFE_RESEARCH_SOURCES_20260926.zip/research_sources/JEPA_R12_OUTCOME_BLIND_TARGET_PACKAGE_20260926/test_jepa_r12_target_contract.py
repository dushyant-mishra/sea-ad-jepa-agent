import unittest
from dataclasses import replace
from jepa_r12_target_contract import (QueryTargetContract,TargetContractError,allow_design_columns,
                                      evaluation_ready,REQUIRED_GATES,independent_endpoint_diagnostics)

BASE=QueryTargetContract(q=6186,partner=(1,2,3,4),reference=(5,6,7,8,9,10,11,12),student=(13,14),teacher_policy="RICH_Q_OBSERVED")
READY={k:True for k in REQUIRED_GATES}
ENDPOINT=dict(biological_endpoint="ATAC_FRAGMENT_COUNTS", same_original_nucleus=False,
              independent_donors=18,baseline="SAME_RNA_LINEAR_PLUS_TECHNICAL",target_selected_using_endpoint=False)
class ContractTest(unittest.TestCase):
    def assertRejected(self,fn):
        with self.assertRaises(TargetContractError): fn()
    def test_01_positive(self): self.assertTrue(BASE.validate())
    def test_02_q_policy_alternatives(self): self.assertNotEqual(BASE.digest(),replace(BASE,teacher_policy="Q_EXCLUDED").digest())
    def test_03_q_in_student(self): self.assertRejected(lambda: replace(BASE,student=(6186,13)).validate())
    def test_04_partner_in_student(self): self.assertRejected(lambda: replace(BASE,student=(4,13)).validate())
    def test_05_ref_in_student(self): self.assertRejected(lambda: replace(BASE,student=(5,13)).validate())
    def test_06_q_in_partner(self): self.assertRejected(lambda: replace(BASE,partner=(6186,2,3,4)).validate())
    def test_07_q_in_reference(self): self.assertRejected(lambda: replace(BASE,reference=(6186,6,7,8,9,10,11,12)).validate())
    def test_08_missing_partner(self): self.assertRejected(lambda: replace(BASE,partner=(1,2)).validate())
    def test_09_wrong_policy(self): self.assertRejected(lambda: replace(BASE,teacher_policy="STUDENT_SEES_Q").validate())
    def test_10_wrong_pairing(self): self.assertRejected(lambda: replace(BASE,same_original_cell=False).validate())
    def test_11_missing_q_conditioning(self): self.assertRejected(lambda: replace(BASE,query_conditioning=False).validate())
    def test_12_fake_authorization(self): self.assertRejected(lambda: replace(BASE,training_authorized=True).validate())
    def test_13_positive_selection_columns(self): self.assertEqual(allow_design_columns(["gene_symbol","assay_feature_present"]),("gene_symbol","assay_feature_present"))
    def test_14_atac_selection_refused(self): self.assertRejected(lambda: allow_design_columns(["gene_symbol","atac_accessibility_state"]))
    def test_15_inferred_atac_selection_refused(self): self.assertRejected(lambda: allow_design_columns(["gene_symbol","matched_rna_atac_state"]))
    def test_16_unknown_columns_fail(self): self.assertRejected(lambda: allow_design_columns(["gene_symbol","secret_score"]))
    def test_16b_validation_cohort_rna_detections_not_selection(self): self.assertRejected(lambda: allow_design_columns(["gene_symbol","original_rna_measurement_support"]))
    def test_17_missing_gate_blocks(self): self.assertRejected(lambda: evaluation_ready({k:True for k in REQUIRED_GATES[:-1]}))
    def test_18_false_gate_blocks(self): self.assertFalse(evaluation_ready({**READY,"P6_CONTAMINATION_REVIEW_UPDATED":False}))
    def test_19_type_gate_blocks(self): self.assertRejected(lambda: evaluation_ready({**READY,"P6_CONTAMINATION_REVIEW_UPDATED":1}))
    def test_20_all_gate_positive_control(self): self.assertTrue(evaluation_ready(READY))
    def test_21_opened_atac_blocks(self): self.assertRejected(lambda: evaluation_ready(READY,observed_atac_opened=True))
    def test_22_protected_blocks(self): self.assertRejected(lambda: evaluation_ready(READY,no_protected_outcomes_opened=False))
    def test_23_endpoint_positive(self): self.assertTrue(independent_endpoint_diagnostics(**ENDPOINT))
    def test_24_rna_derived_endpoint_rejected(self): self.assertRejected(lambda: independent_endpoint_diagnostics(**{**ENDPOINT,"biological_endpoint":"RNA_STAGE75_GRAPH"}))
    def test_25_fake_cell_pair_rejected(self): self.assertRejected(lambda: independent_endpoint_diagnostics(**{**ENDPOINT,"same_original_nucleus":True}))
    def test_26_pseudoreplication_rejected(self): self.assertRejected(lambda: independent_endpoint_diagnostics(**{**ENDPOINT,"independent_donors":4126}))
    def test_27_no_same_rna_baseline_rejected(self): self.assertRejected(lambda: independent_endpoint_diagnostics(**{**ENDPOINT,"baseline":"TECHNICAL_ONLY"}))
    def test_28_contaminated_endpoint_rejected(self): self.assertRejected(lambda: independent_endpoint_diagnostics(**{**ENDPOINT,"target_selected_using_endpoint":True}))
if __name__=='__main__': unittest.main(verbosity=2)
