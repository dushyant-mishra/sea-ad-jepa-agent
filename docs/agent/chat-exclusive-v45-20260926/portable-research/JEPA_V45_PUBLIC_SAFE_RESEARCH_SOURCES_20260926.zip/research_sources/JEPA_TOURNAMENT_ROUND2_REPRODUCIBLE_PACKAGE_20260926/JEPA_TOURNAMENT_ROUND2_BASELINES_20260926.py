#!/usr/bin/env python3
"""Independent RED-TEAM controls for historical tiny tournament; not FULL104 authority.
Inputs: SHA-verified historical subset produced by previous tournament scripts.
No pathology, ATAC, protected outcomes, or model selection. Test donors never used for tuning.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import hashlib, json, importlib.util, warnings
import numpy as np
import pandas as pd
import torch
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder, StandardScaler
ROOT=Path('/mnt/data')
# Import frozen first-round preparation/panel code, not its main() training loop.
spec=importlib.util.spec_from_file_location('frozen_tiny','/mnt/data/JEPA_TINY_TOURNAMENT_20260926.py')
frozen=importlib.util.module_from_spec(spec);spec.loader.exec_module(frozen)
meta=frozen.meta; micro=meta.native_class.str.contains('microgl',case=False).to_numpy()
donors=np.array(sorted(meta.loc[micro,'donor_id'].unique()));d=meta.donor_id.to_numpy()
orig=json.loads((ROOT/'JEPA_TINY_TOURNAMENT_RESULTS_20260926.json').read_text())

def pooled(y,pred,mean,indices):
    yy=y[indices];pp=pred[indices];b=np.broadcast_to(mean,yy.shape)
    den=((yy-b)**2).sum();return float(1-((yy-pp)**2).sum()/den) if den>0 else None

def fit_ridge(ztrain,ytrain,zvalid,yvalid,ztest,*,alpha):
    mu=ztrain.mean(0); sd=np.maximum(ztrain.std(0),.05)
    model=Ridge(alpha=alpha).fit((ztrain-mu)/sd,ytrain)
    return model.predict((zvalid-mu)/sd),model.predict((ztest-mu)/sd)

def subject_scores(y,te,pred):
    mean=y[tr].mean(0)
    return pooled(y[te],pred,mean,np.arange(len(te))),pooled(y[te],pred,mean,np.flatnonzero(micro[te]))

records=[]; source_audit=[]; exact_masks=[]
for fold,splitseed in enumerate([4300,4317]):
    rng=np.random.default_rng(splitseed); perm=rng.permutation(donors)
    td=set(perm[:34]);vd=set(perm[34:42]);testd=set(perm[42:])
    tr=np.flatnonzero(np.isin(d,list(td)));val=np.flatnonzero(np.isin(d,list(vd)));te=np.flatnonzero(np.isin(d,list(testd)))
    assert td.isdisjoint(vd) and td.isdisjoint(testd) and vd.isdisjoint(testd)
    raw, full, parts,y,sources=frozen.features(tr,val,te)
    source_audit.append(sources)
    assert sources['evaluation_addresses_sha256']==orig['features_by_fold'][fold]['evaluation_addresses_sha256']
    assert sources['selected_addresses_sha256']==orig['features_by_fold'][fold]['selected_addresses_sha256']
    # Fixed test mask identical to the earlier neural-student evaluation mask.
    seed=100+fold; evalx,q=frozen.mask_view(raw,430000+seed)
    trainx,trainq=frozen.mask_view(raw,seed*1000+0)
    # A genuinely independent, second prospective mask stress on SAME test donors,
    # not used for selection. Only linear model; neural weights were not retained.
    stressx,_=frozen.mask_view(raw,930000+seed)
    # The score is *relative composition among 96 disjoint held-out RNA features*.
    # Not an independent biological endpoint, raw-count abundance, or true rare state.
    core=trainx[:,:400]; xval=evalx[val]; xtest=evalx[te]
    def save(arm,pval,ptest,pstress=None,chosen=None):
        mean=y[tr].mean(0)
        def score(yy,pp):
            b=np.broadcast_to(mean,yy.shape);den=((yy-b)**2).sum()
            return float(1-((yy-pp)**2).sum()/den) if den>0 else None
        mm=micro[te]
        rec={'fold':fold,'arm':arm,'n_train_donors':len(td),'n_val_donors':len(vd),'n_test_donors':len(testd),
          'n_test_micro':int(mm.sum()),'validation_r2':score(y[val],pval),'test_r2':score(y[te],ptest),
          'micro_test_r2':score(y[te][mm],ptest[mm]),'hyperparam':chosen}
        if pstress is not None:rec['alternative_mask_test_r2']=score(y[te],pstress)
        records.append(rec)
        print('FOLD',fold,arm,'TEST',round(rec['test_r2'],5),'MICRO',round(rec['micro_test_r2'],5),'VAL',round(rec['validation_r2'],5),flush=True)
        return rec
    for panel in ['VISIBLE_700','VISIBLE_CORE_400','VISIBLE_FINE_RARE_300']:
        cols=slice(None) if panel=='VISIBLE_700' else slice(0,400) if panel=='VISIBLE_CORE_400' else slice(400,None)
        ztr=trainx[tr,cols];zval=evalx[val,cols];zte=evalx[te,cols];zs=stressx[te,cols]
        for alpha in [20,200]:
            pv,pt=fit_ridge(ztr,y[tr],zval,y[val],zte,alpha=alpha)
            _,ps=fit_ridge(ztr,y[tr],zval,y[val],zs,alpha=alpha)
            save(panel+'_RIDGE_'+str(alpha),pv,pt,ps,{'alpha':alpha,'tuned_on_test':False})
    # Train-only PCA compressed masked RNA, 32 dimensions matching neural latent widths.
    std=StandardScaler().fit(trainx[tr]);sc=std.transform(trainx)
    pca=PCA(n_components=32,svd_solver='randomized',random_state=4400+fold).fit(sc[tr]);
    ztr=pca.transform(sc[tr]);zval=pca.transform(std.transform(evalx[val]));zte=pca.transform(std.transform(evalx[te]));zs=pca.transform(std.transform(stressx[te]))
    pv,pt=fit_ridge(ztr,y[tr],zval,y[val],zte,alpha=20)
    _,ps=fit_ridge(ztr,y[tr],zval,y[val],zs,alpha=20)
    save('PCA32_VISIBLE_ONLY',pv,pt,ps,{'pca_fit_train_only':True,'alpha':20})
    # Technical controls: measurement operator and *lawfully visible* sparsity/depth.
    op=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(meta[['operator_index']].iloc[tr]);o=op.transform(meta[['operator_index']])
    def technical(x):
        # Counting visible chosen genes is permissible here, but is technical proxy.
        # The normalized input has an intrinsic normalization-sum, so derive counts
        # from the masked raw view without forwarding hidden q to the representation.
        return np.c_[np.log1p(x.sum(1)),(x>0).sum(1),np.var(x,axis=1)]
    tech_tr=technical(trainx);tech_test=technical(evalx);tech_s=technical(stressx)
    ztr=np.c_[o[tr],tech_tr[tr]];zval=np.c_[o[val],tech_test[val]];zte=np.c_[o[te],tech_test[te]];zs=np.c_[o[te],tech_s[te]]
    pv,pt=fit_ridge(ztr,y[tr],zval,y[val],zte,alpha=20)
    _,ps=fit_ridge(ztr,y[tr],zval,y[val],zs,alpha=20)
    save('OPERATOR_PLUS_VISIBLE_TECH',pv,pt,ps,{'alpha':20})
    # Positive technical diagnostic with original unmasked scalar library counts,
    # only as a leakage sensitivity test, never an allowable student input.
    op_tech=np.c_[o,np.log1p(raw.sum(1)),(raw>0).sum(1)]
    pv,pt=fit_ridge(op_tech[tr],y[tr],op_tech[val],y[val],op_tech[te],alpha=20)
    save('ILLEGAL_FULL_PANEL_DEPTH_DIAGNOSTIC',pv,pt,chosen={'prohibited_as_student':True})
    # Negative label-shuffle control: permute TRAINING-donor y ONLY, independent test unchanged.
    shuf=np.random.default_rng(9300+fold).permutation(len(tr))
    pv,pt=fit_ridge(trainx[tr],y[tr][shuf],evalx[val],y[val],evalx[te],alpha=20)
    save('SHUFFLED_TRAIN_LABEL_NEGATIVE',pv,pt,chosen={'train_label_permutation':True})
    # Identity-only query indices carry no information in old toy task; explicit limitation.
    exact_masks.append({'fold':fold,'evaluation_mask_seed':430000+seed,'first_train_mask_seed':seed*1000,'test_count':len(te),'train_count':len(tr),'val_count':len(val), 'query_id_not_passed_to_any_neural_arm':True})

old={}
for arm in ['EMA','RICH','SHARED','TEAM']:
    rr=[z for z in orig['results'] if z['arm']==arm]
    old[arm]={'mean_student_r2':float(np.mean([a['student_r2'] for a in rr])),
       'mean_micro_student_r2':float(np.mean([a['student_micro_r2'] for a in rr]))}
new={}
for arm in sorted(set(x['arm'] for x in records)):
    zz=[x for x in records if x['arm']==arm]
    new[arm]={'mean_test_r2':float(np.mean([x['test_r2'] for x in zz])),
      'mean_micro_test_r2':float(np.mean([x['micro_test_r2'] for x in zz])),
      'folds':len(zz)}
output={'schema':'JEPA_HISTORICAL_TINY_TOURNAMENT_ROUND2_DISCRIMINATING_BASELINES_V1',
 'scope':'RESEARCH_ONLY_HISTORICAL_FIT_DONOR_SUBSET_NONAUTHORIZING',
 'inputs':{'previous_report_sha256':hashlib.sha256((ROOT/'JEPA_TINY_TOURNAMENT_REPORT_20260926.md').read_bytes()).hexdigest(),
           'previous_script_sha256':hashlib.sha256((ROOT/'JEPA_TINY_TOURNAMENT_20260926.py').read_bytes()).hexdigest(),
           'previous_results_sha256':hashlib.sha256((ROOT/'JEPA_TINY_TOURNAMENT_RESULTS_20260926.json').read_bytes()).hexdigest(),
           'uses_prepared_historical_subset':True,'source_hashes_verified_by_original_frozen_preparation':True},
 'source_audit':source_audit,'masks':exact_masks,'previous_neural_scores':old,'control_scores':new,'all_records':records,
 'limitations':['same-study heldout RNA, not independent biological fidelity','repeat splits of same 50 donors',
 'query identity absent from all original neural models','rare panel low prevalence not rare cell state',
 'historical common-supported 700 features; native operator missingness untested','direct ridge trains on one fixed mask unlike neural stochastic masks',
 'no current V5 exact incumbent/no matched neural teacher capacity/no protected outcomes',
 'technical model controls do not eliminate all donor, QC, depth, source shortcuts'],
 'training_authorized':False,'N1_opened':False,'protected_outcomes_opened':False}
path=ROOT/'JEPA_TOURNAMENT_ROUND2_BASELINES_RESULTS_20260926.json';path.write_text(json.dumps(output,indent=2,allow_nan=False))
print('COMPLETE',str(path),flush=True)
