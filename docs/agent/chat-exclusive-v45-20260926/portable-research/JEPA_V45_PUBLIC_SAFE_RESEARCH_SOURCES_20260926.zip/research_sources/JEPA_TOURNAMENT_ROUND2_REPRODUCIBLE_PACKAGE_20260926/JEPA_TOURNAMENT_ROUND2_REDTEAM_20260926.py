#!/usr/bin/env python3
"""Fail-closed audit of historical tiny tournament round two. CPU only; no protected data."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import hashlib,importlib.util,json
from pathlib import Path
import numpy as np
root=Path('/mnt/data'); checks=[]
def require(name,ok):
    if not bool(ok):raise AssertionError('STOP_ROUND2_'+name)
    checks.append(name);print('PASS',name,flush=True)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8<<20),b''):h.update(block)
    return h.hexdigest()
known={
 'FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part001':'b8163f53a27f7cb1b526f8311d1b46b599502596c5d0be74fa588747a4e72b2e',
 'FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part002':'5bc2ec30fb374b15f1c5a4764e1856b0664c13513462ef2f7e224c4b6f856875',
 'FOUNDATION_CALIBRATION_BUNDLE_20260824.zip':'07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444',
 'expression.zip':'1098fd4c3fac7a991f2d51ac86ecd0a7ae94be9373e5cc30b9d81be392d32fd4'}
for name,h in known.items():require('SOURCE_SHA_'+name,sha(root/name)==h)
spec=importlib.util.spec_from_file_location('frozen','/mnt/data/JEPA_TINY_TOURNAMENT_20260926.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
old=json.loads((root/'JEPA_TINY_TOURNAMENT_RESULTS_20260926.json').read_text())
base=json.loads((root/'JEPA_TOURNAMENT_ROUND2_BASELINES_RESULTS_20260926.json').read_text())
ablate=json.loads((root/'JEPA_TOURNAMENT_ROUND2_TEACHER_ABLATION_RESULTS_20260926.json').read_text())
require('EXACT_2_FOLDS_4_NEURAL_ARMS',len([r for r in old['results'] if r['arm'] in ('EMA','RICH','SHARED','TEAM')])==8)
require('RESULTS_BOUND_TO_ORIGINAL',base['inputs']['previous_results_sha256']==sha(root/'JEPA_TINY_TOURNAMENT_RESULTS_20260926.json') and ablate['previous_results_sha256']==sha(root/'JEPA_TINY_TOURNAMENT_RESULTS_20260926.json'))
require('FEATURE_DIGEST_PARITY',base['source_audit']==old['features_by_fold'])
require('FULL_BASELINE_COVERAGE',len(base['all_records'])==20 and len({r['arm'] for r in base['all_records']})==10)
require('TEACHER_ABLATION_COVERAGE',len(ablate['results'])==16 and len(ablate['means'])==8)
for fold,seed in enumerate([4300,4317]):
    donor_ids=np.array(sorted(f.meta.loc[f.meta.native_class.str.contains('microgl',case=False),'donor_id'].unique()))
    donors=np.random.default_rng(seed).permutation(donor_ids)
    split_sets=[set(donors[:34]),set(donors[34:42]),set(donors[42:])]
    require(f'FOLD_{fold}_DONOR_INDEX_DISJOINT',not (split_sets[0]&split_sets[1] or split_sets[0]&split_sets[2] or split_sets[1]&split_sets[2]) and len(set(f.meta.donor_id)&set(donors))==len(donor_ids))
    for arm in ('PCA32_VISIBLE_ONLY','SHUFFLED_TRAIN_LABEL_NEGATIVE','OPERATOR_PLUS_VISIBLE_TECH'):
        q=next(r for r in base['all_records'] if r['fold']==fold and r['arm']==arm)
        require(f'FOLD_{fold}_{arm}_FINITE',np.isfinite(q['test_r2']) and np.isfinite(q['micro_test_r2']))
    shuffle=next(r for r in base['all_records'] if r['fold']==fold and r['arm']=='SHUFFLED_TRAIN_LABEL_NEGATIVE')
    pca=next(r for r in base['all_records'] if r['fold']==fold and r['arm']=='PCA32_VISIBLE_ONLY')
    tech=next(r for r in base['all_records'] if r['fold']==fold and r['arm']=='OPERATOR_PLUS_VISIBLE_TECH')
    require(f'FOLD_{fold}_PLANTED_LABEL_SHUFFLE_FAILS',shuffle['test_r2']<0 and shuffle['test_r2']<pca['test_r2'])
    require(f'FOLD_{fold}_PCA_BEATS_THIS_TECH_CONTROL',pca['test_r2']>tech['test_r2'])
    rich=next(r for r in ablate['results'] if r['fold']==fold and r['arm']=='RICH_PCA32_FULL_TEACHER')
    split=next(r for r in ablate['results'] if r['fold']==fold and r['arm']=='SPLIT_PCA16_8_8_SAME_TOTAL_DIM')
    null=next(r for r in ablate['results'] if r['fold']==fold and r['arm']=='CORE_PLUS_WITHIN_OPERATOR_SHUFFLED_SPECIALISTS')
    require(f'FOLD_{fold}_SPLIT_EXPERT_NULL_SENSITIVITY',split['test_r2']>null['test_r2'])
    require(f'FOLD_{fold}_RICH_PCA_DIM_MATCH',rich['dims']==split['dims']==32)
require('NO_PROTECTED_OR_PRODUCTION_AUTHORITY',base['training_authorized'] is False and base['N1_opened'] is False and base['protected_outcomes_opened'] is False and ablate['training_authorized'] is False and ablate['protected_outcomes_opened'] is False)
# Physical counterfactual against the *same original code*, including planted failure.
raw=np.array([[7,2,0,9,3,4,11,0]*88][:1]*8,dtype=np.float32)[:,:700]
view,q=f.mask_view(raw,791);mut=raw.copy();mut[np.arange(len(q)),q]+=83.0
view2,q2=f.mask_view(mut,791)
require('STUDENT_DIRECT_QUERY_VALUE_INVARIANCE',np.array_equal(q,q2) and np.array_equal(view,view2))
keep=np.random.default_rng(791).random(raw.shape)>.40;keep[np.arange(len(q)),q]=False
bad1=f.panel_log(raw,np.arange(700))*keep;bad2=f.panel_log(mut,np.arange(700))*keep
require('PLANTED_FULL_LIBRARY_LEAK_VISIBLE',float(np.max(np.abs(bad1-bad2)))>.001)
# Regression: the earlier withdrawn within-group estimator is not invoked by any script.
for file in ['JEPA_TINY_TOURNAMENT_20260926.py','JEPA_TOURNAMENT_ROUND2_BASELINES_20260926.py','JEPA_TOURNAMENT_ROUND2_TEACHER_ABLATION_20260926.py']:
    require('NO_WITHDRAWN_ESTIMATOR_'+file,'x4_within' not in (root/file).read_text())
print('ROUND2_ALL',len(checks),'PHYSICAL_AUDIT_CHECKS_PASS_RESEARCH_ONLY',flush=True)
(root/'JEPA_TOURNAMENT_ROUND2_AUDIT_RECEIPT_20260926.json').write_text(json.dumps({
 'schema':'JEPA_TOURNAMENT_ROUND2_LOCAL_AUDIT_RECEIPT',
 'original_sha256':known,'checks':checks,'count':len(checks),
 'scope':'historical research only; not qualified teacher biology or V5 training',
 'train_authorized':False,'protected_opened':False},indent=2))
