#!/usr/bin/env python3
"""Capacity-matched 32d unsupervised linear teacher-view ablation; DEVELOPMENT ONLY.
No teacher is trained, this is a falsification/feasibility comparator, not neural A/B/C.
"""
import os;os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import importlib.util,json,hashlib
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
spec=importlib.util.spec_from_file_location('frozen_tiny','/mnt/data/JEPA_TINY_TOURNAMENT_20260926.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
micro=f.meta.native_class.str.contains('microgl',case=False).to_numpy();d=f.meta.donor_id.to_numpy();
donors=np.array(sorted(f.meta.loc[micro,'donor_id'].unique()));records=[]
prev=json.load(open('/mnt/data/JEPA_TINY_TOURNAMENT_RESULTS_20260926.json'))

def fit_pca(x,tr,fold,n,seed):
    scaler=StandardScaler().fit(x[tr]);a=scaler.transform(x)
    model=PCA(n_components=n,svd_solver='randomized',random_state=seed+fold).fit(a[tr]);return model.transform(a).astype(np.float32)

def evaluate(z,y,tr,te):
    mu=z[tr].mean(0);std=np.maximum(z[tr].std(0),.01)
    model=Ridge(alpha=20).fit((z[tr]-mu)/std,y[tr]);pred=model.predict((z[te]-mu)/std)
    def scorer(idx):
        b=np.broadcast_to(y[tr].mean(0),y[te][idx].shape)
        den=((y[te][idx]-b)**2).sum()
        return float(1-((y[te][idx]-pred[idx])**2).sum()/den)
    return scorer(slice(None)),scorer(micro[te])

for fold,seed in enumerate([4300,4317]):
    perm=np.random.default_rng(seed).permutation(donors)
    tr=np.flatnonzero(np.isin(d,perm[:34]));te=np.flatnonzero(np.isin(d,perm[42:]));val=np.flatnonzero(np.isin(d,perm[34:42]))
    raw,full,parts,y,ids=f.features(tr,val,te)
    assert ids['selected_addresses_sha256']==prev['features_by_fold'][fold]['selected_addresses_sha256']
    # ALL variants draw from the same original full teacher-normalized 700 RNA values;
    # unlike previous A/B/C neural arms, normalization is NOT a confound here.
    core=fit_pca(full[:,:400],tr,fold,16,11)
    fine=fit_pca(full[:,400:600],tr,fold,8,12)
    rare=fit_pca(full[:,600:700],tr,fold,8,13)
    rich=fit_pca(full,tr,fold,32,14)
    # Sensitivity check: teacher's specialist inputs normalized independently,
    # as the original first-round specialist models were. This changes the
    # information geometry and is NOT a matched-normalization comparison to A.
    core_ind=fit_pca(parts[0],tr,fold,16,21)
    fine_ind=fit_pca(parts[1],tr,fold,8,22)
    rare_ind=fit_pca(parts[2],tr,fold,8,23)
    states={'RICH_PCA32_FULL_TEACHER':rich,
            'SPLIT_PCA16_8_8_SAME_TOTAL_DIM':np.c_[core,fine,rare],
            'CORE_PCA16_ONLY':core,
            'SPLIT_PARTWISE_NORM_SENSITIVITY':np.c_[core_ind,fine_ind,rare_ind],
            'CORE_PARTWISE_NORM_SENSITIVITY':core_ind,
            'CORE_PCA16_PLUS_RANDOM16':np.c_[core,np.random.default_rng(9900+fold).normal(size=(len(full),16)).astype(np.float32)]}
    # Donor-independent null: unpair the fine/rare features on every split
    # while preserving the same all-operator mix. We must not use test outcomes
    # or selection to choose the permutation.
    shuf=np.arange(len(full))
    for partition,k in ((tr,0),(val,1),(te,2)):
        shuf[partition]=np.random.default_rng(9950+fold*3+k).permutation(partition)
    states['CORE_PLUS_UNPAIRED_SPECIALISTS']=np.c_[core,fine[shuf],rare[shuf]]
    # Stronger negative: shuffling separately within each operator preserves
    # any operator-specific signal. If performance survives, suspect technical shortcuts.
    shuffled=np.arange(len(full))
    for k,partition in enumerate((tr,val,te)):
        for op in np.unique(f.meta.operator_index.to_numpy()[partition]):
            ix=partition[f.meta.operator_index.to_numpy()[partition]==op]
            shuffled[ix]=np.random.default_rng(9990+fold*126+k*42+int(op)).permutation(ix)
    states['CORE_PLUS_WITHIN_OPERATOR_SHUFFLED_SPECIALISTS']=np.c_[core,fine[shuffled],rare[shuffled]]
    for name,z in states.items():
        a,b=evaluate(z,y,tr,te)
        records.append({'fold':fold,'arm':name,'test_r2':a,'micro_test_r2':b,'dims':z.shape[1]})
        print(f'FOLD={fold} {name} R2={a:.5f} micro={b:.5f}',flush=True)

sums={}
for arm in sorted({r['arm'] for r in records}):
    rr=[r for r in records if r['arm']==arm]
    sums[arm]={'mean_r2':float(np.mean([r['test_r2'] for r in rr])),
      'mean_micro_r2':float(np.mean([r['micro_test_r2'] for r in rr]))}
res={'schema':'JEPA_HISTORICAL_TEACHER_VIEW_LINEAR_ABLATION_NONAUTHORIZING_V1',
  'scope':'HISTORICAL_SAME_STUDY_RNA_NO_NEURAL_TEACHER_TRAINED',
  'previous_results_sha256':hashlib.sha256(Path('/mnt/data/JEPA_TINY_TOURNAMENT_RESULTS_20260926.json').read_bytes()).hexdigest(),
  'dims':{'full_teacher':32,'split_teacher':32,'core_only':16},
  'full_normalization_matched_for_rich_split_core':True,'independent_head_normalization_sensitivity_also_run':True,'donor_splits':2,'teacher_target_biologically_qualified':False,
  'results':records,'means':sums,'training_authorized':False,'protected_outcomes_opened':False}
Path('/mnt/data/JEPA_TOURNAMENT_ROUND2_TEACHER_ABLATION_RESULTS_20260926.json').write_text(json.dumps(res,indent=2))
