import io,zipfile,pandas as pd,numpy as np, scipy.sparse as sp, hashlib,json
import hashlib
KNOWN_SHA={
 "FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part001":"b8163f53a27f7cb1b526f8311d1b46b599502596c5d0be74fa588747a4e72b2e",
 "FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part002":"5bc2ec30fb374b15f1c5a4764e1856b0664c13513462ef2f7e224c4b6f856875",
 "expression.zip":"1098fd4c3fac7a991f2d51ac86ecd0a7ae94be9373e5cc30b9d81be392d32fd4"
}
for name,expected in KNOWN_SHA.items():
 h=hashlib.sha256()
 with open('/mnt/data/'+name,'rb') as fh:
  for chunk in iter(lambda:fh.read(8<<20),b''):h.update(chunk)
 assert h.hexdigest()==expected,(name,'SOURCE_SHA_MISMATCH')
print('THREE_EXACT_SOURCE_SHA256_VERIFIED',flush=True)
import os
if not os.path.isfile('/tmp/jepa_discovery.npz'):
 p1='/mnt/data/FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part001'
 p2='/mnt/data/FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part002'
 with open('/tmp/jepa_combined.zip','wb') as dst:
  for path in (p1,p2):
   with open(path,'rb') as src:
    for chunk in iter(lambda:src.read(8<<20),b''):dst.write(chunk)
 with zipfile.ZipFile('/tmp/jepa_combined.zip') as z3:
  member=next(n for n in z3.namelist() if n.endswith('.npz'))
  with z3.open(member) as src,open('/tmp/jepa_discovery.npz','wb') as dst:
   import shutil;shutil.copyfileobj(src,dst,8<<20)

z=zipfile.ZipFile('/mnt/data/expression.zip');prefix='expression/expression/'
f=pd.read_csv(io.BytesIO(z.read(prefix+'FOUNDATION_DISCOVERY_SAMPLE_FREEZE.csv')),dtype={'stable_key':str})
meta=[];offset=0
for op in range(42):
 d=pd.read_csv(io.BytesIO(z.read(prefix+f'sample_operator_metadata/op{op:02d}.meta.csv')),dtype={'stable_key':str})
 d['csr_row']=np.arange(len(d))+offset;d['operator_index']=op;offset+=len(d);meta.append(d)
m=pd.concat(meta,ignore_index=True)
print('metadata total',len(m), 'unique',m.stable_key.nunique(), 'freeze unique',f.stable_key.nunique(),flush=True)
f=f.merge(m[['stable_key','csr_row','source_library','operator_index','donor_id']],on='stable_key',suffixes=('','_meta'),validate='one_to_one')
print('joined',len(f),'op agree',(f.operator_index==f.operator_index_meta).all(),'donor agree',(f.donor_id==f.donor_id_meta).all(),flush=True)
micro=f.native_class.str.contains('microgl',case=False,na=False)
keep_donors=set(f.loc[micro,'donor_id']);others=f[(~micro)&f.donor_id.isin(keep_donors)&f.broad_class.eq('Non-neuronal and Non-neural')]
# deterministic 1200 other within microglia donor population
extra=others.sample(n=min(1200,len(others)),random_state=4301)
sel=pd.concat([f[micro],extra]).sort_values('csr_row').reset_index(drop=True)
print('selected',len(sel),'micro',micro.sum(),'donors',sel.donor_id.nunique(),'ops',sel.operator_index.nunique(),flush=True)
with zipfile.ZipFile('/tmp/jepa_discovery.npz') as zz:
 ptr=np.load(io.BytesIO(zz.read('indptr.npy')),allow_pickle=False)
 print('nnz',ptr[-1],'dtype indices/data; rows',len(ptr)-1,flush=True)
 # Stream compressed array once and sample exact row offsets.
 def get_selected(name,dtype):
  out=[];positions=sel.csr_row.to_numpy();
  with zz.open(name+'.npy') as stream:
   from numpy.lib import format
   version=format.read_magic(stream)
   shape,fortran,dt=(format.read_array_header_2_0(stream) if version==(2,0) else format.read_array_header_1_0(stream))
   print(name,'array',shape,dt,flush=True)
   assert dt==np.dtype(dtype)
   curr=0
   for j,row in enumerate(positions):
    start,end=int(ptr[row]),int(ptr[row+1]);gap=(start-curr)*dt.itemsize
    while gap:
     b=stream.read(min(gap,1<<20));assert b;gap-=len(b)
    size=(end-start)*dt.itemsize; b=stream.read(size)
    if len(b)!=size:raise RuntimeError('short read')
    out.append(np.frombuffer(b,dtype=dt).copy());curr=end
    if j%400==0:print(name,'row',j,flush=True)
  return np.concatenate(out)
 idx=get_selected('indices',np.int32);vals=get_selected('data',np.float64)
 lengths=np.diff(ptr)[sel.csr_row.to_numpy()];rows_ptr=np.r_[0,np.cumsum(lengths)]
 X=sp.csr_matrix((vals,idx,rows_ptr),shape=(len(sel),41238));print('X',X.shape,X.nnz,flush=True)
 sp.save_npz('/tmp/jepa_tour_logexpr.npz',X,compressed=True)
 sel.to_csv('/tmp/jepa_tour_meta.csv',index=False)
 print(json.dumps({'selected':len(sel),'microglia':int(sel.native_class.str.contains('microgl',case=False).sum()),'donors':sel.donor_id.nunique(),'operators':sel.operator_index.nunique(),'csr_nnz':int(X.nnz),'positive_values':int(np.sum(X.data>0))}),flush=True)
