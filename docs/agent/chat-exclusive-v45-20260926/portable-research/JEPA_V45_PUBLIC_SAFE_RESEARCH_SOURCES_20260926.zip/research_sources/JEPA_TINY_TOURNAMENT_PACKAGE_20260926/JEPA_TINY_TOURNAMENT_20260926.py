#!/usr/bin/env python3
"""Historical DEVELOPMENT-ONLY tiny representation tournament.
NO FULL104 authority, production model, protected outcome, or causal inference.
Requires local /tmp/jepa_tour_logexpr.npz and /tmp/jepa_tour_meta.csv produced
from the original authenticated historical 50k discovery archive.
"""
import os,io,json,zipfile,copy,hashlib
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np,pandas as pd,scipy.sparse as sp
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score
from sklearn.preprocessing import OneHotEncoder
import torch
from torch import nn
from torch.utils.data import DataLoader,TensorDataset

torch.set_num_threads(2)
ROOT='/mnt/data';SEED=430926; np.random.seed(SEED);torch.manual_seed(SEED)
meta=pd.read_csv('/tmp/jepa_tour_meta.csv');X=sp.load_npz('/tmp/jepa_tour_logexpr.npz');assert X.shape==(len(meta),41238)
assert (meta.operator_index==meta.operator_index_meta).all()
# Reverse exact float64 log1p(10000*raw/full_library) using each row's
# smallest positive entry (an observed single UMI). Fail if non-integral.
data=X.data.copy();denoms=[];maxerr=0
for i in range(X.shape[0]):
 a=data[X.indptr[i]:X.indptr[i+1]]
 if not len(a):raise ValueError('empty row cannot be inverted')
 raw=np.expm1(a)/np.expm1(a.min());err=np.max(abs(raw-np.rint(raw)));maxerr=max(maxerr,err)
 if err>1e-5:raise ValueError('source is not exactly invertible to integer counts')
 a[:]=np.rint(raw);denoms.append(int(round(10000/np.expm1(X.data[X.indptr[i]:X.indptr[i+1]].min()))))
rawX=sp.csr_matrix((data,X.indices.copy(),X.indptr.copy()),shape=X.shape)
# Authentic historical operator support; never treat structurally missing as zero.
z=zipfile.ZipFile(ROOT+'/FOUNDATION_CALIBRATION_BUNDLE_20260824.zip')
n=next(n for n in z.namelist() if n.endswith('FOUNDATION_OPERATOR_ADDRESS_OBSERVATION_STATE.npz'))
with np.load(io.BytesIO(z.read(n)),allow_pickle=False) as s: states=s['states']; ops=s['operator_index']
assert np.array_equal(ops,np.arange(42))
eligible=np.flatnonzero(np.all(states[np.unique(meta.operator_index)]==1,axis=0))
print('source',X.shape,'microglia',sum(meta.native_class.str.contains('microgl',case=False)),'common_scalar_eligible',len(eligible),'max_raw_rounding_error',maxerr,flush=True)

def panel_log(raw,cols):
 v=raw[:,cols].astype(np.float32);tot=v.sum(axis=1,keepdims=True)
 return np.log1p(np.divide(v*10000,tot,out=np.zeros_like(v),where=tot>0)).astype(np.float32)

def features(tr,val,te):
 micro=meta.native_class.str.contains('microgl',case=False).to_numpy()
 tm=np.intersect1d(tr,np.flatnonzero(micro)); A=rawX[tm][:,eligible].toarray()
 prevalence=(A>0).mean(axis=0);V=np.var(np.log1p(A),axis=0)
 rng=np.random.default_rng(43)
 pool=np.flatnonzero((prevalence>.10)&(prevalence<.98))
 pool=pool[np.argsort(-V[pool])][:1600]
 if len(pool)<1200:raise ValueError('too few detectable genes')
 # Do not give any teacher or student the independent expression-evaluation panel.
 evalidx=rng.choice(pool[200:1400],size=96,replace=False)
 remaining=pool[~np.isin(pool,evalidx)]
 core=remaining[:400];fine=remaining[400:600]
 used=np.r_[core,fine,evalidx]
 distinct=np.setdiff1d(np.arange(len(eligible)),used)
 candidates=distinct[(prevalence[distinct]>=.025)&(prevalence[distinct]<=.22)]
 # Only select features seen in >=3 independent TRAINING donors.
 donors=meta.donor_id.to_numpy()[tm]
 recurrence=np.zeros(len(candidates),dtype=np.int16)
 for donor in np.unique(donors):
  recurrence+=(A[donors==donor][:,candidates]>0).any(axis=0)
 candidates=candidates[recurrence>=3]
 rare=candidates[np.argsort(-V[candidates])][:100]
 if len(rare)<90:raise ValueError('too few rare-proxy features')
 panels=[eligible[core],eligible[fine],eligible[rare]];ev=eligible[evalidx]
 chosen=np.r_[*panels];dense=rawX[:,chosen].toarray().astype(np.float32)
 inp=panel_log(dense,np.arange(dense.shape[1]))
 # Teacher specialist input normalized independently using exclusively its panel.
 targets=[panel_log(dense,np.arange(lo,hi)) for lo,hi in [(0,400),(400,600),(600,700)]]
 out=panel_log(rawX[:,ev].toarray().astype(np.float32),np.arange(len(ev)))
 return dense,inp,targets,out,dict(core=len(core),fine=len(fine),rare=len(rare),independent_eval=len(ev),rare_donors_min=3,
   selected_addresses_sha256=hashlib.sha256(chosen.astype('<i4').tobytes()).hexdigest(),evaluation_addresses_sha256=hashlib.sha256(ev.astype('<i4').tobytes()).hexdigest())

def mlp(d,h,o):return nn.Sequential(nn.Linear(d,h),nn.GELU(),nn.Linear(h,o))
class RichAE(nn.Module):
 def __init__(self):
  super().__init__();self.e=mlp(700,128,32);self.d=mlp(32,128,700)
 def embed(self,x,parts):return self.e(x)
 def forward(self,x,parts):z=self.embed(x,parts);return ((self.d(z)-x)**2).mean()
class SharedAE(nn.Module):
 def __init__(self):
  super().__init__();self.e=mlp(700,128,64);self.h=nn.ModuleList([nn.Linear(64,d) for d in (16,8,8)]);self.d=nn.ModuleList([mlp(d,64,n) for d,n in [(16,400),(8,200),(8,100)]])
 def embed(self,x,parts):q=self.e(x);return torch.cat([h(q) for h in self.h],1)
 def forward(self,x,parts):q=self.e(x);return sum(((d(h(q))-p)**2).mean() for d,h,p in zip(self.d,self.h,parts))/3
class TeamAE(nn.Module):
 def __init__(self):
  super().__init__();self.enc=nn.ModuleList([mlp(n,64,d) for n,d in [(400,16),(200,8),(100,8)]]);self.dec=nn.ModuleList([mlp(d,64,n) for n,d in [(400,16),(200,8),(100,8)]])
 def embed(self,x,parts):return torch.cat([e(p) for e,p in zip(self.enc,parts)],1)
 def forward(self,x,parts):return sum(((d(e(p))-p)**2).mean() for d,e,p in zip(self.dec,self.enc,parts))/3
class Student(nn.Module):
 def __init__(self,arm):
  super().__init__();self.arm=arm
  if arm in ('RICH','EMA'):self.e=mlp(700,128,32)
  if arm=='SHARED':self.t=mlp(700,128,64);self.h=nn.ModuleList([nn.Linear(64,d) for d in (16,8,8)])
  if arm=='TEAM':self.c=mlp(400,64,16);self.s=mlp(300,64,16)
 def forward(self,x):
  if self.arm in ('RICH','EMA'):return self.e(x)
  if self.arm=='SHARED':q=self.t(x);return torch.cat([h(q) for h in self.h],1)
  return torch.cat([self.c(x[:,:400]),self.s(x[:,400:])],1)

def mask_view(raw,seed):
 rng=np.random.default_rng(seed);keep=rng.random(raw.shape)>.40
 # Every sampled query is a CORE feature deliberately absent from student.
 q=rng.integers(0,32,size=raw.shape[0]);keep[np.arange(len(q)),q]=False
 v=raw*keep;return panel_log(v,np.arange(raw.shape[1])),q

def train_ae(model,inp,parts,tr,val,seed,epochs=26):
 torch.manual_seed(seed);opt=torch.optim.AdamW(model.parameters(),lr=.002,weight_decay=.005)
 x=torch.tensor(inp);pp=[torch.tensor(p) for p in parts];rng=np.random.default_rng(seed);best=1e9;pat=0;beststate=None
 for ep in range(epochs):
  model.train();order=rng.permutation(tr)
  for ix in np.array_split(order,max(1,int(np.ceil(len(tr)/128)))):
   opt.zero_grad();loss=model(x[ix],[p[ix] for p in pp]);loss.backward();opt.step()
  model.eval()
  with torch.no_grad():vl=model(x[val],[p[val] for p in pp]).item()
  if vl<best-1e-5:best=vl;pat=0;beststate=copy.deepcopy(model.state_dict())
  else:
   pat+=1
   if pat>=6:break
 model.load_state_dict(beststate);model.eval()
 with torch.no_grad():return model.embed(x,pp).numpy(),best,ep+1

def train_student(arm,raw,z,tr,val,seed,epochs=38):
 # Normalize teacher coordinates only on training donors; equalize head magnitudes.
 mu=z[tr].mean(0);sd=np.maximum(z[tr].std(0),.15);zt=(z-mu)/sd
 torch.manual_seed(seed+101);model=Student(arm);opt=torch.optim.AdamW(model.parameters(),lr=.002,weight_decay=.01)
 best=1e9;pat=0;beststate=None; xv,_=mask_view(raw,430000+seed)
 valx=torch.tensor(xv[val]);valy=torch.tensor(zt[val].astype(np.float32));rng=np.random.default_rng(seed+200)
 for ep in range(epochs):
  xm,_=mask_view(raw,seed*1000+ep);xx=torch.tensor(xm);yy=torch.tensor(zt.astype(np.float32));model.train()
  for ix in np.array_split(rng.permutation(tr),max(1,int(np.ceil(len(tr)/128)))):
   opt.zero_grad();loss=((model(xx[ix])-yy[ix])**2).mean();loss.backward();opt.step()
  model.eval()
  with torch.no_grad():vl=((model(valx)-valy)**2).mean().item()
  if vl<best-1e-5:best=vl;pat=0;beststate=copy.deepcopy(model.state_dict())
  else:
   pat+=1
   if pat>=7:break
 model.load_state_dict(beststate);model.eval()
 with torch.no_grad():pred=model(torch.tensor(xv)).numpy()*sd+mu
 return pred,float(best),ep+1,sum(p.numel() for p in model.parameters())

def train_ema(inp,raw,tr,val,seed):
 torch.manual_seed(seed);teacher=mlp(700,128,32);student=Student('EMA');teacher.load_state_dict(student.e.state_dict());opt=torch.optim.AdamW(student.parameters(),lr=.001,weight_decay=.01)
 xx=torch.tensor(inp);rng=np.random.default_rng(seed);best=1e9;beststates=None;pat=0
 for ep in range(45):
  stu,_=mask_view(raw,seed*1000+ep);sx=torch.tensor(stu);student.train()
  for ix in np.array_split(rng.permutation(tr),max(1,int(np.ceil(len(tr)/128)))):
   with torch.no_grad():target=teacher(xx[ix]);target=(target-target.mean(0))/(target.std(0,unbiased=False)+.1)
   out=student(sx[ix]);out=(out-out.mean(0))/(out.std(0,unbiased=False)+.1)
   std=out.std(0,unbiased=False);loss=((out-target)**2).mean()+.05*torch.relu(.7-std).mean()
   opt.zero_grad();loss.backward();opt.step()
   with torch.no_grad():
    for t,s in zip(teacher.parameters(),student.e.parameters()):t.mul_(.99).add_(s,alpha=.01)
  student.eval();sv,_=mask_view(raw,430000+seed)
  with torch.no_grad():v=((student(torch.tensor(sv[val]))-teacher(xx[val]))**2).mean().item()
  if v<best-1e-5:best=v;beststates=(copy.deepcopy(teacher.state_dict()),copy.deepcopy(student.state_dict()));pat=0
  else:
   pat+=1
   if pat>=8:break
 teacher.load_state_dict(beststates[0]);student.load_state_dict(beststates[1]);teacher.eval();student.eval()
 sv,_=mask_view(raw,430000+seed)
 with torch.no_grad():z=teacher(xx).numpy();pred=student(torch.tensor(sv)).numpy()
 return z,pred,float(best),ep+1,sum(p.numel() for p in teacher.parameters())+sum(p.numel() for p in student.parameters())

def probe(z,y,tr,te,micro,alpha=20):
 a=z[tr];mean=a.mean(0);std=np.maximum(a.std(0),.01);a=(a-mean)/std;b=(z[te]-mean)/std
 # Evaluate R2 against TRAIN-donor expression mean, no held-out donor scaling.
 target=y[tr];model=Ridge(alpha=alpha).fit(a,target);pred=model.predict(b)
 baseline=np.broadcast_to(target.mean(0),pred.shape)
 den=((y[te]-baseline)**2).sum();num=((y[te]-pred)**2).sum()
 score=1-num/den if den>0 else np.nan
 mm=micro[te];ind=te[mm]
 if len(ind)>3:
  p=pred[mm];base=np.broadcast_to(target.mean(0),p.shape);den=((y[ind]-base)**2).sum();micro_r2=1-((y[ind]-p)**2).sum()/den if den>0 else np.nan
 else:micro_r2=np.nan
 return float(score),float(micro_r2),pred

def main():
 micro=meta.native_class.str.contains('microgl',case=False).to_numpy(); donors=np.array(sorted(meta.loc[micro,'donor_id'].unique()));results=[];sources=[]
 for fold,splitseed in enumerate([4300,4317]):
  rng=np.random.default_rng(splitseed);perm=rng.permutation(donors);td=set(perm[:34]);vd=set(perm[34:42]);testd=set(perm[42:]); d=meta.donor_id.to_numpy()
  tr=np.flatnonzero(np.isin(d,list(td)));val=np.flatnonzero(np.isin(d,list(vd)));te=np.flatnonzero(np.isin(d,list(testd)))
  assert len(set(d[tr])&set(d[te]))==0 and len(set(d[val])&set(d[te]))==0
  dense,inp,parts,y,source=features(tr,val,te);sources.append(source); print('fold',fold,'train,val,test',len(tr),len(val),len(te),'micro',int(micro[tr].sum()),int(micro[val].sum()),int(micro[te].sum()),'panels',source,flush=True)
  # Independent negative baselines: technical-only and shuffled teacher-state probe.
  op=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(meta[['operator_index']].iloc[tr]);opz=op.transform(meta[['operator_index']]);q=np.random.default_rng(300+fold).normal(size=(len(meta),32)).astype(np.float32)
  for arm in ['TECHNICAL_ONLY','RANDOM_STATE']:
   z=opz if arm=='TECHNICAL_ONLY' else q
   r,r_m,_=probe(z,y,tr,te,micro)
   results.append(dict(fold=fold,arm=arm,teacher_r2=r,teacher_micro_r2=r_m,student_r2=np.nan,student_micro_r2=np.nan,teacher_params=0,student_params=0,teacher_epochs=0,student_epochs=0))
  for arm in ['EMA','RICH','SHARED','TEAM']:
   torch.manual_seed(100+fold)
   if arm=='EMA':
    z,spred,vl,ep,np_total=train_ema(inp,dense,tr,val,seed=100+fold);tp=np_total//2;stp=np_total-tp;se=ep
   else:
    model={'RICH':RichAE,'SHARED':SharedAE,'TEAM':TeamAE}[arm]();tp=sum(p.numel() for p in model.parameters())
    z,tl,ep=train_ae(model,inp,parts,tr,val,seed=100+fold);spred,vl,se,stp=train_student(arm,dense,z,tr,val,seed=100+fold)
   rt,rtm,_=probe(z,y,tr,te,micro);rs,rsm,_=probe(spred,y,tr,te,micro)
   rec=dict(fold=fold,arm=arm,teacher_r2=rt,teacher_micro_r2=rtm,student_r2=rs,student_micro_r2=rsm,teacher_params=tp,student_params=stp,teacher_epochs=ep,student_epochs=se,student_valid_loss=vl)
   results.append(rec);print('RESULT',json.dumps(rec),flush=True)
  print('completed fold',fold,flush=True)
 out={'scope':'HISTORICAL_DEVELOPMENT_ONLY_NO_BIOLOGICAL_WINNER','dataset':{'source':'FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K historical 50k FIT DONOR sample','subset_cells':len(meta),'microglia_cells':int(micro.sum()),'donors':len(donors),'operators':meta.operator_index.nunique(),'raw_reconstruction_max_abs_error':maxerr,'preprocessing':'invert original log1p via per-row single-count quantum; renormalize teacher and masked student independently; no preexisting whole-library denominator in model inputs','heldout_eval_genes':96,'donor_folds':2},'experiment':{'source_only_science_qualification':False,'current_v5_model_exact':False,'incumbent':'scaled single EMA student/teacher proxy, NOT current V5 exact implementation','rare_component':'low-prevalence common-core RNA proxy, NOT independently validated rare microglial biology','query_specificity':'NOT QUALIFIED: 1 query gene masked per sample, latent targets are not query-conditioned','independent_biology':'NOT TESTED: evaluation is heldout RNA genes from same historical study','capacity_matched':False,'protected_outcomes_opened':False,'training_authorized':False},'features_by_fold':sources,'results':results}
 for rec in out['results']:
  for k,v in list(rec.items()):
   if isinstance(v,(float,np.floating)) and not np.isfinite(v):rec[k]=None
 with open(ROOT+'/JEPA_TINY_TOURNAMENT_RESULTS_20260926.json','w') as fh:json.dump(out,fh,indent=2,allow_nan=False)
 print('COMPLETE wrote results JSON',flush=True)
if __name__=='__main__':main()
