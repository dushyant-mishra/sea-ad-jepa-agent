#!/usr/bin/env python3
"""Local failure-mode checks for historical, research-only JEPA pilot."""
import json,hashlib,sys,numpy as np
import JEPA_TINY_TOURNAMENT_20260926 as T
from pathlib import Path
R=Path('/mnt/data')
checks=[]
def check(name,condition):
 if not condition:raise AssertionError('FAIL '+name)
 checks.append(name);print('PASS '+name)
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for chunk in iter(lambda:f.read(8<<20),b''):h.update(chunk)
 return h.hexdigest()
known={'FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part001':'b8163f53a27f7cb1b526f8311d1b46b599502596c5d0be74fa588747a4e72b2e','FOUNDATION_DISCOVERY_EXPRESSION_41K_LOG1P10K.zip.part002':'5bc2ec30fb374b15f1c5a4764e1856b0664c13513462ef2f7e224c4b6f856875','FOUNDATION_CALIBRATION_BUNDLE_20260824.zip':'07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444','expression.zip':'1098fd4c3fac7a991f2d51ac86ecd0a7ae94be9373e5cc30b9d81be392d32fd4'}
for name,expected in known.items():check('authentic_source_SHA_'+name,sha(R/name)==expected)
check('reconstructed_raw_integer_quantum',T.maxerr<1e-5 and np.all(T.rawX.data==np.rint(T.rawX.data)))
check('physical_operator_support_not_all_measured',np.any(T.states==2) and np.any(T.states==0) and np.all(T.states[np.unique(T.meta.operator_index)][:,T.eligible]==1))
D=np.array(sorted(T.meta.loc[T.meta.native_class.str.contains('microgl',case=False),'donor_id'].unique()));rng=np.random.default_rng(4300);perm=rng.permutation(D)
tr=np.flatnonzero(T.meta.donor_id.isin(perm[:34]));v=np.flatnonzero(T.meta.donor_id.isin(perm[34:42]));te=np.flatnonzero(T.meta.donor_id.isin(perm[42:]));allids=T.meta.donor_id.to_numpy()
check('donor_disjoint_train_validation_test',not (set(allids[tr])&set(allids[v]) or set(allids[tr])&set(allids[te]) or set(allids[v])&set(allids[te])))
raw,x,parts,y,src=T.features(tr,v,te)
qseed=914;clean,q=T.mask_view(raw[:30].copy(),qseed);mut=raw[:30].copy();mut[np.arange(len(q)),q]+=111.0;altered,q2=T.mask_view(mut,qseed)
check('query_scalar_counterfactual_invariant_student',np.array_equal(q,q2) and np.array_equal(clean,altered))
# Deliberately flawed full-library normalization leaks the supposedly hidden count.
keep=np.random.default_rng(qseed).random(raw[:30].shape)>.4;keep[np.arange(len(q)),q]=False
bad1=T.panel_log(raw[:30],np.arange(700))*keep;bad2=T.panel_log(mut,np.arange(700))*keep
check('planted_global_denominator_leak_detected',np.max(abs(bad1-bad2))>.001)
check('independent_probe_has_96_genes',y.shape[1]==96 and src['independent_eval']==96)
Rjson=json.load(open(R/'JEPA_TINY_TOURNAMENT_RESULTS_20260926.json'))
check('exact_two_donor_splits_six_arms',len(Rjson['results'])==12 and sorted(set(x['arm'] for x in Rjson['results']))==['EMA','RANDOM_STATE','RICH','SHARED','TEAM','TECHNICAL_ONLY'])
check('target_query_specificity_not_falsely_certified',Rjson['experiment']['query_specificity'].startswith('NOT QUALIFIED') and not Rjson['experiment']['current_v5_model_exact'])
check('no_full104_training_or_protected_results',Rjson['experiment']['training_authorized'] is False and Rjson['experiment']['protected_outcomes_opened'] is False)
check('train_only_feature_sets_differ_across_folds',Rjson['features_by_fold'][0]['selected_addresses_sha256']!=Rjson['features_by_fold'][1]['selected_addresses_sha256'])
check('teacher_heldout_expression_beyond_technical_control',all(next(x for x in Rjson['results'] if x['arm']=='RICH' and x['fold']==fold)['teacher_r2']>next(x for x in Rjson['results'] if x['arm']=='TECHNICAL_ONLY' and x['fold']==fold)['teacher_r2'] for fold in range(2)))
print('ALL',len(checks),'TOURNAMENT_RESEARCH_GATES_PASS_NOT_BIOLOGICAL_AUTHORITY')
