import unittest
from dataclasses import replace
from JEPA_R6_ARCHITECTURE_BRIDGE_RESEARCH_20260926 import *

class BridgeTests(unittest.TestCase):
    def setUp(self):self.p=example()
    def reject(self,p):
        with self.assertRaises(ContractError):p.validate()
    def test_single_valid(self):self.assertFalse(self.p.validate()['training_authorized'])
    def test_q_visible_teacher_allowed(self):self.assertTrue(self.p.validate()['q_visible_to_teacher'])
    def test_q_excluded_policy_rejects_visible(self):self.reject(replace(self.p,query_value_teacher_policy="TEACHER_Q_EXCLUDED"))
    def test_q_excluded_teacher_passes(self):
        c=replace(self.p.heads[0],input_addresses=(200,201,10));p=replace(self.p,heads=(c,),query_value_teacher_policy="TEACHER_Q_EXCLUDED");self.assertFalse(p.validate()['q_visible_to_teacher'])
    def test_student_q_count(self):self.reject(replace(self.p,student=replace(self.p.student,value_addresses=(174,10))))
    def test_denominator_q(self):self.reject(replace(self.p,student=replace(self.p.student,normalization_ancestors=(10,174))))
    def test_qc_q(self):self.reject(replace(self.p,student=replace(self.p.student,qc_ancestors=(10,174))))
    def test_student_teacher_panel(self):self.reject(replace(self.p,student=replace(self.p.student,value_addresses=(10,200))))
    def test_missing_ancestry(self):self.reject(replace(self.p,student=replace(self.p.student,query_target_addresses=(200,))))
    def test_same_cell(self):
        c=replace(self.p.heads[0],observation=replace(self.p.heads[0].observation,cell="donor_similar_other_cell"));self.reject(replace(self.p,heads=(c,)))
    def test_duplicate_head(self):self.reject(replace(self.p,heads=(self.p.heads[0],self.p.heads[0])))
    def test_missing_support_abstains(self):
        rare=TeacherHead("RARE",Observation("original_cell_17",174,(),False,"b"*64),(),(),False)
        p=replace(self.p,heads=(*self.p.heads,rare));self.assertFalse(p.validate()['heads']['RARE'])
    def test_unsupported_fake_zero(self):
        rare=TeacherHead("RARE",Observation("original_cell_17",174,(0.,),False,"b"*64),(),(),False)
        self.reject(replace(self.p,heads=(*self.p.heads,rare)))
    def test_no_core(self):self.reject(replace(self.p,heads=()))
    def test_queried_scalar_as_target(self):
        c=replace(self.p.heads[0],target_addresses=(174,));self.reject(replace(self.p,heads=(c,)))
    def test_nonhex_sha(self):
        c=replace(self.p.heads[0],observation=replace(self.p.heads[0].observation,source_sha256="r"*64));self.reject(replace(self.p,heads=(c,)))
    def test_multihead_supported(self):
        fine=TeacherHead("FINE",Observation("original_cell_17",174,(.4,.6),True,"c"*64),(174,202),(202,),True)
        p=replace(self.p,heads=(*self.p.heads,fine),student=replace(self.p.student,query_target_addresses=(200,201,202)))
        self.assertTrue(p.validate()['heads']['FINE'])
    def test_copied_specialist_warning_not_suppressed(self):
        rare=TeacherHead("RARE",Observation("original_cell_17",174,(.2,.3),True,"c"*64),(174,202),(202,),True)
        p=replace(self.p,heads=(*self.p.heads,rare),student=replace(self.p.student,query_target_addresses=(200,201,202)))
        self.assertTrue(p.validate()['copied_head_warning']['RARE'])
    def top(self):return Topology((Module('s','ONLINE_ENCODER',2,protected(2)),Module('t','EMA_TEACHER',2,protected(2)),Module('pred','ONLINE_PREDICTOR',0,())),('s','pred'),(('s','t'),))
    def test_topology_valid(self):self.assertFalse(self.top().validate()['training_authorized'])
    def test_teacher_in_optimizer(self):self.reject(replace(self.top(),optimizer_modules=('s','t','pred')))
    def test_missing_online_predictor(self):self.reject(replace(self.top(),optimizer_modules=('s',)))
    def test_missing_protected_role(self):
        t=self.top();self.reject(replace(t,modules=(replace(t.modules[0],protected=protected(2)[:-1]),*t.modules[1:])))
    def test_missing_ema_pair(self):self.reject(replace(self.top(),ema_pairs=()))
    def test_ema_depth_mismatch(self):
        t=self.top();self.reject(replace(t,modules=(t.modules[0],replace(t.modules[1],depth=3,protected=protected(3)),t.modules[2])))
    def test_multi_teacher_pair_valid(self):
        t=self.top();m=(*t.modules,Module('s2','ONLINE_ENCODER',1,protected(1)),Module('t2','EMA_TEACHER',1,protected(1)))
        self.assertEqual(len(Topology(m,('s','pred','s2'),(('s','t'),('s2','t2'))).validate()['ema_pairs']),2)

if __name__=='__main__':unittest.main(verbosity=2)
