#!/usr/bin/env python3
"""R6 non-authorizing historical R5 target stress test; never inspect protected outcomes.
Uses same already-developed donor partitions, not independent confirmation.
1. Count-thinning stability of N8/N16/N32 (descriptive, no selection on heldout donors).
2. Increment of observed q RNA after N8 and strictly non-q student-panel technical features.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import importlib.util,json,hashlib,time
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder
ROOT=Path('/mnt/data')
s=importlib.util.spec_from_file_location('historical',ROOT/'JEPA_TINY_TOURNAMENT_20260926.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
meta=f.meta; donor=meta.donor_id.to_numpy();micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy();op=meta.operator_index.to_numpy();D=np.array(sorted(set(donor[micro])));perm=np.random.default_rng(20260926).permutation(D);folds=np.array_split(perm,5)

def fit(x,y,tr,te,w):
    avg=np.average(x[tr],axis=0,weights=w);std=np.maximum(np.sqrt(np.average((x[tr]-avg)**2,axis=0,weights=w)),.05)
    return Ridge(alpha=20).fit((x[tr]-avg)/std,y[tr],sample_weight=w/w.mean()).predict((x[te]-avg)/std)

def panel(k):
    sm=k.sum(1,keepdims=True)
    return np.log1p(np.divide(10000*k,sm,out=np.zeros_like(k,dtype='float64'),where=sm>0))

def metrics(a,b,sub):
    a=a[sub];b=b[sub]
    if len(a)<3:return None
    # Split-half explained repeatability (upper bound includes technical common artifacts).
    mid=(a+b)/2; noise=(a-b)/2
    total=np.mean((mid-mid.mean(0))**2)
    err=np.mean(noise**2)
    rel=float((total-err)/(total+err)) if total+err else None
    return {'count':len(a),'repeatability_proxy':rel,'half_mse':float(np.mean((a-b)**2)),'median_cosine':float(np.median(np.sum(a*b,axis=1)/(np.linalg.norm(a,axis=1)*np.linalg.norm(b,axis=1)+1e-9)))}

start=time.time();rows=[];qc=[]
for fi,held in enumerate(folds):
    rest=perm[~np.isin(perm,held)]; rr=np.random.default_rng(20261010+fi).permutation(rest);tr=np.flatnonzero(np.isin(donor,rr[8:]));te=np.flatnonzero(np.isin(donor,held));tm=np.intersect1d(tr,np.flatnonzero(micro))
    raw,full,parts,y,src=f.features(tr,np.flatnonzero(np.isin(donor,rr[:8])),te)
    a=f.rawX[tm][:,f.eligible].toarray();pv=(a>0).mean(0);vv=np.var(np.log1p(a),axis=0);pool=np.flatnonzero((pv>.10)&(pv<.98));pool=pool[np.argsort(-vv[pool])][:1600];ev=f.eligible[np.random.default_rng(43).choice(pool[200:1400],size=96,replace=False)];assert hashlib.sha256(ev.astype('<i4').tobytes()).hexdigest()==src['evaluation_addresses_sha256'];original=f.rawX[:,ev].toarray().astype(np.float64)
    # TECH features never include q/N/H; these 700 independently selected measured genes exclude full 96-feature teacher panel.
    ob=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(op[tr,None]);vtech=np.c_[ob.transform(op[:,None]),np.log1p(raw.sum(1)),(raw>0).sum(1),np.log1p(raw).mean(1)]
    _,inv,cnt=np.unique(donor[tr],return_inverse=True,return_counts=True);weights=(1/cnt[inv])*(len(tr)/len(cnt))
    qids=np.random.default_rng(1009+fi).choice(48,size=8,replace=False)
    for q in qids:
        cor=np.corrcoef(np.log1p(original[tm]),rowvar=False)[q].copy();cor[q]=0;cor[~np.isfinite(cor)]=0
        other=np.arange(48);other=other[other!=q];ns=other[np.argsort(-np.abs(cor[other]),kind='stable')];hs=np.arange(48,96)[np.argsort(-np.abs(cor[48:]),kind='stable')[:8]]
        hcounts=original[:,hs];hy=panel(hcounts);qscalar=np.log1p(original[:,q,None]);
        for k in (8,16,32):
            neigh=ns[:k];nc=original[:,neigh];valid=(nc.sum(1)>0)&(hcounts.sum(1)>0)
            T=panel(nc)
            # Restrict to same positive support in both split views for honest no-fake-zero comparison.
            tevalid=te[valid[te]]
            rng=np.random.default_rng(7011+fi*1000+q*10+k)
            h1=rng.binomial(nc[tevalid].astype(np.int64),.5).astype(np.float64);h2=nc[tevalid]-h1
            both=(h1.sum(1)>0)&(h2.sum(1)>0)
            A=panel(h1[both]);B=panel(h2[both]);m=micro[tevalid][both]
            for region,sub in [('ALL',np.ones(len(A),dtype=bool)),('MICRO',m)]:
                mt=metrics(A,B,sub)
                if mt:rows.append({'fold':fi,'q':int(ev[q]),'region':region,'panel_size':k,'section':'THINNING','valid_full':int(len(tevalid)),'valid_two_halves':int(both.sum()),**mt})
            if k==8:
                tt=tr[valid[tr]];ee=tevalid;w=weights[valid[tr]]
                obs={'N_ONLY':T,'N_PLUS_Q':np.c_[T,qscalar],'N_PLUS_TECH':np.c_[T,vtech],'N_PLUS_TECH_PLUS_Q':np.c_[T,vtech,qscalar],'TECH_ONLY':vtech,'TECH_PLUS_Q':np.c_[vtech,qscalar],'Q_ONLY':qscalar}
                # extra q contribution beyond N+technical features; all outcomes H held out from these inputs
                ref=np.average(hy[tt],axis=0,weights=w)
                for name,xx in obs.items():
                    pred=fit(xx,hy,tt,ee,w)
                    for region,sub in [('ALL',np.ones(len(ee),dtype=bool)),('MICRO',micro[ee])]:
                        if not sub.any():continue
                        den=((hy[ee][sub]-ref)**2).sum();r2=float(1-((hy[ee][sub]-pred[sub])**2).sum()/den) if den>0 else None
                        rows.append({'fold':fi,'q':int(ev[q]),'region':region,'section':'Q_CONDITIONAL','model':name,'r2':r2,'valid_test_cells':int(sub.sum()),'test_donors':int(len(set(donor[ee[sub]])))})
                # Student query count never in input; target n/h unchanged by q counterfactual
                mutated=original[te].copy();mutated[:,q]+=83
                assert np.array_equal(panel(mutated[:,neigh]),T[te])
                assert np.array_equal(panel(mutated[:,hs]),hy[te])
                qc.append({'fold':fi,'q':int(ev[q]),'n_sha256':hashlib.sha256(ev[neigh].astype('<i4').tobytes()).hexdigest(),'h_sha256':hashlib.sha256(ev[hs].astype('<i4').tobytes()).hexdigest(),'query_count_target_invariance':True,'n_h_disjoint':len(set(neigh)&set(hs))==0})
    print('fold',fi,'done',flush=True)
summary={}
for sect in ('THINNING','Q_CONDITIONAL'):
    summary[sect]={}
    for region in ('ALL','MICRO'):
        regionrows=[r for r in rows if r['section']==sect and r['region']==region]
        key='panel_size' if sect=='THINNING' else 'model'
        summary[sect][region]={str(v):{'mean':float(np.mean([r['repeatability_proxy'] if sect=='THINNING' else r['r2'] for r in regionrows if r[key]==v and (r['repeatability_proxy'] if sect=='THINNING' else r['r2']) is not None])),'tasks':len([r for r in regionrows if r[key]==v]),'median_valid':float(np.median([r['valid_two_halves'] if sect=='THINNING' else r['valid_test_cells'] for r in regionrows if r[key]==v]))} for v in sorted(set(r[key] for r in regionrows))}
result={'schema':'JEPA_R6_HISTORICAL_TEACHER_TARGET_STRESS_NONAUTHORIZING','scope':'REUSED_1561_CELL_50_DONOR_HISTORICAL_SUBSET_NO_INDEPENDENT_BIOLOGY','counts':{'folds':5,'query_fold_tasks':40,'target_sensitivity_tests':len(qc)},'description':'Repeated half-count N8,N16,N32 stability, and q scalar incremental predictive value for same-assay heldout H8 after technical features from disjoint 700-gene student panel. No biological fidelity claim.','summary':summary,'rows':rows,'source_checks':qc,'training_authorized':False,'biological_target_qualified':False,'protected_opened':False,'elapsed_seconds':round(time.time()-start,2)}
p=ROOT/'JEPA_R6_TEACHER_TARGET_STRESS_RESULTS_20260926.json';p.write_text(json.dumps(result,indent=2));print(json.dumps(summary,indent=2));print('SAVED',p,flush=True)
