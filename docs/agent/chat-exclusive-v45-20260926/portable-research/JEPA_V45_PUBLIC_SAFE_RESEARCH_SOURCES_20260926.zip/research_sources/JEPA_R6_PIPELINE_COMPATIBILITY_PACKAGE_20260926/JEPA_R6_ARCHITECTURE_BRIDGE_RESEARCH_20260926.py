#!/usr/bin/env python3
"""NON-AUTHORIZING proposed V5 architecture/interface bridge; no training or issuer calls.
Validates logical inputs and topology only. Digest syntax is NOT source authentication.
"""
from dataclasses import dataclass
from typing import Mapping, Tuple
import hashlib, json, math, re

HEADS=("CORE","FINE","RARE")
ROLES=("attention_norm","attention.query","attention.key","attention.value")
PARAMS=("weight","bias")
HEX=re.compile(r"[0-9a-f]{64}\Z")
class ContractError(ValueError):pass

def check_sha(x):
    if not isinstance(x,str) or not HEX.fullmatch(x):raise ContractError("invalid source digest; format is not proof of original bytes")
    return x

@dataclass(frozen=True)
class Observation:
    cell: str
    query: int
    values: Tuple[float,...]
    measured: bool
    source_sha256: str
    def verify(self):
        if not isinstance(self.cell,str) or not self.cell:raise ContractError("cell key absent")
        if type(self.query)!=int or not 0<=self.query<41238:raise ContractError("invalid query address")
        check_sha(self.source_sha256)
        if type(self.measured)!=bool:raise ContractError("measured must be a boolean")
        if self.measured and (not self.values or not all(math.isfinite(v) for v in self.values)):
            raise ContractError("measured target empty/nonfinite")
        if not self.measured and self.values:raise ContractError("unmeasured observation fabricated as zero/vector")

@dataclass(frozen=True)
class TeacherHead:
    head: str
    observation: Observation
    # These are observational input address *lineages*, not claims of observed signal.
    input_addresses: Tuple[int,...]
    target_addresses: Tuple[int,...]
    biological_eligibility: bool
    def verify(self):
        if self.head not in HEADS:raise ContractError("unrecognized head")
        self.observation.verify()
        if type(self.biological_eligibility)!=bool:raise ContractError("eligibility not boolean")
        if len(set(self.input_addresses))!=len(self.input_addresses):raise ContractError("duplicate input address")
        if len(set(self.target_addresses))!=len(self.target_addresses):raise ContractError("duplicate target address")
        if any(type(a)!=int or not 0<=a<41238 for a in (*self.input_addresses,*self.target_addresses)):
            raise ContractError("address outside canonical universe")
        if self.observation.query in self.target_addresses:raise ContractError("q scalar directly declared as measured target")
        if (not self.observation.measured or not self.biological_eligibility) and self.observation.values:
            raise ContractError("abstaining teacher carries values")

@dataclass(frozen=True)
class StudentView:
    observation: Observation
    value_addresses: Tuple[int,...]
    # All ancestors of normalization/global/QC inputs must be declared, even if not explicit features.
    normalization_ancestors: Tuple[int,...]
    qc_ancestors: Tuple[int,...]
    query_target_addresses: Tuple[int,...]
    def verify(self):
        self.observation.verify()
        forbidden=set(self.query_target_addresses)|{self.observation.query}
        for name,addresses in (("student value",self.value_addresses),("student normalization",self.normalization_ancestors),("student QC",self.qc_ancestors)):
            if set(addresses)&forbidden:raise ContractError(name+" contains hidden query/teacher target measurement")
            if any(type(a)!=int or not 0<=a<41238 for a in addresses):raise ContractError("invalid student input lineage")

@dataclass(frozen=True)
class TeacherTargetPackage:
    heads: Tuple[TeacherHead,...]
    student: StudentView
    query_value_teacher_policy: str
    def validate(self):
        if self.query_value_teacher_policy not in ("ALLOW_TEACHER_Q_WITH_SCALAR_DIAGNOSTIC","TEACHER_Q_EXCLUDED"):
            raise ContractError("unknown query policy")
        self.student.verify()
        if not self.heads or self.heads[0].head!="CORE":raise ContractError("supported core target must be first")
        if len({x.head for x in self.heads})!=len(self.heads):raise ContractError("duplicate head")
        cell,q=self.student.observation.cell,self.student.observation.query
        for x in self.heads:
            x.verify()
            if (x.observation.cell,x.observation.query)!=(cell,q):raise ContractError("cross-cell or mismatched q teacher target")
            if self.query_value_teacher_policy=="TEACHER_Q_EXCLUDED" and q in x.input_addresses:
                raise ContractError("teacher q excluded policy violated")
        if not self.heads[0].observation.measured or not self.heads[0].biological_eligibility:
            raise ContractError("core target unsupported")
        target_set=set().union(*(set(h.target_addresses) for h in self.heads))
        if target_set!=set(self.student.query_target_addresses):raise ContractError("student forbidden target set incomplete")
        return {'training_authorized':False,'heads':{h.head:bool(h.observation.measured and h.biological_eligibility) for h in self.heads},
                'q_visible_to_teacher':any(q in h.input_addresses for h in self.heads),
                'copied_head_warning':{h.head:h.observation.values==self.heads[0].observation.values
                                       for h in self.heads[1:] if h.observation.measured}}

@dataclass(frozen=True)
class Module:
    name: str
    role: str # ONLINE_ENCODER, ONLINE_PREDICTOR, EMA_TEACHER, or FROZEN_NONPARAMETRIC
    depth: int
    protected: Tuple[str,...] # e.g. block0/attention.query/weight

@dataclass(frozen=True)
class Topology:
    modules: Tuple[Module,...]
    optimizer_modules: Tuple[str,...]
    ema_pairs: Tuple[Tuple[str,str],...]
    def validate(self):
        if not self.modules:raise ContractError("no modules")
        by={m.name:m for m in self.modules}
        if len(by)!=len(self.modules):raise ContractError("duplicate module")
        trainable={m.name for m in self.modules if m.role in ("ONLINE_ENCODER","ONLINE_PREDICTOR")}
        teachers={m.name for m in self.modules if m.role=="EMA_TEACHER"}
        if set(self.optimizer_modules)!=trainable or len(self.optimizer_modules)!=len(trainable):
            raise ContractError("optimizer must include all online modules exactly once, no teacher")
        for m in self.modules:
            if m.role not in ("ONLINE_ENCODER","ONLINE_PREDICTOR","EMA_TEACHER","FROZEN_NONPARAMETRIC"):
                raise ContractError("unknown module role")
            if m.role in ("ONLINE_ENCODER","EMA_TEACHER"):
                if type(m.depth)!=int or m.depth<1:raise ContractError("invalid encoder depth")
                expected={f"block{i}/{r}/{p}" for i in range(m.depth) for r in ROLES for p in PARAMS}
                if set(m.protected)!=expected or len(m.protected)!=len(expected):
                    raise ContractError(f"protected registry incomplete for module {m.name}")
            elif m.protected:raise ContractError("non-encoder claims attention protection")
        if len(set(self.ema_pairs))!=len(self.ema_pairs):raise ContractError("duplicate EMA pair")
        ema_targets={t for _,t in self.ema_pairs}
        if ema_targets!=teachers or len(self.ema_pairs)!=len(teachers):
            raise ContractError("each EMA teacher must have exactly one update pairing")
        for source,target in self.ema_pairs:
            if source not in trainable or by[source].role!="ONLINE_ENCODER" or by[target].role!="EMA_TEACHER":
                raise ContractError("invalid EMA pairing")
            if by[source].depth!=by[target].depth:raise ContractError("EMA pair geometry mismatch")
        return {'training_authorized':False,'protected_tensors_by_module':{m.name:len(m.protected) for m in self.modules},
                'ema_pairs':list(self.ema_pairs),'optimizer_modules':list(self.optimizer_modules)}

def protected(depth):return tuple(f"block{i}/{r}/{p}" for i in range(depth) for r in ROLES for p in PARAMS)

def example():
    sha="a"*64
    o=Observation("original_cell_17",174,(.2,.3),True,sha)
    student=StudentView(o,(10,11,12),(10,11,12),(10,11),(200,201))
    core=TeacherHead("CORE",o,(174,200,201,10),(200,201),True)
    return TeacherTargetPackage((core,),student,"ALLOW_TEACHER_Q_WITH_SCALAR_DIAGNOSTIC")

if __name__=='__main__':
    print(json.dumps({'target':example().validate(),'topology':Topology((Module('student','ONLINE_ENCODER',2,protected(2)),Module('teacher','EMA_TEACHER',2,protected(2)),Module('predictor','ONLINE_PREDICTOR',0,())),('student','predictor'),(('student','teacher'),)).validate()},indent=2))
