#!/usr/bin/env python3
"""Research-only, outcome-blind *identity* join over existing authenticated ETL.

Requires an existing checkout that contains the two exact source commits. Reads
small committed guide/target identity tables via `git show <commit>:<path>`; does
NOT open expression counts, ATAC fragments, target engagement/effect columns,
protected data, or restricted datasets. No target selection or authorization.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import io
import json
import pathlib
import subprocess
import sys

ETL_COMMIT = "d6211320a7e7d685dab1b2cf45c6c0a16c7f9c8c"
P = "analysis/therapeutic_perturbation_etl/"
INPUTS = {
    "gse178317_guide_library": (ETL_COMMIT, P + "reference/GSE178317_sgrna_library_suppl_table5.csv"),
    "gse301119_crispri_guide_identity": (ETL_COMMIT, P + "evidence/gse301119/CRISPRi_guide_donor_meta.csv"),
    "gse301119_crispra_guide_identity": (ETL_COMMIT, P + "evidence/gse301119/CRISPRa_guide_donor_meta.csv"),
    "gse293118_guide_identity": (ETL_COMMIT, P + "evidence/gse293118/GSE293118_perturbation_identity.csv"),
    "gse311359_guide_identity": (ETL_COMMIT, P + "evidence/gse311359/GSE311359_perturbation_identity.csv"),
    "stage75f_primary_rna_hypotheses": (ETL_COMMIT, "results/tables/stage75f_primary_tf_target_gene_evidence_summary_v1.csv"),
    "stage75f_secondary_rna_hypotheses": (ETL_COMMIT, "results/tables/stage75f_secondary_tf_target_gene_evidence_summary_v1.csv"),
    "gse254205_sample_identity": (ETL_COMMIT, P + "evidence/gse254205/GSE254205_sample_identity.csv"),
}
# R8 research-only hypothesis panels and named RNA readout challenges. These are
# NOT scientifically approved target definitions and NOT a production exclusion.
PROGRAMS = {
 "APOE": {"partners": ["APOC1", "ABCA1", "GPNMB", "TREM2"], "rna_readouts": ["CTSD", "LPL"]},
 "P2RY12": {"partners": ["TMEM119", "CX3CR1", "GPR34", "C1QA"], "rna_readouts": ["SALL1", "CSF1R"]},
 "HLA-DRA": {"partners": ["CD74", "HLA-DPA1", "HLA-DMA", "IFI30"], "rna_readouts": ["HLA-DMB", "CTSS"]},
}
REFERENCES = ["RPLP0", "EEF1A1", "PGK1", "HPRT1", "PPIA", "RPL13A", "GUSB", "SDHA"]
EXTRA_AUDIT_SENTINELS = ["BIN1", "PLCG2", "INPP5D"]


def get_git_bytes(repo: pathlib.Path, sha: str, path: str) -> bytes:
    result = subprocess.run(["git", "-C", str(repo), "show", f"{sha}:{path}"],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode:
        raise RuntimeError(f"SOURCE_UNAVAILABLE {sha}:{path}: {result.stderr.decode(errors='replace')[:400]}")
    return result.stdout


def parse_csv(name: str, source: bytes) -> list[dict[str, str]]:
    try:
        txt = source.decode("utf-8-sig")
        obj = csv.DictReader(io.StringIO(txt))
        out = list(obj)
    except Exception as e:
        raise ValueError(f"MALFORMED_CSV {name}: {e}") from e
    if not obj.fieldnames or not out:
        raise ValueError(f"EMPTY_OR_HEADERLESS_SOURCE {name}")
    if any(None in row or any(v is None for v in row.values()) for row in out):
        raise ValueError(f"MALFORMED_ROWS {name}")
    return out


def require_fields(name: str, rows: list[dict], *fields: str):
    absent = set(fields) - set(rows[0])
    if absent:
        raise ValueError(f"SOURCE_SCHEMA_DRIFT {name} {sorted(absent)}")


def build(tables: dict[str, list[dict]]) -> tuple[list[dict], dict]:
    a = tables
    require_fields("gse178317", a["gse178317_guide_library"], "target_gene")
    for mode in ("crispri", "crispra"):
        require_fields("gse301119_"+mode, a[f"gse301119_{mode}_guide_identity"], "Gene_Targeted", "crispr")
    require_fields("gse293118", a["gse293118_guide_identity"], "target_id", "target_class", "guide_id")
    require_fields("gse311359", a["gse311359_guide_identity"], "nominated_gene", "target_class", "guide_id")
    for t in ("stage75f_primary_rna_hypotheses", "stage75f_secondary_rna_hypotheses"):
        require_fields(t, a[t], "target_gene", "validated_regulation", "edge_edge_type")
        if any(x["validated_regulation"].strip().lower() != "false" for x in a[t]):
            raise ValueError("STAGE75F_AUTHORITY_CHANGED_REVIEW_REQUIRED")
        if any(x["edge_edge_type"] != "microglia_snrna_sample_coactivity" for x in a[t]):
            raise ValueError("STAGE75F_LINEAGE_CHANGED_REVIEW_REQUIRED")
    require_fields("gse254205", a["gse254205_sample_identity"], "sample_id", "condition", "replicate")

    g178 = {x["target_gene"] for x in a["gse178317_guide_library"] if x["target_gene"] != "NTC" and not x["target_gene"].lower().startswith("non-")}
    mg = {}
    for mode in ("crispri", "crispra"):
        mg[mode] = {x["Gene_Targeted"] for x in a[f"gse301119_{mode}_guide_identity"]
                    if x["crispr"] == "Perturbed" and x["Gene_Targeted"]}
    g293 = {x["target_id"] for x in a["gse293118_guide_identity"] if x["target_class"] == "gene"}
    g311 = {x["nominated_gene"] for x in a["gse311359_guide_identity"] if x["nominated_gene"]}
    d311 = collections.Counter(x["guide_id"] for x in a["gse311359_guide_identity"])
    duplicated_guides = {k:v for k,v in d311.items() if v > 1}
    st75 = {x["target_gene"] for t in ("stage75f_primary_rna_hypotheses", "stage75f_secondary_rna_hypotheses") for x in a[t]}
    conditions = collections.Counter(x["condition"] for x in a["gse254205_sample_identity"])

    rows = []
    for program, definition in PROGRAMS.items():
        for gene, role in [(program,"query")]+[(g,"partner") for g in definition["partners"]]+[(g,"rna_readout") for g in definition["rna_readouts"]]:
            rows.append((program,gene,role))
    for gene in REFERENCES:
        rows.append(("ALL_THREE",gene,"reference"))
    for gene in EXTRA_AUDIT_SENTINELS:
        rows.append(("AUDIT_ONLY",gene,"not_a_selected_R8_target"))

    out = []
    for program, gene, role in rows:
        out.append({
            "program": program, "gene": gene, "role": role,
            "gse178317_day8_guide_library": "TARGET_PRESENT_DEVELOPMENT" if gene in g178 else "NO_TARGET_IN_THIS_LIBRARY",
            "gse301119_macrophage_crispri_guide_identity": "TARGET_PRESENT_ESTIMATOR_NOT_QUALIFIED" if gene in mg["crispri"] else "NO_TARGET_IN_THIS_LIBRARY",
            "gse301119_macrophage_crispra_guide_identity": "TARGET_PRESENT_ESTIMATOR_NOT_QUALIFIED" if gene in mg["crispra"] else "NO_TARGET_IN_THIS_LIBRARY",
            "gse293118_HMC3_gene_target": "TARGET_PRESENT_CELL_LINE" if gene in g293 else "NOT_PRESENT_AS_GENE_TARGET",
            "gse311359_iMGL_nominated_gene": "IDENTITY_COLLISION_EFFECT_INVALID" if gene == "BIN1" and d311["BIN1"] > 1 else ("NOMINATED_NOT_VALIDATED" if gene in g311 else "NOT_NOMINATED"),
            "stage75f_GSE174367_RNA_coactivity_hypothesis": "RNA_DERIVED_HYPOTHESIS_NOT_INDEPENDENT_GROUND_TRUTH" if gene in st75 else "NO_STAGE75F_GENE_HYPOTHESIS",
            # PR175 includes observed ATAC data; do not read it for target construction.
            "r8_genome_identity_status": "NOT_RECOMPUTED__REQUIRES_INDEPENDENT_ANNOTATION_ONLY_CROSSWALK",
        })
    manifest = {
        "scope": "EXISTING_ETL_IDENTITY_ONLY_RECONCILIATION__DEVELOPMENT_ONLY",
        "never_select_target_from": "observed external assay outcomes or cohort gene detection/accessibility",
        "input_data_families": {"gse178317_target_guide_library_n":len(g178),
                                "gse301119_crispri_target_names":len(mg["crispri"]),
                                "gse301119_crispra_target_names":len(mg["crispra"]),
                                "gse293118_gene_targets":len(g293),
                                "gse311359_duplicated_guide_ids":duplicated_guides,
                                "stage75f_gene_targets":len(st75),
                                "gse254205_conditions_and_technical_replicates":dict(conditions)},
        "gse178317_q_overlap": {q:q in g178 for q in PROGRAMS},
        "gse301119_q_overlap": {q: {mode:q in genes for mode,genes in mg.items()} for q in PROGRAMS},
        "r8_three_query_exclusion_union_size":len({x for p,d in PROGRAMS.items() for x in [p]+d["partners"]+REFERENCES}),
        "r8_six_separate_readouts_not_in_23_gene_exclusion": [g for d in PROGRAMS.values() for g in d["rna_readouts"]],
        "biological_validation_executed":False,"target_selected":False,
        "qualified_production_normalization":False,"training_authorized":False,
        "full104_protected_outcomes_opened":False,
        "qualification_limits":[
            "GSE178317 guide wells are technical; no independent biological replicates",
            "GSE301119 is primary macrophage with two donors; downstream estimator previously disqualified",
            "GSE293118 HMC3 is a cell line, not independent human donor validation",
            "GSE311359 BIN1 gene guide identity collision invalidates its original gene-level effects",
            "Stage75F is derived from the same Morabito RNA and is not biological ground truth",
            "PR175 contains observed ATAC values; no PR175 output is loaded by this script",
            "Existing PR175 45-gene panel is not an assay-wide R8 29-gene coverage check",
            "No observed ATAC value, respondent direction or differential expression used for target choice"
        ]}
    return out, manifest


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo",type=pathlib.Path,required=True)
    ap.add_argument("--out-dir",type=pathlib.Path,required=True)
    args=ap.parse_args()
    if args.out_dir.exists() and any(args.out_dir.iterdir()):
        raise SystemExit("STOP_OUTPUT_EXISTS")
    sources={};tables={}
    for name,(rev,path) in INPUTS.items():
        b=get_git_bytes(args.repo,rev,path)
        tables[name]=parse_csv(name,b)
        sources[name]={"git_commit":rev,"path":path,"bytes":len(b),"sha256_computed_from_git_bytes":hashlib.sha256(b).hexdigest(),"rows":len(tables[name])}
    rows,manifest=build(tables)
    manifest["sources"]=sources
    args.out_dir.mkdir(parents=True,exist_ok=True)
    out_csv=args.out_dir/"R8_EXISTING_ETL_IDENTITY_ALIGNMENT.csv"
    with out_csv.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    manifest["aligned_rows"]=len(rows)
    manifest["alignment_csv_sha256"]=hashlib.sha256(out_csv.read_bytes()).hexdigest()
    out_json=args.out_dir/"R8_EXISTING_ETL_IDENTITY_ALIGNMENT_RECEIPT.json"
    out_json.write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(json.dumps({"rows":len(rows),"sources":len(sources),"training_authorized":False,
                      "output_csv":str(out_csv),"output_receipt":str(out_json)},sort_keys=True))

if __name__=="__main__":
    main()
