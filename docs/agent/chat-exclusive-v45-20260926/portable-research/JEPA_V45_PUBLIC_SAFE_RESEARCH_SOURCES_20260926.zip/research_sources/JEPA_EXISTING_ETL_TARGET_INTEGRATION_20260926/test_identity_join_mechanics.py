"""Local parser/guard fixtures only; NOT a physical ETL source replay."""
import importlib.util
import pathlib
import unittest
P=pathlib.Path(__file__).with_name("build_existing_etl_target_crosswalk.py")
spec=importlib.util.spec_from_file_location("target_identity_join",P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def fixture():
  return {
   "gse178317_guide_library":[{"target_gene":"CSF1R"},{"target_gene":"NTC"}],
   "gse301119_crispri_guide_identity":[{"Gene_Targeted":"APOE","crispr":"Perturbed"},{"Gene_Targeted":"NTC","crispr":"Control"}],
   "gse301119_crispra_guide_identity":[{"Gene_Targeted":"APOE","crispr":"Perturbed"}],
   "gse293118_guide_identity":[{"target_id":"BIN1","target_class":"gene","guide_id":"BIN1_1"}],
   "gse311359_guide_identity":[{"nominated_gene":"BIN1","target_class":"other","guide_id":"BIN1"} for _ in range(3)],
   "stage75f_primary_rna_hypotheses":[{"target_gene":"APOE","validated_regulation":"False","edge_edge_type":"microglia_snrna_sample_coactivity"}],
   "stage75f_secondary_rna_hypotheses":[{"target_gene":"CD74","validated_regulation":"False","edge_edge_type":"microglia_snrna_sample_coactivity"}],
   "gse254205_sample_identity":[{"sample_id":x,"condition":x,"replicate":"rep1"} for x in ["NT","AB","AB_GNE"]]
  }

class MechanicsOnly(unittest.TestCase):
 def test_identity_roles_and_no_control_promotion(self):
  rows,rec=m.build(fixture()); idx={(r['program'],r['gene']):r for r in rows}
  self.assertEqual(len(rows),32)
  self.assertEqual(rec['r8_three_query_exclusion_union_size'],23)
  self.assertEqual(rec['input_data_families']['gse178317_target_guide_library_n'],1)
  self.assertIn('TARGET_PRESENT',idx['P2RY12','CSF1R']['gse178317_day8_guide_library'])
  self.assertIn('ESTIMATOR_NOT_QUALIFIED',idx['APOE','APOE']['gse301119_macrophage_crispri_guide_identity'])
  self.assertEqual(idx['HLA-DRA','HLA-DRA']['gse178317_day8_guide_library'],'NO_TARGET_IN_THIS_LIBRARY')
  self.assertFalse(rec['training_authorized'])
 def test_bin1_collision_is_a_hard_label(self):
  rows,_=m.build(fixture()); x=next(row for row in rows if row['gene']=='BIN1')
  self.assertEqual(x['gse311359_iMGL_nominated_gene'],'IDENTITY_COLLISION_EFFECT_INVALID')
 def test_rna_coactivity_never_promoted_to_validated_regulation(self):
  rows,_=m.build(fixture()); x=next(row for row in rows if row['gene']=='APOE')
  self.assertEqual(x['stage75f_GSE174367_RNA_coactivity_hypothesis'],'RNA_DERIVED_HYPOTHESIS_NOT_INDEPENDENT_GROUND_TRUTH')
  bad=fixture();bad['stage75f_primary_rna_hypotheses'][0]['validated_regulation']='True'
  with self.assertRaisesRegex(ValueError,'STAGE75F_AUTHORITY_CHANGED'):m.build(bad)
 def test_source_schema_and_lineage_fail_closed(self):
  bad=fixture();bad['gse301119_crispri_guide_identity'][0].pop('crispr')
  with self.assertRaisesRegex(ValueError,'SOURCE_SCHEMA_DRIFT'):m.build(bad)
  bad=fixture();bad['stage75f_primary_rna_hypotheses'][0]['edge_edge_type']='ATAC_validated'
  with self.assertRaisesRegex(ValueError,'STAGE75F_LINEAGE_CHANGED'):m.build(bad)
 def test_csv_parser_rejects_malformed_rows(self):
  with self.assertRaisesRegex(ValueError,'MALFORMED_ROWS'):
   m.parse_csv('bad',b'gene,assay\nA\n')
 def test_readouts_are_outside_the_23_gene_normalization_comparator(self):
  actual={q for q in m.PROGRAMS} | {g for p in m.PROGRAMS.values() for g in p['partners']} | set(m.REFERENCES)
  readouts={g for p in m.PROGRAMS.values() for g in p['rna_readouts']}
  self.assertEqual(len(actual),23);self.assertEqual(len(readouts),6);self.assertFalse(actual&readouts)

if __name__=='__main__':unittest.main()
