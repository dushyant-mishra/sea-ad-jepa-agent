#!/usr/bin/env python3
"""R8 historical developmental construction/measurement stress test. NO protected data.
Tests a measured target object; no neural training or claims of biological fidelity.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import json,hashlib,io,zipfile
from pathlib import Path
import numpy as np,pandas as pd,scipy.sparse as sp
R=Path('/mnt/data'); META=Path('/tmp/jepa_tour_meta.csv'); MATRIX=Path('/tmp/jepa_tour_logexpr.npz')
assert META.exists() and MATRIX.exists(), 'original-data-derived development cache unavailable'
PROGRAMS={
 'APOE_LIPID':{'q':6188,'panel':[11425,7194,2044, None],'readout':[]},
}
# Use frozen R7 exact gene mapping from the original archive, not hand-entered index guesses.
GENES={
 'APOE_LIPID':{'query':'APOE','panel':['APOC1','ABCA1','GPNMB','TREM2'],'readout':['CTSD','LPL']},
 'P2RY12_HOMEOSTATIC':{'query':'P2RY12','panel':['TMEM119','CX3CR1','GPR34','C1QA'],'readout':['SALL1','CSF1R']},
 'HLA_DRA_ANTIGEN':{'query':'HLA-DRA','panel':['CD74','HLA-DPA1','HLA-DMA','IFI30'],'readout':['HLA-DMB','CTSS']},
}
BUNDLE=R/'FOUNDATION_CALIBRATION_BUNDLE_20260824.zip'
sha=hashlib.sha256()
with BUNDLE.open('rb') as inp:
 for ch in iter(lambda:inp.read(8<<20),b''):sha.update(ch)
assert sha.hexdigest()=='07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444'
with zipfile.ZipFile(BUNDLE) as z:
 namespace=pd.read_csv(z.open(next(n for n in z.namelist() if n.endswith('address_namespace.csv'))))
 sym=namespace[namespace.identity_class=='current_exact'].set_index('symbol')['molecular_address_index'].to_dict()
 support_file=next(n for n in z.namelist() if n.endswith('FOUNDATION_OPERATOR_ADDRESS_OBSERVATION_STATE.npz'))
 with np.load(io.BytesIO(z.read(support_file)),allow_pickle=False) as s:support=s['states'].copy()
meta=pd.read_csv(META);X=sp.load_npz(MATRIX);assert X.shape==(len(meta),41238)
ops=meta.operator_index.to_numpy();donor=meta.donor_id.to_numpy();micro=meta.native_class.str.contains('microgl',case=False,na=False).to_numpy();assert micro.sum()==361
# Invert exact original log1p(10000*raw/full-source-library) with each observed 1-UMI entry.
base=np.expm1(np.minimum.reduceat(X.data,X.indptr[:-1]));assert np.all(base>0)
def raw_cols(cols):
 A=X[:,cols].toarray();v=np.expm1(A)/base[:,None];assert np.max(np.abs(v-np.rint(v)))<1e-5
 return np.rint(v).astype(np.int64)
# Complementary reference is all original measured common-ledger RNA EXCLUDING every q/panel/readout
# for all programs. Never use full-library denominator including the queried gene.
ban=set()
for g in GENES.values():
 for s in [g['query']]+g['panel']+g['readout']:
  assert s in sym,s
  ban.add(int(sym[s]))
assert len(ban)==21
HOUSE=['RPLP0','EEF1A1','PGK1','HPRT1','PPIA','RPL13A','GUSB','SDHA']
housecols=[int(sym[x]) for x in HOUSE]
assert len(set(housecols))==8 and not set(housecols)&ban
assert np.all(support[np.unique(ops[micro])[:,None],np.array(housecols)[None,:]]==1)
# Disjoint housekeeping reference, not an externally validated size factor.
house_raw=raw_cols(housecols).sum(1).astype(float)
print('DISJOINT_REFERENCE_POSITIVE',int(np.sum(house_raw[micro]>0)),'OF',int(micro.sum()),flush=True)
ban.update(housecols)
observed_total=np.zeros(X.shape[0],dtype=np.float64)
for i in range(X.shape[0]):
 sl=slice(X.indptr[i],X.indptr[i+1]);v=np.expm1(X.data[sl])/base[i];idx=X.indices[sl]
 # Excluded q, all candidate target and all held-out readout genes from the reference.
 observed_total[i]=np.rint(v[~np.isin(idx,list(ban))]).sum()
assert np.all(observed_total[micro]>0)

def target(panel,ref,alpha=.5):
 """Measured 1D log activity + 4D regularized CLR composition + separately retained uncertainty.
 Raw counts, support and q-invariance are also retained; no zero means missing modality.
 """
 total=panel.sum(axis=1);active=np.log1p(1e4*total/(ref+1e-8))
 prob=(panel+alpha)/(total[:,None]+alpha*panel.shape[1]);clr=np.log(prob)-np.log(prob).mean(1,keepdims=True)
 # Delta-method measurement precision proxies, not epistemic uncertainty.
 sd_act=np.sqrt(1/(total+.5)+1/(ref+.5));sd_comp=np.sqrt(1/(panel+alpha))
 return active,clr,sd_act,sd_comp

def corr(a,b,where):
 if where.sum()<12 or np.std(a[where])<1e-12 or np.std(b[where])<1e-12:return None
 return float(np.corrcoef(a[where],b[where])[0,1])

res={};checks=[];pilot_targets={};house_targets={};pilot_raw={}
for k,(name,g) in enumerate(GENES.items()):
 q=int(sym[g['query']]);pan=[int(sym[x]) for x in g['panel']];held=[int(sym[x]) for x in g['readout']];cols=[q]+pan+held
 assert len(set(cols))==7 and all(support[np.unique(ops)[:,None],np.array(cols[:5])[None,:]].reshape(-1))
 P=raw_cols(pan); Q=raw_cols([q]); microP=P[micro];pilot_raw[name]=microP.sum(1).astype(float); ref=observed_total[micro];mops=ops[micro];mdon=donor[micro]
 # All targets same exact cell and eligible gene support; non-target zeros are observations, not imputation.
 full=target(microP,ref);pilot_targets[name]=full[0].copy()
 # Alternative activity uses a fixed eight-gene reference DISJOINT from student, q and all readouts.
 house_targets[name]=target(microP,np.maximum(house_raw[micro],1))[0]  # zero-reference cells ABSTAIN below
 # Q-count mutation has no path to the target or the reference.
 counter=target(microP.copy(),ref.copy());assert all(np.array_equal(a,b) for a,b in zip(full,counter))
 # Explicit paired molecule partition, one split per query. Include zero counts, avoid conditioning on both halves positive.
 rng=np.random.default_rng(20260926+k); A=rng.binomial(microP,.5); B=microP-A
 # Reference split independent of panel, both halves have finite denominators.
 RA=rng.binomial(ref.astype(np.int64),.5);RB=ref.astype(np.int64)-RA
 a=target(A*2,RA*2);b=target(B*2,RB*2)
 positive=microP.sum(1)>0;both=(A.sum(1)>0)&(B.sum(1)>0)
 act_reliab=corr(a[0],b[0],np.ones(len(ref),dtype=bool)); act_pos=corr(a[0],b[0],positive)
 # Zero-count composition is NOT observed composition. Never reward shared zero-filled prior.
 comp_reliab=[corr(a[1][:,j],b[1][:,j],both) for j in range(4)]
 # Pilot observed-count uncertainty (not a calibrated confidence interval).
 n_present=int(positive.sum());n_zero=int((~positive).sum());med_umi=float(np.median(microP.sum(1)[positive]));med_sd=float(np.median(full[2]))
 # Report depth association and donor/operator levels; these are possible shortcut channels.
 depth_corr=corr(full[0],np.log1p(ref),np.ones(len(ref),dtype=bool))
 donor_means=[np.mean(full[0][mdon==d]) for d in sorted(set(mdon))]
 donor_cells=[int(sum(mdon==d)) for d in sorted(set(mdon))]
 res[name]={
  'query_address':q,'partner_addresses':pan,'readout_addresses_reserved':held,
  'microglia_cells':len(ref),'donors':len(set(mdon)),'operator_count':len(set(mops)),
  'n_positive_partner_UMI':n_present,'n_measured_zero_partner_UMI':n_zero,
  'median_partner_UMI_when_positive':med_umi,
  'half_count_activity_correlation_all_microglia':act_reliab,
  'half_count_activity_correlation_positive_only':act_pos,
  'half_count_composition_coordinate_correlations':comp_reliab,
  'half_count_both_nonzero':int(both.sum()),
  'composition_defined_in_full_cell':int(positive.sum()),
  'composition_undefined_zero_count':int((~positive).sum()),
  'composition_half_count_comparison_restricted_to_both_positive':True,
  'median_approx_activity_sampling_sd':med_sd,
  'activity_reference_depth_correlation':depth_corr,
  'eight_housekeeping_reference_zero_cells':int(np.sum(house_raw[micro]==0)),'disjoint_reference_abstains_when_zero':True,
  'independent_donor_cell_counts':{'min':min(donor_cells),'median':float(np.median(donor_cells)),'max':max(donor_cells)},
  'donor_mean_activity_range':[float(min(donor_means)),float(max(donor_means))],
  'teacher_target_structure':'measured nonquery amplitude plus regularized four-gene CLR composition with explicit support and measurement-error proxies',
 }
 checks += [f'{name}:exact q/panel/readout disjoint',f'{name}:q invariant before normalization',f'{name}:distinct zero/missing',f'{name}:independent reference denominator',f'{name}:all measured panel genes supported']
# Development-only student feasibility. Never use this as independent confirmation or select a target on it.
from sklearn.utils.extmath import randomized_svd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder
perm=np.random.default_rng(20260926).permutation(np.unique(donor[micro]));folds=np.array_split(perm,5)
common=np.flatnonzero(np.all(support[np.unique(ops)[:,None],np.arange(41238)[None,:]],axis=0))
common=common[~np.isin(common,list(ban))];student_records=[]
def r2(y,p,mu):
 den=np.sum((y-mu)**2);return float(1-np.sum((y-p)**2)/den) if den>0 else None
for fi,held in enumerate(folds):
 other=perm[~np.isin(perm,held)];rr=np.random.default_rng(20261010+fi).permutation(other)
 tr=np.flatnonzero(np.isin(donor,rr[8:]));te=np.flatnonzero(np.isin(donor,held));tm=tr[micro[tr]];em=te[micro[te]]
 assert len(set(donor[te]))==10 and len(set(donor[tr])&set(donor[te]))==0
 cand=raw_cols(common)[tm];prev=(cand>0).mean(0);variance=np.log1p(cand).var(0)
 ix=np.flatnonzero((prev>.1)&(prev<.98));ix=ix[np.argsort(-variance[ix],kind='stable')]
 sel=common[ix[:700]];assert len(sel)==700 and not set(sel)&ban
 panel=raw_cols(sel).astype(float)
 # Exactly matched-cell denominator-ablation: exclude all 700 student-visible genes from the teacher target reference.
 # This is not independent biological validation and uses a fold-specific, training-selected panel.
 ref_disjoint_large=observed_total-panel.sum(1);assert np.all(ref_disjoint_large[micro]>0)
 def masked(seed):
  keep=np.random.default_rng(seed).random(panel.shape)>.4
  v=panel*keep;tot=v.sum(1,keepdims=True)
  return np.log1p(np.divide(v*10000,tot,out=np.zeros_like(v),where=tot>0))
 view1=masked(910000+3*fi);view2=masked(910001+3*fi);view3=masked(910002+3*fi);viewte=masked(920000+fi)
 Ztrain=np.vstack([v[tr] for v in (view1,view2,view3)]);Ztest=viewte[te]
 _,idx,cnt=np.unique(donor[tr],return_inverse=True,return_counts=True);w=1/cnt[idx];w=np.tile(w/3,3)
 mu=np.average(Ztrain,axis=0,weights=w);sd=np.maximum(np.sqrt(np.average((Ztrain-mu)**2,axis=0,weights=w)),.07)
 _,_,vt=randomized_svd(((Ztrain-mu)/sd)*np.sqrt(w[:,None]/w.sum()),n_components=32,n_iter=3,random_state=3500+fi)
 latent=((Ztrain-mu)/sd)@vt.T;latent_te=((Ztest-mu)/sd)@vt.T
 oh=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(ops[tr,None])
 def tech(v,indices):
  sub=v[indices];return np.c_[oh.transform(ops[indices,None]),np.log1p(sub.sum(1)),(sub>0).sum(1),sub.var(1)]
 ttr=np.vstack([tech(v,tr) for v in (view1,view2,view3)]);tte=tech(viewte,te)
 keeptr=np.tile(micro[tr],3);keepte=micro[te];trainids=np.tile(np.flatnonzero(micro[tr]),3)
 for name in GENES:
  Y=pilot_targets[name];micro_original_indices=np.flatnonzero(micro);global_to_micro=np.full(len(meta),-1,dtype=int);global_to_micro[micro_original_indices]=np.arange(len(micro_original_indices))
  ytrain=Y[global_to_micro[tm]]; ytest=Y[global_to_micro[em]]
  w_micro=np.array([1/sum(donor[tm]==d) for d in donor[tm]]);wfit=np.tile(w_micro/3,3)
  zfit=latent[keeptr]; tfit=ttr[keeptr];zout=latent_te[keepte];tout=tte[keepte]
  yy=np.tile(ytrain,3);mean_y=np.average(ytrain,weights=w_micro)
  zp=Ridge(alpha=20).fit(zfit,yy,sample_weight=wfit/wfit.mean()).predict(zout)
  tp=Ridge(alpha=20).fit(tfit,yy,sample_weight=wfit/wfit.mean()).predict(tout)
  new_target=np.log1p(1e4*pilot_raw[name]/ref_disjoint_large[micro])
  dtrain=new_target[global_to_micro[tm]];dtest=new_target[global_to_micro[em]]
  dmu=np.average(dtrain,weights=w_micro)
  dp=Ridge(alpha=20).fit(zfit,np.tile(dtrain,3),sample_weight=wfit/wfit.mean()).predict(zout)
  dt=Ridge(alpha=20).fit(tfit,np.tile(dtrain,3),sample_weight=wfit/wfit.mean()).predict(tout)
  yhouse=house_targets[name];htrain=yhouse[global_to_micro[tm]];htest=yhouse[global_to_micro[em]];hmu=np.average(htrain,weights=w_micro)
  hkeep=house_raw[tm]>0;heval=house_raw[em]>0
  assert hkeep.sum()>20 and heval.sum()>10
  validtrain=np.tile(hkeep,3);validw=wfit[validtrain]
  hp=Ridge(alpha=20).fit(zfit[validtrain],np.tile(htrain[hkeep],3),sample_weight=validw/validw.mean()).predict(zout[heval])
  htech=Ridge(alpha=20).fit(tfit[validtrain],np.tile(htrain[hkeep],3),sample_weight=validw/validw.mean()).predict(tout[heval])
  hmu=np.average(htrain[hkeep],weights=w_micro[hkeep]);htest=htest[heval]
  # Identical eligible cells, identical student inputs; only target denominator differs.
  ym_overlap=np.average(ytrain[hkeep],weights=w_micro[hkeep])
  op=Ridge(alpha=20).fit(zfit[validtrain],np.tile(ytrain[hkeep],3),sample_weight=validw/validw.mean()).predict(zout[heval])
  ot=Ridge(alpha=20).fit(tfit[validtrain],np.tile(ytrain[hkeep],3),sample_weight=validw/validw.mean()).predict(tout[heval])
  over_ytest=ytest[heval]
  student_records.append({'fold':fi,'program':name,'test_micro':len(em),'test_donors':len(set(donor[em])),'student_r2':r2(ytest,zp,mean_y),'technical_r2':r2(ytest,tp,mean_y),'disjoint_large_student_r2':r2(dtest,dp,dmu),'disjoint_large_technical_r2':r2(dtest,dt,dmu),'disjoint_house_n_evaluable':int(heval.sum()),'overlap_matched_student_r2':r2(over_ytest,op,ym_overlap),'overlap_matched_technical_r2':r2(over_ytest,ot,ym_overlap),'disjoint_house_student_r2':r2(htest,hp,hmu),'disjoint_house_technical_r2':r2(htest,htech,hmu)})
for name in GENES:
 a=[x for x in student_records if x['program']==name]
 res[name]['fivefold_student_activity_mean_r2']=float(np.mean([x['student_r2'] for x in a]))
 res[name]['fivefold_technical_activity_mean_r2']=float(np.mean([x['technical_r2'] for x in a]))
 res[name]['student_minus_technical_by_fold']=[float(x['student_r2']-x['technical_r2']) for x in a]
 res[name]['fivefold_disjoint_large_student_mean_r2']=float(np.mean([x['disjoint_large_student_r2'] for x in a]))
 res[name]['fivefold_disjoint_large_technical_mean_r2']=float(np.mean([x['disjoint_large_technical_r2'] for x in a]))
 res[name]['fivefold_overlap_matched_student_mean_r2']=float(np.mean([x['overlap_matched_student_r2'] for x in a]))
 res[name]['fivefold_overlap_matched_technical_mean_r2']=float(np.mean([x['overlap_matched_technical_r2'] for x in a]))
 res[name]['fivefold_disjoint_house_student_mean_r2']=float(np.mean([x['disjoint_house_student_r2'] for x in a]))
 res[name]['fivefold_disjoint_house_technical_mean_r2']=float(np.mean([x['disjoint_house_technical_r2'] for x in a]))
 res[name]['disjoint_house_student_minus_technical_by_fold']=[float(x['disjoint_house_student_r2']-x['disjoint_house_technical_r2']) for x in a]
checks.extend(['large disjoint denominator positive on all microglia','disjoint reference zero-case abstention','fivefold donor-disjoint student target activity pilot','no q/panel/readout in student 700-gene panel','technical control on identical visible views'])

print(json.dumps({k:{j:v for j,v in x.items() if j not in ('partner_addresses','readout_addresses_reserved','independent_donor_cell_counts')} for k,x in res.items()},indent=2),flush=True)
out={'schema':'JEPA_R8_STRUCTURED_TARGET_DEV_PROBE_V1','date':'2026-09-26','population':'historical repeated 361 microglia cells / 50 donors / 15 ops','claim':'measurement-precision and structure only, no independent biological validation','source_sha256':sha.hexdigest(),'reference_exclusion_count':len(ban),'housekeeping_reference_symbols':HOUSE,'results':res,'student_pilot_folds':student_records,'passed_checks':checks,'training_authorized':False,'protected_data_opened':False}
(R/'JEPA_R8_STRUCTURED_TARGET_RESULTS_20260926.json').write_text(json.dumps(out,indent=2)+'\n')
