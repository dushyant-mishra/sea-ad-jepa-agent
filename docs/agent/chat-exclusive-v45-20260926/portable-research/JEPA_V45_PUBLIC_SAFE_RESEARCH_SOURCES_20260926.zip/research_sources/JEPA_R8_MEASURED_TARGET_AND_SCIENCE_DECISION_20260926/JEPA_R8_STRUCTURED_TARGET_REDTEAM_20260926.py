#!/usr/bin/env python3
"""Isolated hostile/positive tests for developmental target semantics; not biology proof."""
import sys
sys.path.insert(0,'/mnt/data')
from dataclasses import replace
from JEPA_R8_STRUCTURED_TARGET_CONTRACT_20260926 import Evidence,construct_measured_anchor,TargetEvidenceError
import json
ROOT='07748d5bd21fe0857ccad3002fba3946d1791d25898b841d41056a3707117444'
e=Evidence('original-cell-A','donor-X',6186,'APOE',(1,2,3,4),(3,2,1,0),(10,11,12,13,14,15,16,17),(8,8,7,6,5,4,3,2),'RNA','SAME_ORIGINAL_CELL',ROOT,13)
passed=[]
def yes(test,msg):
 assert test,msg;passed.append(msg)
def bad(x,msg):
 try:construct_measured_anchor(x,expected_source_sha256=ROOT)
 except TargetEvidenceError:passed.append(msg)
 else:raise AssertionError('FALSE_GREEN '+msg)
a=construct_measured_anchor(e,expected_source_sha256=ROOT)
yes(a.status=='MEASURED_NONZERO' and abs(sum(a.clr_composition))<1e-12,'measured positive / centered composition')
b=construct_measured_anchor(replace(e,teacher_queried_umi=999999),expected_source_sha256=ROOT)
yes((a.log10k_activity,a.clr_composition)==(b.log10k_activity,b.clr_composition),'queried scalar cannot change measured target even if rich teacher saw it')
b=construct_measured_anchor(replace(e,teacher_queried_umi=None),expected_source_sha256=ROOT)
yes(a.log10k_activity==b.log10k_activity and not b.teacher_query_count_was_supplied,'q-excluded policy produces same fixed measured anchor')
z=construct_measured_anchor(replace(e,partner_raw_umi=(0,0,0,0)),expected_source_sha256=ROOT)
yes(z.status=='MEASURED_ZERO_COMPOSITION_UNDEFINED' and z.log10k_activity==0 and z.clr_composition is None,'measured zero != unmeasured or fake composition')
z=construct_measured_anchor(replace(e,partner_raw_umi=(None,0,0,0)),expected_source_sha256=ROOT)
yes(z.status=='ABSTAIN_PARTNER_UNMEASURED' and z.log10k_activity is None,'structurally missing partner abstains')
z=construct_measured_anchor(replace(e,reference_raw_umi=(0,)*8),expected_source_sha256=ROOT)
yes(z.status=='ABSTAIN_REFERENCE_ZERO' and z.log10k_activity is None,'reference-zero abstention, no division by zero')
z=construct_measured_anchor(replace(e,reference_raw_umi=(None,)+e.reference_raw_umi[1:]),expected_source_sha256=ROOT)
yes(z.status=='ABSTAIN_REFERENCE_UNMEASURED','reference missing abstention')
bad(replace(e,partner_address_ids=(1,2,3,6186)),'queried value in partner genes rejected')
bad(replace(e,disjoint_reference_address_ids=(10,11,12,13,14,15,16,1)),'reference overlaps teacher panel rejected')
bad(replace(e,correspondence='SAME_DONOR_DIFFERENT_NUCLEUS'),'unpaired same donor cannot merge as same-cell')
bad(replace(e,assay='ATAC'),'not a same-cell RNA anchor')
bad(replace(e,original_sha256='0'*64),'source root mismatch rejected')
bad(replace(e,partner_raw_umi=(-1,2,3,0)),'negative UMI rejected')
bad(replace(e,teacher_queried_umi=True),'bool masquerading as count rejected')
bad(replace(e,partner_address_ids=(1,2,3,3)),'duplicate partner rejected')
# An actual source change must be verified by the original audit; the schema cannot invent provenance.
yes(not a.scientifically_validated and not a.causal_claim,'status explicitly nonvalidating/noncausal')
print(json.dumps({'schema':'JEPA_R8_HISTORICAL_TARGET_REDTEAM','passed':len(passed),'failed':0,'checks':passed,'training_authorized':False},indent=2))
