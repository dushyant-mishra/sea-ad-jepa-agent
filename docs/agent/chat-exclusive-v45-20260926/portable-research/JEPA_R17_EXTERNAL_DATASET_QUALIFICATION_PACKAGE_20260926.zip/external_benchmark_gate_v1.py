#!/usr/bin/env python3
"""Outcome-blind external benchmark custody gate; research only, never authorizes training.
Run: python external_benchmark_gate_v1.py candidate_manifest.json
No network, no biological outcome inspection, no donor data saved here.
"""
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

FIELDS = ('id','family','source_url','access','published_total_donors','paired_donor_count',
          'paired_donor_count_basis','donor_identity_authenticated','microglial_donor_count',
          'microglial_donor_count_basis','original_files_authenticated','feature_mapping_authenticated',
          'training_overlap_checked','prior_outcome_exposure_audited','evaluation_protocol_frozen',
          'outcome_access','use_as_independent_replication_of')
TRUE_KEYS = ('donor_identity_authenticated','original_files_authenticated','feature_mapping_authenticated',
             'training_overlap_checked','prior_outcome_exposure_audited','evaluation_protocol_frozen')
ALLOWED_OUTCOME = ('SEALED','QUARANTINED_WITH_EXPOSURE_REGISTER')

class GateError(ValueError): pass

def inspect(candidate:dict, families:dict[str,str]|None=None)->dict:
    missing = sorted(set(FIELDS) - candidate.keys())
    if missing: raise GateError('missing schema keys: '+','.join(missing))
    if candidate['access'] not in ('OPEN','CONTROLLED'):
        raise GateError('access must be OPEN or CONTROLLED')
    if candidate['outcome_access'] not in ('SEALED','QUARANTINED_WITH_EXPOSURE_REGISTER','OPENED_UNRECORDED'):
        raise GateError('invalid outcome_access')
    family=candidate['family']; ident=candidate['id']
    if not family or not ident or not candidate['source_url'].startswith('https://'):
        raise GateError('source identity invalid')
    n=candidate['published_total_donors']; paired=candidate['paired_donor_count']; mic=candidate['microglial_donor_count']
    if type(n) is not int or n < 1: raise GateError('published_total_donors must be a documented positive integer')
    for name,value in [('paired_donor_count',paired),('microglial_donor_count',mic)]:
        if value is not None and (type(value) is not int or value<0 or value>n):
            raise GateError(f'{name} exceeds published donors or invalid')
    if mic is not None and paired is not None and mic>paired:
        raise GateError('microglial paired donors cannot exceed paired donors')
    if paired is not None and not candidate['paired_donor_count_basis']:
        raise GateError('paired donor count has no source basis')
    if mic is not None and not candidate['microglial_donor_count_basis']:
        raise GateError('microglial donor count has no source basis')
    if any(type(candidate[k]) is not bool for k in TRUE_KEYS):
        raise GateError('attestations must be booleans, never strings')
    if families is not None and candidate['use_as_independent_replication_of']:
        other=candidate['use_as_independent_replication_of']
        if other not in families: raise GateError('unknown prior cohort in independence claim')
        if family==families[other]: raise GateError('same family cannot be independent replication')
    blockers=[]
    if paired is None: blockers.append('PAIRED_DONOR_COUNT_UNKNOWN')
    if mic is None: blockers.append('PAIRED_MICROGLIAL_DONOR_COUNT_UNKNOWN')
    if paired==0 or mic==0: blockers.append('NO_PAIRED_MICROGLIAL_DONORS')
    if candidate['access']=='CONTROLLED' and not candidate.get('duc_authorized',False):blockers.append('DATA_USE_AGREEMENT_NOT_AUTHORIZED')
    if candidate['outcome_access'] not in ALLOWED_OUTCOME: blockers.append('OUTCOME_EXPOSURE_UNRECORDED')
    for k in TRUE_KEYS:
        if not candidate[k]:blockers.append(k.upper()+'_OPEN')
    if candidate['use_as_independent_replication_of'] and families is None:
        blockers.append('INDEPENDENCE_RELATION_NOT_VERIFIED')
    return {'id':ident,'status':'ELIGIBLE_FOR_SEPARATE_SCIENTIFIC_REVIEW' if not blockers else 'BLOCKED_OUTCOME_BLIND',
            'blockers':blockers,'published_total_donors':n,'paired_donors':paired,
            'paired_microglial_donors':mic,'training_authorized':False,
            'outcome_scored':False}

def inspect_manifest(doc:dict)->dict:
    rows=doc.get('candidates')
    if not isinstance(rows,list) or not rows: raise GateError('no candidates')
    ids=[r['id'] for r in rows]
    if len(ids)!=len(set(ids)):raise GateError('duplicate dataset IDs')
    families={r['id']:r['family'] for r in rows}
    res=[inspect(r,families) for r in rows]
    raw=json.dumps({'schema':'R17_OUTCOME_BLIND_EXTERNAL_BENCHMARK_GATE_V1','results':res},sort_keys=True,separators=(',',':')).encode()
    return {'schema':'R17_OUTCOME_BLIND_EXTERNAL_BENCHMARK_GATE_V1','results':res,'digest_sha256':hashlib.sha256(raw).hexdigest(),
            'training_authorized':False,'outcome_scored':False}

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: python external_benchmark_gate_v1.py candidate_manifest.json')
    d=json.loads(Path(sys.argv[1]).read_text());print(json.dumps(inspect_manifest(d),indent=2))
