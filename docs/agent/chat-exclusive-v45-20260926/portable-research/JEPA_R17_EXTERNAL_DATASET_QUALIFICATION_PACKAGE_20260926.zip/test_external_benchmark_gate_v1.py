import copy,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from external_benchmark_gate_v1 import inspect,inspect_manifest,GateError
DOC=json.loads((Path(__file__).parent/'candidate_manifest.json').read_text())
class TestGate(unittest.TestCase):
 def test_all_stay_blocked(self):
  r=inspect_manifest(DOC);self.assertEqual(len(r['results']),4)
  self.assertTrue(all(v['status']=='BLOCKED_OUTCOME_BLIND' for v in r['results']))
  self.assertFalse(r['training_authorized'])
 def test_donor_unknown_not_assumed_from_study_total(self):
  self.assertIn('PAIRED_DONOR_COUNT_UNKNOWN',inspect(DOC['candidates'][2])['blockers'])
 def test_microglia_unknown_never_assumed(self):
  self.assertIn('PAIRED_MICROGLIAL_DONOR_COUNT_UNKNOWN',inspect(DOC['candidates'][0])['blockers'])
 def test_duc_blocks_controlled(self):
  self.assertIn('DATA_USE_AGREEMENT_NOT_AUTHORIZED',inspect(DOC['candidates'][2])['blockers'])
 def test_outcome_exposure(self):
  c=copy.deepcopy(DOC['candidates'][0]);c['outcome_access']='OPENED_UNRECORDED';self.assertIn('OUTCOME_EXPOSURE_UNRECORDED',inspect(c)['blockers'])
 def test_zero_donors(self):
  c=copy.deepcopy(DOC['candidates'][0]);c['paired_donor_count']=0;c['microglial_donor_count']=0;c['paired_donor_count_basis']='zero verified in metadata';c['microglial_donor_count_basis']='zero verified in metadata';self.assertIn('NO_PAIRED_MICROGLIAL_DONORS',inspect(c)['blockers'])
 def test_false_15_paired_microglia(self):
  c=copy.deepcopy(DOC['candidates'][0]);c['paired_donor_count']=15;c['paired_donor_count_basis']='paper total only';c['microglial_donor_count']=16;c['microglial_donor_count_basis']='invented';
  with self.assertRaises(GateError):inspect(c)
 def test_false_same_family_independence(self):
  c=copy.deepcopy(DOC['candidates'][0]);c['use_as_independent_replication_of']='GSE214637'
  with self.assertRaises(GateError):inspect(c,{'GSE214637':'GSE214637_ANDERSON'})
 def test_false_rosmap_pfc_independence(self):
  c=copy.deepcopy(DOC['candidates'][2]);c['use_as_independent_replication_of']='SYN52293417'
  with self.assertRaises(GateError):inspect(c,{'SYN52293417':'ROSMAP_XIONG_2025'})
 def test_duplicate_records(self):
  d=copy.deepcopy(DOC);d['candidates'].append(copy.deepcopy(d['candidates'][0]));
  with self.assertRaises(GateError):inspect_manifest(d)
 def test_string_attestation_is_not_truth(self):
  c=copy.deepcopy(DOC['candidates'][0]);c['original_files_authenticated']='true';
  with self.assertRaises(GateError):inspect(c)
 def test_bool_not_acceptable_as_sample_size(self):
  c=copy.deepcopy(DOC['candidates'][0]);c['published_total_donors']=True
  with self.assertRaises(GateError):inspect(c)
 def test_missing_basis(self):
  c=copy.deepcopy(DOC['candidates'][0]);c['paired_donor_count']=15
  with self.assertRaises(GateError):inspect(c)
 def test_fake_all_true_requires_actual_counts(self):
  c=copy.deepcopy(DOC['candidates'][0]);
  for k in ('donor_identity_authenticated','original_files_authenticated','feature_mapping_authenticated','training_overlap_checked','prior_outcome_exposure_audited','evaluation_protocol_frozen'): c[k]=True
  self.assertIn('PAIRED_DONOR_COUNT_UNKNOWN',inspect(c)['blockers'])
 def test_controlled_needs_duc_even_full_other_data(self):
  c=copy.deepcopy(DOC['candidates'][2]);c['paired_donor_count']=50;c['paired_donor_count_basis']='audited';c['microglial_donor_count']=20;c['microglial_donor_count_basis']='audited';
  for k in ('donor_identity_authenticated','original_files_authenticated','feature_mapping_authenticated','training_overlap_checked','prior_outcome_exposure_audited','evaluation_protocol_frozen'):c[k]=True
  self.assertEqual(inspect(c)['blockers'],['DATA_USE_AGREEMENT_NOT_AUTHORIZED'])
if __name__=='__main__':unittest.main(verbosity=2)
