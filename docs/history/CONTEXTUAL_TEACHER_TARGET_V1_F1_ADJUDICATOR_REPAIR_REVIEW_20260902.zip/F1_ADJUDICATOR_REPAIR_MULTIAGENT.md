# F1 adjudicator repair — targeted multi-agent review

Overall verdict: **PASS AWAITING EXTERNAL REVIEW**. Key question—can a subset of the frozen 104-donor/2,781-cell population or an incomplete decision stack produce a production PASS? **No.**

1. Historian / Authority — PASS. Frozen assignment, randomization, weights, namespace, null map, complete engine, and decision contracts are unchanged. An initial STOP found that an arbitrary complete payload could be paired with a component result; the adapter was rewritten so `integrate_records()` is the sole production qualification entry.

2. Statistics / Query Design — PASS. Exact 44,496 assignments and 222,480 assignment×evidence keys are required, with 2,781 cells, 104 donors, 42 operators, eight programs, and two draws. Cell weights are byte-bound; donor mass is exactly one; `Vhat=(Z0-Z1)^2/4` is derived internally; QID wins are exactly `{0,.5,1}`. A temporary STOP about Spearman was resolved by authenticating the already-frozen QID-v2 replacement contract (`15d87387…c69423`).

3. Decision-Engine Integration — PASS. No aggregate-only production qualifier remains. Complete endpoints derive from the same validated aggregate. The caller may supply only exact donor-bound nuisance descriptors, all six frozen semantic categories are mandatory, and the real nuisance root remains unset. Full qualification is component PASS AND hash-pinned complete-engine PASS.

4. Biology / Protected Programs — PASS. All eight programs remain explicit. Protected-family estimability/reporting, contextual-minus-direct degradation, evidence trend, QID-v2, HC3 nuisance, and cross-source replication remain veto-capable. No threshold, endpoint family, or claim scope changed.

5. Provenance / Population Completeness — PASS. Omission, relabel, duplicate-replacement, extra-record, subset, and nuisance-omission attacks reject. No expression, outcomes, training, or EMA were accessed.

6. Scientific Red-Team — PASS. It reproduced the earlier forged-aggregate and empty-nuisance attacks against the superseded adapter, then confirmed both routes are closed. All fourteen current integration/incompleteness attacks pass. Publication had to be regenerated from current sources; the final manifest performs that condition.

Preserved boundary: real execution remains unauthorized because both forward and nuisance authorities are unset. Dissent/STOPs were preserved and repaired rather than suppressed.
