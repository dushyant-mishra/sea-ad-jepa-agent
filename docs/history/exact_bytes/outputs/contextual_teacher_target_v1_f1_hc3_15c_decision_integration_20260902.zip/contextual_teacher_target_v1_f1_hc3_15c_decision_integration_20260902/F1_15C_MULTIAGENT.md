# F1 15C Targeted Review

Exactly six scoped lenses reviewed the synthetic-only integration. Initial dissent is preserved below.

## 1. Historian / Authority — PASS

15B remained immutable and was not re-selected. `(5,0,4)` and the exact design are loaded and reverified only. The chronology remains `EXECUTION_ENFORCED_PROSPECTIVELY__EXTERNAL_TIME_ANCHOR_UNAVAILABLE`; the local anchor is not represented as independent pre-result time proof.

## 2. Statistics / HC3 — PASS after narrow provenance repair

The frozen input design SHA remains `5d2fda2e81a6edd63241ccf996fe0e5086275233e765daae19509be24cd518e3`. Initial review found that a vectorized re-centering SHA did not identify the exact matrix built by frozen v1 arithmetic. The adapter now hashes the matrix returned by the actual frozen `nuisance_design()` transformation; an independent per-column reconstruction agrees at `37653ed4a21f513a7389630bffa7447f9022323e8240bb80f53394138f1917eb`. HC3 rank/df remain 16/88 and the gate vector is unchanged.

## 3. Decision-Engine Semantics — PASS

The unchanged decision v4 computes one HC3 object and exposes exactly one `hc3_nuisance_positive` gate. The adapter calls that engine once and adds provenance only afterward. All 14 legacy cases pass; no stale or double HC3 gate exists.

## 4. Dataset / Donor Geometry — PASS after fail-open repair

Initial review found that parallel arrays allowed silent positional outcome drift. The boundary was replaced with exact donor-keyed records. It now requires the exact 104-donor set and reconstructs all endpoint vectors in frozen schema order. Insertion-order permutation is invariant; the obsolete positional-array interface, omission, and relabeling are rejected.

## 5. Provenance / Firewall — PASS

Controlling 15A4/15B/provenance, selected-design, truth-table, decision/integration, component, legal, assignment, null-map, and namespace bytes are hash-bound. No expression/model/checkpoint loader or training path exists. Real execution unconditionally stops because reader/forward authority remains unset.

## 6. Scientific Red-Team — PASS after expanded executable attacks

The suite executes actual one-bit design mutation, altered triple/schema, NPH-C1, HVS-C6, and old raw rank-18 substitutions. It also rejects forged HC3 PASS, NaN, invalid legal values, donor omission/relabel, and positional arrays. Exact zero outcome makes HC3 unestimable; source-confined and isolated HC3-veto fixtures change the intended gates. Independent code reproduces the conclusion-bearing checks.

## Preserved dissent and resolution

- Initial Dataset/Donor Geometry: STOP for parallel positional arrays. Resolved by donor-keyed records and a direct positional-interface attack.
- Initial Provenance/Red-Team: STOP for unverified truth-table/namespace bytes, superficial design attacks, wrong zero-variance target, and shallow independent validation. All four were repaired and re-reviewed PASS.
- Initial Statistics/HC3: CONCERN/STOP for mislabelled effective-matrix SHA. Resolved by hashing the actual frozen-v1 transform and independent byte agreement.

Final council result: all six lenses PASS; no remaining dissent or promotion-grade ambiguity.
