# F1 strict legal/provenance Boolean repair — four-lens review

Key question: can any non-Boolean legal/provenance value produce a current PASS? **No.**

1. Authority / Historian — PASS. The frozen truth table requires legal provenance to equal true; the repair enforces that authority rather than adding science. No randomization, population, statistical, estimand, or claim-scope authority changed.

2. Statistics / Decision Semantics — PASS. Built-in `True` preserves the passing behavior and built-in `False` preserves the failing legal gate. All fourteen decision regression artifacts are byte-identical; tails, confidence intervals, Holm families, thresholds, protected-program reporting, and claim scope are unchanged.

3. Provenance / Type Boundary — PASS AFTER PUBLICATION REPAIR. The code boundary was correct, but the first review issued `STOP_PROVENANCE_HASH_MISMATCH` because the intentionally historical truth-table package still bound pre-repair sources. That package was not rewritten. This new narrow package includes fresh source snapshots and manifests for the repaired decision/integration bytes; the manifest verification is the resolution.

4. Scientific Red-Team — PASS. Direct decision and integration attacks reject strings, integers, containers, `None`, NumPy booleans, and all other non-built-in-bool objects. Exact `type(...) is bool` closes the domain generally, not only for enumerated examples. No stale v1 route is a current production authority.

Real execution remains fail-closed because forward and nuisance roots are unset. No reader, expression, candidate outcome, training, or EMA work occurred.
