#!/usr/bin/env python3
"""Resource-derived batch-size benchmark for the engineering-only ALL executor."""
from __future__ import annotations

import argparse
import gc
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import psutil

import run_full104_refit_null_block_major_v1 as block


def load_plan(directory: Path) -> pd.DataFrame:
    authority = json.loads((directory / "LOSSLESS_PLAN_AUTHORITY.json").read_text())
    if authority["plan_file_sha256"] != block.EXPECTED_ALL_PLAN_SHA256:
        raise RuntimeError("benchmark ALL plan mismatch")
    with np.load(directory / authority["plan_file"], allow_pickle=False) as z:
        return pd.DataFrame({name: z[name] for name in z.files})


def representative_plan(plan: pd.DataFrame) -> pd.DataFrame:
    groups = [(key, group) for key, group in plan.groupby(["donor_id", "operator_index"], sort=True)]
    sizes = np.asarray([len(group) for _, group in groups])
    chosen = set()
    for quantile in (0.0, 0.25, 0.5, 0.75, 0.9, 1.0):
        target = float(np.quantile(sizes, quantile))
        chosen.add(int(np.argmin(np.abs(sizes - target))))
    # Touch every donor accumulator while keeping the benchmark bounded.
    first_by_donor = {}
    for index, ((donor, _operator), _group) in enumerate(groups):
        first_by_donor.setdefault(str(donor), index)
    chosen.update(first_by_donor.values())
    return pd.concat([groups[index][1] for index in sorted(chosen)], ignore_index=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--matrix", required=True)
    parser.add_argument("--plan-dir", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=False)
    matrix = Path(args.matrix).resolve(); plan = load_plan(Path(args.plan_dir).resolve())
    sample = representative_plan(plan); donors = sorted(plan.donor_id.astype(str).unique())
    views = np.load(matrix / "A_views.npy", mmap_mode="r")
    key = "engineering-throughput-benchmark-v1"
    candidates = [1, 8, 32, 64, 128, 256]; records = []
    for k in candidates:
        available = int(psutil.virtual_memory().available)
        accumulator = int(k * block.ACCUMULATOR_BYTES_PER_REPLICATE)
        largest_block = int(sample.groupby(["donor_id", "operator_index"]).size().max() * 4 * views.shape[-1] * 8)
        reserve = 4 * 1024**3
        safe = accumulator + largest_block + reserve <= available
        if not safe:
            records.append({"K": k, "status": "SKIPPED_MEMORY_UNSAFE", "available_bytes": available,
                            "accumulator_bytes": accumulator, "largest_float64_block_bytes": largest_block,
                            "required_including_reserve_bytes": accumulator + largest_block + reserve})
            continue
        before_swap = psutil.swap_memory(); process = psutil.Process(); io0 = process.io_counters(); rss0 = process.memory_info().rss
        between = np.empty((k, len(donors), views.shape[-1], views.shape[-1]), np.float64); between.fill(0.0)
        compensation = np.empty_like(between); compensation.fill(0.0)
        touched_rss = process.memory_info().rss; started = time.perf_counter()
        result, _maps, metrics = block.block_major_null_between_batch(
            views, sample, donors, "A", list(range(k)), key, args.device,
            between=between, compensation=compensation)
        elapsed = time.perf_counter() - started; io1 = process.io_counters(); after_swap = psutil.swap_memory()
        finite = bool(np.isfinite(result).all())
        records.append({"K": k, "status": "PASS" if finite else "STOP_NONFINITE", "rows": int(len(sample)),
                        "strata": int(sample.groupby(["donor_id", "operator_index"]).ngroups),
                        "wall_seconds": elapsed, "replicates_per_second": k / elapsed,
                        "logical_bytes_read": int(metrics["logical_matrix_bytes_read"]),
                        "physical_read_bytes_delta": int(io1.read_bytes - io0.read_bytes),
                        "rss_before_bytes": int(rss0), "rss_after_touch_bytes": int(touched_rss),
                        "rss_peak_proxy_bytes": int(process.memory_info().rss),
                        "swap_used_before_bytes": int(before_swap.used), "swap_used_after_bytes": int(after_swap.used),
                        "available_before_bytes": available, "accumulator_bytes": accumulator, "finite": finite})
        del result, between, compensation; gc.collect()
    passed = [r for r in records if r["status"] == "PASS" and r["swap_used_after_bytes"] <= r["swap_used_before_bytes"]]
    if not passed:
        status, selected = "STOP_NO_SAFE_BATCH_SIZE", None
    else:
        best = max(passed, key=lambda r: r["replicates_per_second"])
        selected = int(best["K"]); status = "PASS_BLOCK_MAJOR_BATCH_SIZE_DERIVED"
    report = {"status": status, "selected_K": selected, "selection_rule": "highest measured replicates_per_second among memory-safe candidates with no swap-use increase",
              "candidates": records}
    (out / "BLOCK_MAJOR_BATCH_BENCHMARK.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2))
    if selected is None: raise SystemExit(2)


if __name__ == "__main__":
    main()
