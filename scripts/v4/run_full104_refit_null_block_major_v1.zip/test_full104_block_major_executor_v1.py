#!/usr/bin/env python3
"""Targeted parity/resume/adversarial tests for block-major ALL execution."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

import full104_refit_null_sensitivity_core_v1 as core
import run_full104_refit_null_block_major_v1 as block


def synthetic(seed=17):
    rng=np.random.default_rng(seed); donors=[f"D{i}" for i in range(4)]; records=[]; values=[]; row=0
    for donor in donors:
        for operator in range(2):
            n=5+operator; values.append(rng.normal(size=(n,4,12)).astype(np.float32))
            for _ in range(n): records.append({"row_index":row,"selection_row":row,"donor_id":donor,"operator_index":operator,"stratum_n":n,"stratum_m":n,"sample_rank":row,"within_donor_weight":1/(2*n),"global_weight":1/(8*n)}); row+=1
    return np.concatenate(values),pd.DataFrame(records),donors


def parity_for_views(views,plan,donors,key,sketch,replicates,device):
    sequential=[]; maps=[]
    for rep in replicates:
        value,mapping=core.null_between_one(views,plan,donors,"ALL",sketch,rep,key,device);sequential.append(value);maps.append(mapping)
    batched,batch_maps,_=block.block_major_null_between_batch(views,plan,donors,sketch,replicates,key,device)
    return bool(np.array_equal(np.asarray(sequential),batched) and maps==[batch_maps[x] for x in replicates]),float(np.max(np.abs(np.asarray(sequential)-batched)))


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--matrix",required=True);parser.add_argument("--plan-dir",required=True);parser.add_argument("--out",required=True);parser.add_argument("--device",default="cuda")
    args=parser.parse_args();out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=False);key="fixture-key"
    views,plan,donors=synthetic();results=[]
    for sketch,local in (("A",views),("B",views[:, :, ::-1].copy())):
        passed,diff=parity_for_views(local,plan,donors,key,sketch,[0,1,2,3],args.device);results.append({"test":f"synthetic_{sketch}_old_vs_new","pass":passed,"max_abs":diff})
    reference,_,_=block.block_major_null_between_batch(views,plan,donors,"A",[0],key,args.device)
    for ids,position in (([0,1],0),([0,1,2,3,4,5,6,7],0),([0,1,2],0)):
        candidate,_,_=block.block_major_null_between_batch(views,plan,donors,"A",ids,key,args.device);results.append({"test":f"batch_invariance_K{len(ids)}","pass":bool(np.array_equal(reference[0],candidate[position]))})
    mid,_,_=block.block_major_null_between_batch(views,plan,donors,"A",[4,0] if False else [0,4],key,args.device);results.append({"test":"same_replicate_first","pass":bool(np.array_equal(reference[0],mid[0]))})
    last,_,_=block.block_major_null_between_batch(views,plan,donors,"A",[0,1,2,3,4],key,args.device);solo4,_,_=block.block_major_null_between_batch(views,plan,donors,"A",[4],key,args.device);results.append({"test":"same_replicate_last","pass":bool(np.array_equal(last[4],solo4[0]))})

    # Forced interruption after half the strata, exact accumulator reload, resume.
    checkpoint=out/"resume_checkpoint";identity=block.batch_identity("fp","gate","matrix","A",[0,1],2,{"plan_sha256":"p","plan_semantic_sha256":"s"})
    identity["accumulator_shape"]=[2,len(donors),views.shape[-1],views.shape[-1]]
    maps={r:core.null_mapping_sha256(plan,"ALL","A",r,key) for r in [0,1]}
    class Interrupted(Exception): pass
    def callback(position,b,c): block.save_batch_checkpoint(checkpoint,identity,position,b,c,maps);raise Interrupted()
    try: block.block_major_null_between_batch(views,plan,donors,"A",[0,1],key,args.device,checkpoint_every=4,checkpoint_callback=callback)
    except Interrupted: pass
    restored=block.load_batch_checkpoint(checkpoint,identity,maps)
    resumed,_,_=block.block_major_null_between_batch(
        views,plan,donors,"A",[0,1],key,args.device,
        start_stratum=restored[0],between=restored[1],compensation=restored[2])
    uninterrupted,_,_=block.block_major_null_between_batch(views,plan,donors,"A",[0,1],key,args.device);results.append({"test":"forced_interruption_resume","pass":bool(np.array_equal(resumed,uninterrupted))})

    # Real FULL104 representative strata: small, median-ish and largest.
    matrix=Path(args.matrix).resolve();plan_dir=Path(args.plan_dir).resolve();z=np.load(plan_dir/"NESTED_WEIGHTED_SELECTION.npz",allow_pickle=False);full=pd.DataFrame({name:z[name] for name in z.files});sizes=full.groupby(["donor_id","operator_index"],sort=True).size();targets=[sizes.idxmin(),(sizes-sizes.median()).abs().idxmin(),sizes.idxmax()]
    # Bound the parity fixture's I/O while retaining min/median/max-stratum provenance.
    real=pd.concat([full[(full.donor_id==d)&(full.operator_index==o)].head(256) for d,o in targets],ignore_index=True);real_donors=sorted(real.donor_id.unique())
    for sketch in "AB":
        mmap=np.load(matrix/f"{sketch}_views.npy",mmap_mode="r");passed,diff=parity_for_views(mmap,real,real_donors,"real-subset-key",sketch,[0,1],args.device);results.append({"test":f"real_subset_{sketch}_old_vs_new","pass":passed,"max_abs":diff,"rows":len(real)})

    adversarial={}
    try:block.block_major_null_between_batch(views,plan,donors,"A",[0,0],key,args.device);adversarial["duplicate_replicate"]=False
    except RuntimeError:adversarial["duplicate_replicate"]=True
    attacks={"wrong_batch":dict(identity,batch_size=8),"missing_replicate":dict(identity,replicate_ids=[0]),"wrong_sketch":dict(identity,sketch="B"),"stale_fingerprint":dict(identity,implementation_fingerprint="old"),"block_order":dict(identity,stratum_order="changed")}
    for name,bad in attacks.items():
        try:block.load_batch_checkpoint(checkpoint,bad,maps);adversarial[name]=False
        except RuntimeError:adversarial[name]=True
    wrong_maps=dict(maps);wrong_maps[0]="bad"
    try:block.load_batch_checkpoint(checkpoint,identity,wrong_maps);adversarial["wrong_null_map"]=False
    except RuntimeError:adversarial["wrong_null_map"]=True
    dtype_dir=out/"dtype_checkpoint";dtype_dir.mkdir();np.save(dtype_dir/"between.npy",np.zeros((2,4,12,12),np.float32));np.save(dtype_dir/"compensation.npy",np.zeros((2,4,12,12),np.float64));state={**identity,"next_stratum":0,"between_sha256":block.sha(dtype_dir/"between.npy"),"compensation_sha256":block.sha(dtype_dir/"compensation.npy"),"replicate_map_sha256":{str(k):v for k,v in maps.items()}};(dtype_dir/"BATCH_STATE.json").write_text(json.dumps(state))
    try:block.load_batch_checkpoint(dtype_dir,identity,maps);adversarial["dtype_downgrade"]=False
    except RuntimeError:adversarial["dtype_downgrade"]=True
    adversarial["A_map_on_B"]=adversarial["wrong_sketch"] and adversarial["wrong_null_map"]
    adversarial["cross_contamination"]=bool(np.array_equal(last[4],solo4[0]) and np.array_equal(reference[0],last[0]))
    adversarial["tail_batch"]=next(x["pass"] for x in results if x["test"]=="batch_invariance_K3")
    results.append({"test":"adversarial_suite","pass":all(adversarial.values()),"details":adversarial})
    passed=all(x["pass"] for x in results);report={"status":"PASS_BLOCK_MAJOR_TARGETED_PARITY" if passed else "STOP_BLOCK_MAJOR_TARGETED_PARITY","results":results}
    (out/"BLOCK_MAJOR_TARGETED_PARITY.json").write_text(json.dumps(report,indent=2,sort_keys=True)+"\n");print(json.dumps(report,indent=2));
    if not passed:raise SystemExit(2)

if __name__=="__main__":main()
